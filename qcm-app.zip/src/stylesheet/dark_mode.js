﻿import { Platform, StyleSheet } from 'react-native'

const styles = StyleSheet.create({
    backgroundColor: {
        backgroundColor: '#000'
    },
    fontColor: {
        color: '#FFF'
    }
});

export default styles