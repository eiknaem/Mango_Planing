﻿import { Platform, StyleSheet } from 'react-native'

const styles = StyleSheet.create({
    input: {
        marginLeft: 0
    },
    picker: {
        marginLeft: Platform.OS === 'ios' ? -10 : -4,
        height: 50,
    }
});

export default styles

export const mangoGreen = '#44A97F'
export const blue = '#56CCF2'
export const darkBlue = '#2F80ED'
export const darkGreen = '#27AE60'
export const grey = '#828282'
export const borderGrey = '#D3D3D3'
export const lightGrey = '#E6E6E6'
export const red = '#EB5757'
export const yellow = '#e3b93e'
export const normalText = 16
export const smallText = 14
export const tinyText = 12

// Auth
export const iconStyle = {
    color: 'white',
};

export const inputStyle = {
    color: 'white',
    fontSize: normalText,
};

export const darkInputStyle = {
    color: 'dark',
    fontSize: normalText,
};

export const smallInputStyle = {
    color: 'white',
    fontSize: smallText,
};

// Menu
export const titleStyle = {
    textAlign: 'center',
    color: '#222222',
    fontSize: 14,
    fontWeight: '500',
};

// Approve Doc
export const smallTextStyle = {
    fontSize: smallText,
};

export const tinyTextStyle = {
    fontSize: tinyText,
};

export const smallTextBoldStyle = {
    fontSize: tinyText,
    fontWeight: 'bold',
};

export const bg_header = {
    shadowColor: "#000",
    shadowOffset: {
        width: 0,
        height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
    backgroundColor: '#0F1E43',
};
export const bg_logo = {

    padding: 12,
    borderRadius: 50,
    marginRight: 10,
    marginTop: 10
};
export const btn_save = {
    width: '100%',
    backgroundColor: '#0F1E43',
    borderRadius: 0,
    // borderRightWidth: 1,
    // borderColor: '#fff'
    // height: 50,
    // marginLeft: 30,
    // marginRight: 30
    
};
export const btn_revise = {
    width: '100%',
    backgroundColor: '#0F1E43',
    borderRadius: 0,
    borderLeftWidth: 1,
    borderColor: '#fff'
    
};
export const btn_text = {
    color: 'white',
    fontSize: 18,
    paddingVertical: 10
};
export const menu_QCM = {
    flexDirection: 'column',
    justifyContent: 'space-around'
};
export const customCard = {
    shadowColor: "#000",
    shadowOffset: {
        width: 0,
        height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    marginLeft: 10,
    marginRight: 10,
    borderRadius: 10,
    padding: 0
};
export const block_title = {
    paddingHorizontal: 15,
    paddingVertical: 10,
};
export const clear_card = {
    padding: 0 ,
    marginBottom: 0,
     marginTop: 0
};
export const checklist_btn = {
    width: '20%',
     justifyContent: 'center',
      backgroundColor: '#fff',
       borderRadius: 0
};