﻿import React, { Component } from 'react';
import { StyleSheet, View, TouchableOpacity, TextInput, SafeAreaView, FlatList } from 'react-native'
import { Container, Header, Title, Button, Body, Icon, Text, Footer, FooterTab, Badge } from 'native-base';
import { apiAuth } from '../../api/authentication'
import AsyncStorage from '@react-native-async-storage/async-storage';
import HomeLayout from '../../layouts/home_layout';
import SearchInput, { createFilter } from 'react-native-search-filter';
import Spinner from 'react-native-loading-spinner-overlay';
import { UserSVG } from '../../svg/IconSVG';
import Moment from 'moment';
import {
    inputStyle,
    mangoGreen,
    smallTextStyle,
    smallInputStyle,
    bg_logo,
    bg_header,
    btn_text,
} from "../../stylesheet/styles";
import {
    getReadList,
} from "../../api/qcm";

//Screen
import CheckListScreen from "../Tabs/all_project.js"
import AddDocumentScreen from "../Tabs/add_documents.js"
import GrouptScreen from "../Tabs/group.js"
import ChartScreen from "../Tabs/chart.js"
import NotificationScreen from "../Tabs/notification.js"

class Home extends Component {
    constructor(props) {
        super(props)

        this.state = {
            activeTab: 0
        }
    }

    _changeTab = async (activeTab) => {
        await this.setState({ activeTab })
    }

    _renderContent = () => {
        if (this.state.activeTab === 0) {
            return (<CheckListScreen navigation={this.props.navigation} />)
            return null
        }
        else if (this.state.activeTab === 1) {
            return (<AddDocumentScreen navigation={this.props.navigation} />)
        }
        else if (this.state.activeTab === 2) {
            return (<ChartScreen navigation={this.props.navigation} />)
        }
        else if (this.state.activeTab === 3) {
            return (<GrouptScreen navigation={this.props.navigation} />)
        }
        else if (this.state.activeTab === 4) {
            return (<NotificationScreen navigation={this.props.navigation} />)
        }
        else {
            return null
        }
    }

    render() {
        return (
            <HomeLayout>
                <Container>
                    {this._renderContent()}
                    <Footer>
                        <FooterTab
                            style={{ backgroundColor: '#0F1E43' }}
                        >
                            <Button
                                style={{ backgroundColor: this.state.activeTab == 0 ? '#FFFFFF' : null }}
                                badge={true} onPress={() => { this._changeTab(0) }} active={this.state.activeTab === 0}>
                                <Badge>
                                    <Text>2</Text>
                                </Badge>
                                <Icon
                                    style={{ color: this.state.activeTab == 0 ? '#000' : '#fff' }}
                                    type="FontAwesome" name="check-square-o" />
                            </Button>
                            <Button
                                style={{ backgroundColor: this.state.activeTab == 1 ? '#FFFFFF' : null }}
                                onPress={() => { this._changeTab(1) }} active={this.state.activeTab === 1}>
                                <Icon
                                    style={{ color: this.state.activeTab == 1 ? '#000' : '#fff' }}
                                    type="FontAwesome" name="plus-square-o" />
                            </Button>
                            <Button
                                style={{ backgroundColor: this.state.activeTab == 2 ? '#FFFFFF' : null }}
                                onPress={() => { this._changeTab(2) }} active={this.state.activeTab === 2}>
                                <Icon
                                    style={{ color: this.state.activeTab == 2 ? '#000' : '#fff' }}
                                    type="FontAwesome" name="bar-chart" />
                            </Button>
                            <Button
                                style={{ backgroundColor: this.state.activeTab == 3 ? '#FFFFFF' : null }}
                                onPress={() => { this._changeTab(3) }} active={this.state.activeTab === 3}>
                                <Icon
                                    style={{ color: this.state.activeTab == 3 ? '#000' : '#fff' }}
                                    type="FontAwesome" name="users" />
                            </Button>
                            <Button
                                style={{ backgroundColor: this.state.activeTab == 4 ? '#FFFFFF' : null }}
                                badge={true} onPress={() => { this._changeTab(4) }} active={this.state.activeTab === 4}>
                                <Badge>
                                    <Text>2</Text>
                                </Badge>
                                <Icon
                                    style={{ color: this.state.activeTab == 4 ? '#000' : '#fff' }}
                                    type="FontAwesome" name="bell-o" />
                            </Button>
                        </FooterTab>
                    </Footer>
                </Container>
            </HomeLayout >
        );
    }
}
const styles = StyleSheet.create({
    contentContainer: {
        paddingVertical: 60
    },
    pickerContainer: {
        backgroundColor: '#E6E6E6',
        height: 32,
        paddingHorizontal: 10,
        borderRadius: 5,
    },
    blockSearch: {
        position: 'absolute',
        right: 5,
        width: 40,
        height: 68,
        marginVertical: 8,
        backgroundColor: mangoGreen,
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        borderRadius: 5,
    },
    btnSearch: {
        color: '#fff',
        fontSize: 22,

    },
});
export default Home