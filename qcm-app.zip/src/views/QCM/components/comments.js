import React, { Component } from 'react';
import { StyleSheet, Alert, View, Image, TouchableOpacity, ScrollView, TextInput, KeyboardAvoidingView, Platform, TouchableWithoutFeedback, Keyboard, SafeAreaView } from 'react-native'
import { Container, Root, Header, Title, Content, Footer, FooterTab, Button, Left, Right, Body, Icon, Text, Badge, Card, CardItem, H1, List, ListItem, Thumbnail, Switch, Tab, Tabs, TabHeading, ActionSheet, Item, Input } from 'native-base';
import { Circle } from 'react-native-svg';
import SvgPanZoom, { SvgPanZoomElement } from 'react-native-svg-pan-zoom';
import { LinearGradient } from 'expo-linear-gradient';
import { GiftedChat } from 'react-native-gifted-chat'
import Moment from 'moment';
import linq from 'js-linq';
import { BackSVG, ListSVG, FileSVG, DocSVG, LicenseSVG, OptionSVG, ChatSVG, BinSVG } from '../../../svg/IconSVG';
import {
    borderGrey,
    darkGreen,
    iconStyle,
    inputStyle,
    mangoGreen,
    red,
    grey,
    smallTextStyle,
    bg_header,
    btn_save,
    btn_text,
    menu_QCM,
    customCard,
    block_title,
    smallText,
    titleStyle,
    tinyTextStyle,
    smallInputStyle,
    blue,
    darkBlue,
    bgHeader
} from "../../../stylesheet/styles";

import {
    postComment,
    getCheckList,
    reFormatPicture,
    removeComment,
} from "../../../api/qcm";
import $xt from '../../../api/xtools';

const $linq = arr => new linq(arr);

var BUTTONS = ["ไม่ตรวจ", "รูปภาพ", "หมายเหตุ", "ยกเลิก"];
var DESTRUCTIVE_INDEX = 3;
var CANCEL_INDEX = 4;

class Comments extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            messages: [],
            comment: [],
            description: '',
            docno: '',
            count: 0
        };
    }
    _PostComment = async () => { 
        console.log("sdfsdf", this.state.comment);
        let i = $linq(this.state.comment).count() +1;
        console.log("num", i);
        let data = {
            data:{
                pre_event: this.props.route.params.params._pre_event,
                plan_code: this.props.route.params.plan.plan_code,
                task_comments: this.state.description,
                taskid: this.props.route.params.params._loccode,
                itemno: i,
            }
        }
        // console.log("DATA", data);
        await postComment(data);

        await this.loadComment();
        this.scrollView.scrollToEnd({ animated: true });
        //this.setData(); 
    }
    async loadComment() {
        console.log("LOADDATA")
        let _docno = this.props.route.params.params._docno;
        let _pre_event = this.props.route.params.params._pre_event;
        let _loccode = this.props.route.params.params._loccode;
        let _form_code = this.props.route.params.params._form_code;
        let _form_type = this.props.route.params.params._form_type;
        //await this.props.route.Loading();
        let docs = [];
        docs = await getCheckList({ docno: _docno, pre_event: _pre_event, loccode: _loccode, form_code: _form_code, form_type: _form_type });
        await this.createFilePath(docs.data.comment);
        this.setState({ comment: docs.data.comment, count: $linq(docs.data.comment).count(), description: "" });
    }
    async createFilePath(data) {
        for (let xx in data) {
            let x = data[xx];
            if (!$xt.isEmpty(x.pathpic)) {
                x.pathpic = await reFormatPicture(x.pathpic);
            }
            else {
                x.pathpic = "https://cdn4.vectorstock.com/i/1000x1000/39/33/super-star-typographic-design-lettering-vector-21483933.jpg";
            }
        }
    }
    async deleteComment(itemno) {
        let pre_event = this.props.route.params.params._pre_event;
        let plan_code = this.props.route.params.plan.plan_code;
        let taskid = this.props.route.params.params._loccode;

        console.log("DELETE", itemno, pre_event, plan_code, taskid );
        await removeComment({ itemno, pre_event, plan_code, taskid });
        await this.loadComment();
    }
    async setData() {
        await this.loadComment();
        // await this.createFilePath(this.props.route.params.dataFromParent);
        // await this.setState({ comment: this.props.route.params.dataFromParent, count: $linq(this.props.route.params.dataFromParent).count(), description: "" })
    }
    // componentDidMount() {
    //     // this.setData();
    //     // console.log(this.props);
    // }
    async UNSAFE_componentWillMount() {
        await this.setData();
    }
    // componentWillMount() {
    //     this.setData();
    //     console.log(this.props);
    // }
    Header = () => (
        <Header transparent iosBarStyle={"light-content"} style={[bg_header, { flexDirection: 'row', width: '100%', alignItems: 'center' }]}>
            <View style={{ width: '20%' }} >
                <Button transparent
                    style={{ width: '100%', justifyContent: 'flex-start' }}
                    onPress={() => this.props.navigation.goBack()}>
                    <BackSVG />
                </Button>
            </View>
            <Body style={{ width: '70%', alignItems: 'center', paddingVertical: 15 }}>
                <Title style={btn_text}>QCM</Title>
            </Body>

            <View style={{ width: '20%' }}>
                <Button transparent
                    style={{ width: '100%', justifyContent: 'flex-end' }}>
                </Button>
            </View>
        </Header>
    )
    render() {
        // console.log("COMMENT", this.state.comment);
        return (
            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : null}
                style={{ flex: 1, backgroundColor: '#fff' }}
            >
                <Container>
                    {this.Header()}
                    <Text style={[block_title, { fontWeight: '600' }]}>เลขที่เอกสาร: <Text style={{ fontWeight: '100' }}>{this.props.route.params.docno}</Text></Text>
                    <Text style={block_title}>ความคิดเห็น <Text>{this.state.count}</Text><Text> รายการ</Text></Text>
                    <SafeAreaView style={{ flex: 1 }}>
                        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
                            <View style={{ flex: 1, justifyContent: 'space-between' }}>
                                <ScrollView ref={ref => { this.scrollView = ref }}>
                                    {(this.state.comment).map((item, i) => (
                                        <View key={i}>
                                            <List>
                                                <ListItem avatar>
                                                    <Left>
                                                        {/* <Thumbnail source={{ uri: 'https://cdn4.vectorstock.com/i/1000x1000/39/33/super-star-typographic-design-lettering-vector-21483933.jpg' }} /> */}
                                                        <Thumbnail source={{ uri: item.pathpic }} />
                                                    </Left>
                                                    <Body>
                                                        <Text>{item.add_user}</Text>
                                                        <Text note>{item.description}</Text>
                                                    </Body>
                                                    <Right>
                                                        <Text note>{Moment(item.add_dt).format('DD/MM/YYYY h:mm a')}</Text>
                                                        <TouchableOpacity onPress={() => this.deleteComment(item.itemno)} style={{ backgroundColor: "red" }}>
                                                            <BinSVG />
                                                        </TouchableOpacity>
                                                    </Right>
                                                </ListItem>
                                            </List>
                                        </View>
                                    ))}
                                </ScrollView>
                                <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'flex-end', paddingHorizontal: 15, paddingVertical: 10, backgroundColor: "#FFF" }}>
                                    <Item rounded style={{ paddingHorizontal: 10, backgroundColor: 'rgba(86, 204, 242, 0.15)', width: '90%' }}>
                                        {/*<Input placeholder='เขียนข้อความ'/>*/}
                                        <TextInput
                                            style={{ paddingVertical: 10, width: '100%' }}
                                            placeholder='เขียนข้อความ'
                                            onChangeText={(text) => this.setState({ description: text })}
                                            value={this.state.description} />
                                    </Item>
                                    <Button transparent onPress={() => { this._PostComment() }}><Icon type="FontAwesome" name="arrow-right"></Icon></Button>
                                </View>
                            </View>
                        </TouchableWithoutFeedback>
                    </SafeAreaView>
                </Container>
            </KeyboardAvoidingView>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    inner: {
        padding: 24,
        flex: 1,
        justifyContent: "flex-end",
    },
    header: {
        fontSize: 36,
        marginBottom: 48,
    },
    input: {
        height: 40,
        borderColor: "#000000",
        borderBottomWidth: 1,
        marginBottom: 36,
    },
    btnContainer: {
        backgroundColor: "blue",
        marginTop: 12,
    },
});
export default Comments