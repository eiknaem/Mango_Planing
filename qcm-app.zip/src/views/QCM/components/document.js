﻿import React, { Component } from 'react';
import { StyleSheet, Alert, View, Image, TouchableOpacity, ScrollView, Linking, Dimensions, Share, Platform } from 'react-native'
import { Container, Root, Header, Title, Content, Footer, FooterTab, Button, Left, Right, Body, Icon, Text, Badge, Card, CardItem, H1, List, ListItem, Thumbnail, Switch, Tab, Tabs, TabHeading, ActionSheet, Item, Input } from 'native-base';
import { Circle } from 'react-native-svg';
import SvgPanZoom, { SvgPanZoomElement } from 'react-native-svg-pan-zoom';
import { LinearGradient } from 'expo-linear-gradient';
import { GiftedChat } from 'react-native-gifted-chat';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { WebView } from 'react-native-webview';
import linq from 'js-linq';
import $xt from "../../../api/xtools";
import { useFocusEffect } from '@react-navigation/native';
// import Pdf from 'react-native-pdf';

import {
    borderGrey,
    darkGreen,
    iconStyle,
    inputStyle,
    mangoGreen,
    red,
    grey,
    smallTextStyle,
    bg_header,
    btn_save,
    btn_text,
    menu_QCM,
    customCard,
    block_title,
    smallText,
    titleStyle,
    tinyTextStyle,
    smallInputStyle,
    blue,
    darkBlue,
    bgHeader
} from "../../../stylesheet/styles";
import {
    getCheckList,
    getResults
} from "../../../api/qcm";
import { ReloadInstructions } from 'react-native/Libraries/NewAppScreen';
import PDFReader from 'rn-pdf-reader-js'

const { width, height } = Dimensions.get('window');
const $linq = arr => new linq(arr);

class Document extends React.Component {

    webView = null;
    constructor(props) {
        super(props)
        this.state = {
            loading: false,
            currentTab: 0,
            _calculat: [],
            showQCType: false,
            loadTab: false,
        };
    }
    async UNSAFE_componentWillMount() {
    }
    componentWillUnmount() {
        // fix Warning: Can't perform a React state update on an unmounted component
        this.setState = (state, callback) => {
        
            return;
        };
   
    }

    componentDidMount = async () => {
        // let basePath = await AsyncStorage.getItem('basePath') || ''
        let baseUrl = await AsyncStorage.getItem('baseUrl') || ''
        let mango_auth = await AsyncStorage.getItem('mango_auth') || ''
        let session = await AsyncStorage.getItem('session') || ''
        let auth2 = await AsyncStorage.getItem('auth') || ''
        let auth = JSON.parse(auth2)
        // console.log("auth", auth);

        // let session_id = await AsyncStorage.getItem('session_id') || ''
        // this.setState({ basePath: basePath, baseUrl: baseUrl })
        // await this.calculateCheckList();

        let docs = [];
        docs = this.props.documents
        let _form_area = (docs.data.form_area || "")
        let _vender = (docs.data.vendor || "")
        let _checker = (docs.data.check || "")
        let _me = (docs.data.me || "")
        let _approve = (docs.data.approve || "")
        let _foreman = (docs.data.foreman || "")
        let _docno = (docs.data.header.docno || "")
        let _task = (docs.data.task || "")
        let _plan = (docs.data.plan || "")
        let showQCType = (docs.data.form_data.qc_type || "") != "1" ? true : false

        //FONTEND
        //let printFromWeb = basePath + "page_qcm/print/v_qcc_print_001?docno=" + this.state.docno + "&pre_event2=" + this.state.pre_event2 + "&loccode=" + this.state.loccode + "&form_code=" + this.state.form_code + "&plantform=APP"
        //let printFromWeb = basePath + "page_qcm/print/v_qcc_print_002?token=" + mango_auth + "&docno="+ _docno 

        //BACKEND
        //let printFromWeb = baseUrl + "printApi/document/create?token=" + mango_auth + "&module=QCC&groupcode=PN&doccode=QC001&docno=" + _docno + "&new_program=Y"

        let printFromWeb = baseUrl + "PrintApi/Document/QcAppResultView?docno=" + _docno + "&session_id=" + auth.session_id + "&maincode=" + auth.maincode;
        // console.log("PRINT", printFromWeb);
 console.log("global.isSaved", global.isSaved);
        this.setState({
            baseUrl: baseUrl,
            form_code: docs.data.header.form_code,
            docno: docs.data.header.docno,
            form_type: docs.data.header.form_type,
            check_item: docs.data.header.check_item,
            wo_no: docs.data.header.wo_no,
            paid_period: docs.data.header.paid_period,
            qc_resuult: docs.data.header.qc_resuult,
            approve_status: docs.data.header.approve_status,
            project_data: docs.data.project_data.pre_des,
            unit_data: docs.data.unit_data.pre_des,
            pre_event2: docs.data.header.pre_event2,
            loccode: docs.data.header.loccode,
            planning_progress_per: docs.data.header.planning_progress_per,
            period: _form_area.period,
            vendor: _vender.cust_name,
            checker: !$xt.isEmpty(docs.data.header.check_empno) ? _checker.empfullname_t : "-",
            approve: !$xt.isEmpty(docs.data.header.approve_empno) && docs.data.header.approve_status == "Y" ? _approve.empfullname_t : "-",
            foreman: _foreman.empfullname_t,
            planname: _plan.planname,
            task: _task.taskname,
            printFromWeb: printFromWeb,
            showQCType: showQCType,
        })
        // await this._changeTab(1);
    };
    _changeTab = async (activeTab) => {
        console.log("เอกสาร", activeTab, "this.webView", this.webView);
        // await this.setState({ activeTab })
        // Tab 0 ข้อมูลเอกสาร |  Tab 1 สรุปผล 
        if (activeTab == 1) {
            console.log("1", this.state.printFromWeb);
            // this.webview.reload();
            this, this.setState({ loadTab: true,  printFromWeb: this.state.printFromWeb, })
        }
        if (activeTab === 1 && this.webView) {
            this.webView.reload();
            console.log("2");
        }
        this.setState({ currentTab: activeTab })
    }
    resultColor = () => {
        switch (this.state.showQCType) {
            case true:
                if (this.props.pass_check_pers == 100) {
                    return "green";
                } else {
                    return "red";
                }
                break;
            case false:
                if (this.props.pass_total_pers == 100) {
                    return "green";
                } else {
                    return "red";
                }
                break;
        }
        // if(this.props.pass_total_pers == 100) {
        //     return "green"
        // } else {
        //     return "red"
        // }
    }
    _result = () => {
        switch (this.state.showQCType) {
            case true:
                if (this.props.pass_check_pers == 100) {
                    return "Y";
                } else {
                    return "N";
                }
                break;
            case false:
                if (this.props.pass_total_pers == 100) {
                    return "Y";
                } else {
                    return "N";
                }
                break;
        }

        // if(this.props.pass_total_pers == 100) {
        //     return "Y"
        // } else {
        //     return "N"
        // }
    }
    WebViewContainer = () => {
        return <WebView
            source={{ uri: `https://reactnative.dev/` }}
        />
    }
    onShare = async () => {
        try {
            const result = await Share.share({
                message:
                    'React Native | A framework for building native apps using React',
            });
            if (result.action === Share.sharedAction) {
                if (result.activityType) {
                    // shared with activity type of result.activityType
                } else {
                    // shared
                }
            } else if (result.action === Share.dismissedAction) {
                // dismissed
            }
        } catch (error) {
            alert(error.message);
        }
    };
    render() {
        return (
            // onChangeTab={({ i }) => this._changeTab(i)}
            <Tabs
                tabBarUnderlineStyle={{ height: 0 }}

                locked onChangeTab={({ i }) => this._changeTab(i)}>
                <Tab
                    heading={
                        <TabHeading
                            style={[this.state.currentTab == 0 ? styles.activeTabStyle : styles.inactiveTabStyle, { flexDirection: 'column', paddingVertical: 10 }]}>
                            <Text style={[this.state.currentTab == 0 ? styles.activeTabStyle : styles.inactiveTabStyle, { fontWeight: '300', fontSize: 15 }]}>ข้อมูลเอกสาร</Text>
                        </TabHeading>} >
                    <ScrollView style={{ padding: 10, borderTopColor: '#0F1E43', borderTopWidth: 1 }}>
                        {/* {this.renderCalculate()} */}
                        <Text>ชื่อโครงการ : <Text>{this.state.project_data}</Text></Text>
                        <Text>ชื่อแผนงาน : <Text>{this.state.planname}</Text></Text>
                        <Text>ชื่องาน : <Text>{this.state.task}</Text></Text>
                        {/* <Text>Plan : <Text>{this.state.unit_data}</Text></Text> */}
                        {/* <Text>Task Name : <Text>A0010</Text><Text>{this.state.locname != null ? this.state.locname : ""}</Text></Text> */}
                        <Text>รหัสแบบฟอร์มตรวจ : <Text>{this.state.form_code}</Text></Text>
                        <Text>รหัสเอกสาร : <Text>{this.state.docno}</Text></Text>
                        {/* <Text>ประเภทการตรวจ : <Text>{this.state.form_type == "C" ? "ลูกค้าตรวจ" : "ตรวจผู้รับเหมา"}</Text></Text> */}
                        {/* <Text>งวดตรวจ : <Text>{this.state.period}</Text></Text> */}
                        <Text>จุดตรวจงาน : <Text>{this.state.planning_progress_per}%</Text></Text>
                        {/* <Text>ตรวจครั้งที่ : <Text>{this.state.check_item}</Text></Text> */}
                        {/* <Text>ผู้รับเหมา : <Text>{this.state.vendor}</Text></Text> */}
                        {/* <Text>เลขที่เอกสารสั่งจ้าง : <Text>{this.state.wo_no}</Text></Text> */}
                        {/* <Text>งวดจ่าย : <Text>{this.state.paid_period}</Text></Text> */}
                        <Text>ผู้ตรวจ : <Text>{this.state.checker}</Text></Text>
                        <Text>ผู้อนุมัติตรวจ : <Text>{this.state.approve}</Text></Text>
                        {/* <Text>ผู้ควบคุมงาน : <Text>{this.state.foreman}</Text></Text> */}
                        <Text>ผลตรวจ :  <Text style={{ color: this.resultColor() }}>{this._result() == "Y" ? "ผ่านแล้ว" : "ยังไม่ผ่าน"}</Text></Text>
                        <Text>จำนวนข้อตรวจทั้งหมด : <Text>{this.props.total_items}</Text></Text>
                        <Text>จำนวนข้อที่ตรวจ  : <Text>{this.props.qc_total_counts}</Text></Text>
                        <Text>จำนวนข้อที่ตรวจผ่าน : <Text>{this.props.qc_pass_counts}</Text></Text>
                        <Text>%ผ่าน เทียบกับข้อตรวจทั้งหมด : <Text>{this.props.pass_total_pers}</Text></Text>
                        <Text>%ผ่าน เทียบกับข้อตรวจเท่าที่ตรวจ : <Text>{this.props.pass_check_pers}</Text></Text>
                        {/* <Text>ผลตรวจ : <Text>{this.state.qc_resuult == 'Y' ? "ผ่าน" : 'ไม่ผ่าน'}</Text></Text> */}
                        <Text>อนุมัติผลตรวจ : <Text>{this.state.approve_status == "Y" ? "อนุมัติผล" : "รออนุมัติผลการตรวจ"}</Text></Text>
                    </ScrollView>

                </Tab>
                <Tab
                    heading={
                        <TabHeading
                            style={[this.state.currentTab == 1 ? styles.activeTabStyle : styles.inactiveTabStyle, { flexDirection: 'column', paddingVertical: 10 }]}>
                            <Text style={[this.state.currentTab == 1 ? styles.activeTabStyle : styles.inactiveTabStyle, { fontWeight: '300', fontSize: 15 }]}>สรุปผล</Text>
                        </TabHeading>} >
                    <View style={{ flex: 1, padding: 10, borderTopColor: '#0F1E43', borderTopWidth: 1 }}>
                        {this.state.loadTab &&
                            <WebView
                                ref={ref => (this.webview = ref)}
                                cacheEnabled={false}
                                cacheMode={'LOAD_NO_CACHE'}
                                incognito={true}
                                source={{
                                    uri: this.state.printFromWeb
                                }}
                                style={{ width: width }}

                            />}
                        {/* <PDFReader
                            source={{
                                uri: this.state.printFromWeb,
                            }}
                            withPinchZoom={true}
                        /> */}
                    </View>
                </Tab>

            </Tabs>

        )
    }
}
const styles = StyleSheet.create({
    pickerContainer: {
        backgroundColor: '#E6E6E6',
        height: 32,
        paddingHorizontal: 10,
        borderRadius: 5,
    },
    cardDetail: {
        height: 50,
    },
    preview: {
        width: "100%",
        height: 200,
        //   backgroundColor: "#F8F8F8",
        justifyContent: "center",
        alignItems: "center",
        marginTop: 15
    },
    previewText: {
        color: "#FFF",
        fontSize: 14,
        height: 40,
        lineHeight: 40,
        paddingLeft: 10,
        paddingRight: 10,
        //   backgroundColor: "#69B2FF",
        width: 120,
        textAlign: "center",
        marginTop: 10
    },
    activeTabStyle: {
        backgroundColor: '#FFFFFF',
        color: '#000',
    },
    inactiveTabStyle: {
        backgroundColor: '#0F1E43',
        color: '#ffffff'
    }
})
export default Document