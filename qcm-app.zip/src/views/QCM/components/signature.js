import React, { Component } from 'react';
import { StyleSheet, View, Image, TouchableOpacity } from 'react-native'
import {  Body, Text, Card, CardItem } from 'native-base';
import Signature, { readSignature, clearSignature } from 'react-native-signature-canvas';
import * as FileSystem from 'expo-file-system';
import $xt from "../../../api/xtools";
import MessageBox from "../../../api/msg";
import {
  addSignature
} from "../../../api/qcm";
import {

  customCard,
  block_title,
} from "../../../stylesheet/styles";
class SignatureSc extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      image: "",
      signature: "",
      showModalSave: false
    };
  }

  componentDidMount = async () => {
    // console.log("PROPS SIGNATURE", this.props);
    this.createFilePath();
  };
  //////////////////////////// Signature /////////////////////////////////////
  handleSignature = signature => {
    // console.log("PROPS", this.props);
    const path = FileSystem.cacheDirectory + 'sign.png';
    FileSystem.writeAsStringAsync(path, signature.replace('data:image/png;base64,', ''), { encoding: FileSystem.EncodingType.Base64 }).then(res => {
      console.log(res);

      FileSystem.getInfoAsync(path, { size: true, md5: true }).then(file => {

        this.setState({ signature: file.uri });
        // console.log("APPROVE",this.props.configApprove)
        this._updateSignature();

      })
    }).catch(err => {
      console.log("err", err);
    })
  };

  handleEmpty = () => {
    console.log('Empty');
  }

  handleClear = () => {
    console.log('clear success!');
  }
  handleEnd = () => {
    // console.warn("handleEnd");
    ref.current.readSignature();
  }
  _signature = () => {
    const webStyle = `
    body{
      background: none;
    }
    .m-signature-pad{
      height: 100%;
    }
    .m-signature-pad--footer
    .button {
      background-color: #0F1E43;
      color: #FFF;
    }`;
    return <Signature
      onBegin={this.handleBegin}
      // onEnd={this.handleEnd}
      onOK={this.handleSignature}
      onEmpty={this.handleEmpty}
      onClear={this.handleClear}
      penColor={"black"}
      backgroundColor={"white"}
      autoClear={true}
      descriptionText=""
      clearText="ยกเลิก"
      confirmText="ยืนยัน"
      webStyle={webStyle}
    />
  }
  onSave = async () => {
    let config = this.props.configApprove;
    if (!$xt.isEmpty(config)) {
      if (config.active == "Y") {
        // console.log("SUBMIT APPROVE");
        this.props.navigation.push('SubmitApprove',
          {
            params: this.props.params,
            header: this.props.header
          })
      }
    }
    await this.props.Loading();
    await this.createFilePath();
    this.setState({showModalSave: false})
  }
  showStatusSave = () => {
    if (this.state.showModalSave) {
      return (
        <View
          style={{
            flex: 1,
            position: "absolute",
            left: 0,
            right: 0,
            top: 0,
            height: "100%",
            zIndex: 1,
          }}
        >
          <View style={{ backgroundColor: "rgba(0,0,0,0.5)", flex: 1, alignItems: 'center', justifyContent: 'center' }}>

            <View
              style={{
                // flex: 1,
                justifyContent: "center",
                alignItems: "center",
                backgroundColor: '#0F1E43',
                paddingVertical: 30,
                borderRadius: 5,
                width: '80%',
                textAlign: 'center'
              }}
            >
              <Text style={{ color: '#fff', fontSize: 24 }}>บันทึกข้อมูลเรียบร้อยแล้ว</Text>
              <TouchableOpacity
                transparent
                style={{
                  marginVertical: 15,
                  backgroundColor: "#fff",
                  borderRadius: 5,
                  paddingVertical: 7.5,
                  paddingHorizontal: 20
                }}
                onPress={() => {
                  this.onSave();
                }}
              >
                <Text
                  style={{
                    color: "#0F1E43",
                    textAlign: "center",
                    fontSize: 23,
                  }}
                >
                  ตกลง
                  </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      );
    } else {
      return <View />;
    }
  };
  _updateSignature = async () => {
    // console.warn("this.state.signature", this.state.signature);
    let res = {
      file: this.state.signature,
      docno: this.props.docno,
    }
    try {
      let resp = await addSignature(res);
      if (!resp.success) {
        throw resp.error
      }
      this.setState({ showModalSave: true })
    }
    catch (ex) {
      MessageBox.Alert(`Error`, ex.toString());
      console.log(ex.toString());
    }
  }

  createFilePath = async () => {
    let file_path = this.props.sig_qc;
    console.log("file_path", file_path);
    let axioscustom2 = await $xt.axiosMangoCreate();
    let error = null;
    if (file_path != "") {
      let c = await axioscustom2.get(`Api/File/DownLoad?id=${file_path}`, { headers: { 'Access-Control-Allow-Origin': '*' } });
      let img_path = c.request._url
      console.log("img_path", img_path);
      this.setState({ signature_file: c.request._url })
    }
  }
  renderItem = () => {
    // console.log(this.props.approve_status);
    if (this.props.approve_status == "W" && $xt.isEmpty(this.props.sig_qc)) {
      return (
        <View style={{ flex: 1 }} >
          <Text style={block_title}>ลายเช็นรับมอบ</Text>
          {
            this._result() == "Y" ?
              this._signature() :
              <Card transparent >
                <CardItem style={customCard}>
                  <Body>
                    <View style={{ flexWrap: "wrap", flexDirection: "row", textAlign: "center", minHeight: 100 }}>
                      <Text style={{ flex: 1, alignItems: 'center', textAlign: 'center', justifyContent: 'center', paddingTop: 30 }}>ผลตรวจ ต้องผ่านก่อน</Text>
                    </View>
                  </Body>
                </CardItem>
              </Card>
          }
        </View>
      )
    }
    else if(this.props.approve_status == "Y" || (this.props.approve_status == "W" && !$xt.isEmpty(this.props.sig_qc))) {
      return (
        <View style={{ flex: 1 }} >
          <Card transparent >
            <CardItem style={customCard}>
              <Body>
                <Image source={{ uri: this.state.signature_file }} style={{ width: "100%", height: "90%", justifyContent: "center" }}></Image>
              </Body>
            </CardItem>
          </Card>
        </View>
      )
    }
    else {
      return (
        <Card transparent >
          <CardItem style={customCard}>
            <Body>
              <View style={{ flexWrap: "wrap", flexDirection: "row", textAlign: "center", minHeight: 100 }}>
                <Text style={{ flex: 1, alignItems: 'center', textAlign: 'center', justifyContent: 'center', paddingTop: 30, fontSize: 18 }}>ผลตรวจต้องผ่านก่อน</Text>
              </View>
            </Body>
          </CardItem>
        </Card>
      )
    }



  }
  _result = () => {
    // console.log("qc_total_counts",this.state.qc_total_counts); 
    if (this.props.qc_total_counts == this.props.qc_pass_counts && this.props.qc_total_counts != "undefined" && this.props.qc_total_counts != 0) {
      return "Y"
    } else {
      return "N"
    }
  }
  /////////////////////////////////end Signature ///////////////////////
  render() {
    let { signature } = this.state;
    return (
      <View style={{ flex: 1 }}>
        {this.showStatusSave()}
        <View style={{}}>
          <Text style={[block_title, { fontWeight: '600', fontFamily: 'KanitLight' }]}>เลขที่เอกสาร: <Text style={{ fontWeight: '100' }}>{this.props.docno}</Text></Text>
        </View>
        {this.renderItem()}
      </View>
    )
  }
}

const styles = StyleSheet.create({
  cardDetail: {
    height: 50,
  },
  preview: {
    width: "100%",
    height: 200,
    //   backgroundColor: "#F8F8F8",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 15
  },
  previewText: {
    color: "#FFF",
    fontSize: 14,
    height: 40,
    lineHeight: 40,
    paddingLeft: 10,
    paddingRight: 10,
    //   backgroundColor: "#69B2FF",
    width: 120,
    textAlign: "center",
    marginTop: 10
  }
});

export default SignatureSc