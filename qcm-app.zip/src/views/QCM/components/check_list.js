import React, { Component } from "react";
import {
  View,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  FlatList,
} from "react-native";
import {
  Content,
  Button,
  Icon,
  Text,
  Switch,
  Fab,
} from "native-base";
import { ScrollView } from "react-native-gesture-handler";
import MessageBox from "../../../api/msg";
import linq from "js-linq";
import $xt from "../../../api/xtools";
import { OptionSVG, DeleteSVG } from "../../../svg/IconSVG";
import Svg, {  Circle } from "react-native-svg";

import {
  block_title,
} from "../../../stylesheet/styles";
import { getCheckList } from "../../../api/qcm";
const $linq = (arr) => new linq(arr);
class Checklist extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      refreshing: false,
      spinner: false,
      checkStatus: "",
      unCheckStatus: "",
      disableBtn: false,
      beforeSaveModalShow: false,
      onCreateListShow: false,
      historyModalShow: false,
      showRemarkError: false,
      showQCType: false,
      remark: "",
      activeTab: 0,
      shownDocList: [],
      selectedDoc: {},
      image: "",
      signature: "",
      chosenDate: new Date(),
      resultShow: false,
      currentTab: 0,
      isEnabled: false,
      active: false,
      due_date: new Date(),
      saveButton: false,
    };
  }
  componentDidMount = async () => {
    // console.log("PARAMS INDEX", this.props.docno);
    await this.loadDocList();
    // await this.checkApprove();
  };
  checkApprove = async () => {
    //Header = this.state.docHeader
    let _approve_status = this.state.docHeader.approve_status;
    let _sendapp = this.state.docHeader.sendapp;
    let _docapp = this.state.docHeader.docapp;
    //this.props.route.params
    let _docno = this.props.route.params.docno;
    let _pre_event2 = this.props.route.params.pre_event2;
    let _pre_event = this.props.route.params.pre_event;
    let _loccode = this.props.route.params.loccode;
    let _form_code = this.props.route.params.form_code;
    let _form_type = this.props.route.params.form_type;
    let _type_period = this.props.route.params.type_period;

    let arr = {
      _docno: _docno,
      _pre_event2: _pre_event2,
      _pre_event: _pre_event,
      _loccode: _loccode,
      _form_code: _form_code,
      _form_type: _form_type,
    };

    if (_approve_status == "W" && _sendapp != "Y" && $xt.isEmpty(_docapp)) {
      let messageBox = await MessageBox.Confirm(
        `Warning`,
        `${_docno} ส่งอนุมัติแล้ว ไปยังหน้า Submit Approve หรือไม่?`,
        `ยกเลิก`,
        `ตกลง`
      );
      if (messageBox) {
        this.props.navigation.push("SubmitApprove", { params: arr });
      }
    } else if (_approve_status == "W" && _sendapp == "Y" && _docapp == "N") {
      let messageBox = await MessageBox.Alert(
        `Warning`,
        `${_docno} อยู่ในระหว่างอนุมัติ`
      );
      if (messageBox) {
        // this.props.navigation.push('All_project');
      }
    } else {
    }
  };
  loadDocList = async () => {
    this.setState({ refreshing: true });
    console.log("PROPS", this.props);
    let _docno = this.props.docno;
    let _pre_event2 = this.props.pre_event2;
    let _pre_event = this.props.pre_event;
    let _loccode = this.props.loccode;
    let _form_code = this.props.form_code;
    let _form_type = this.props.form_type;
    let _type_period = this.props.type_period;
    console.log("TYPE_PERIOD", _type_period);
    let docs = [];

    docs = await getCheckList({
      docno: _docno,
      pre_event: _pre_event,
      loccode: _loccode,
      form_code: _form_code,
      form_type: _form_type,
    });

    if (docs.error) {
      MessageBox.Alert(`Error`, docs.error, `OK`);
      return;
    }

    let _approve_status = docs.data.header.approve_status;
    let _sendapp = docs.data.header.sendapp;
    let _docapp = docs.data.header.docapp;
    let arr = {
      _docno: _docno,
      _pre_event2: _pre_event2,
      _pre_event: _pre_event,
      _loccode: _loccode,
      _form_code: _form_code,
      _form_type: _form_type,
      _approve_status: _approve_status,
      _sendapp: _sendapp,
      _docapp: _docapp,
    };

    ////////////
    console.log("APPROVE", docs.data);
    ////////////
    this.reformatDocList(docs.data.detail, docs.data.form_data.qc_type);
    this.setState({
      refreshing: false,
      docHeader: docs.data.header,
      sig_qc: docs.data.header.sig_qc_result || "",
      approve_status: docs.data.header.approve_status,
      sendapp: docs.data.header.sendapp,
      docapp: docs.data.header.docapp,
      _docno: _docno,
      _docs: docs,
      comment: docs.data.comment,
      file: docs.data.file,
      plan: docs.data.plan,
      obj: arr,
      // showQCType: docs.data.form_data.qc_type != "1" ? true : false,
      approveAppQCM: docs.data.approveAppQCM,
      _type_period: _type_period,
    });
  };

  reformatDocList = async (docList, qc_type) => {
    //////////////////
    if (qc_type != "1") {
      $linq(docList).foreach((x) => {
        x.node_number = x.item_number = x.itemno;
        x.check_item = "Y";
        x.item_name = x.remark;
      });
    }
    //////////////////
    this.setState({
      shownDocList: docList,
      showQCType: qc_type != "1" ? true : false,
    });
    this.calculateCheckList();
    await this.findParentNocal();
  };
  _setTitleList = (title, item) => {
    item.item_name = title;
    this.setState({ titleList: title });
  };
  _checkList = (item, type) => {
    this.setState({ selectedDoc: item });
    if (type === "check") {
      item.item_result = "Y";
      // this.setState({ showStatus: item.item_result });
    } else if (type === "uncheck") {
      item.item_result = "N";
      // this.setState({ showStatus: item.item_result });
    }
    item.check_date = new Date();
    this.setState({ showStatus: item.item_result }); //check_date: new Date()
    // this.setState({ shownDocList: docList });
    // this._renderStatusBG(item.item_result, type)
    // console.log("shownDocList", this.state.shownDocList);
    this.calculateCheckList();
  };
  _result = () => {
    // console.log("qc_total_counts",this.state.qc_total_counts);
    switch (this.state.showQCType) {
      case true:
        if (this.state.pass_check_pers == 100) {
          this.state.saveButton = true;
          return "Y";
        } else {
          this.state.saveButton = false;
          return "N";
        }
      // break;
      case false:
        if (this.state.pass_total_pers == 100) {
          this.state.saveButton = true;
          return "Y";
        } else {
          this.state.saveButton = false;
          return "N";
        }
      // break;
    }
  };
  resultColor = () => {
    switch (this.state.showQCType) {
      case true:
        if (this.state.pass_check_pers == 100) {
          return "green";
        } else {
          return "red";
        }
        break;
      case false:
        if (this.state.pass_total_pers == 100) {
          return "green";
        } else {
          return "red";
        }
        break;
    }
  };
  _renderStatusBG = (item, type) => {
    // console.log("item",this.state.selectedDoc);
    if (item.no_cal == "Y") {
      return "#E0E0E0";
    }

    if (item.item_result == "Y" && type == "check") {
      // console.log("check");
      return "#00B473";
    } else if (item.item_result == "N" && type == "uncheck") {
      // console.log("uncheck");
      return "#FF7878";
    } else {
      return "white";
      // console.log("none");
    }
  };
  renderItem = ({ item }) => {
    let approve_status = this.state.approve_status;
    return this.state.showQCType ? (
      <ScrollView style={{ paddingHorizontal: 15, paddingVertical: 15 }}>
        <View
          style={{
            marginLeft: 20,
            borderBottomWidth: 1,
            paddingVertical: 15,
            borderBottomColor: "#C4C4C4",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              width: "100%",
              paddingRight: 40,
            }}
          >
            <Text style={{ fontSize: item.item_type == "H" ? 18 : 16 }}>
              {/* {item.item_number}.{" "} */}
              {item.itemno}
            </Text>
            <TextInput
              style={{
                height: 40,
                borderColor: "#d3d3d3",
                borderWidth: 1,
                paddingHorizontal: 10,
                marginVertical: 5,
                width: "90%",
                borderRadius: 5,
              }}
              onChangeText={(text) => this._setTitleList(text, item)}
              placeholder="ระบุหัวข้อตรวจ"
            >
              <Text style={{ color: "#8f9bb3" }}>{item.item_name}</Text>
            </TextInput>
            <TouchableOpacity
              transparent
              onPress={() =>
                this.props.navigation.push("AdditionalMenu", {
                  docno: this.state._docno,
                  approve_status: this.state.approve_status,
                  item_number: item.item_number,
                  check_date: item.check_date || null,
                  score: item.score || null,
                  remark: this.state.showQCType ? item.item_name : item.remark,
                  itemUpdate: this.itemUpdate,
                  showQCType: this.state.showQCType,
                  type_period: this.state._type_period,
                })
              }
              style={{ position: "absolute", right: 0, top: 5 }}
            >
              <OptionSVG />
            </TouchableOpacity>
          </View>
          <View
            style={{ flexDirection: "row", justifyContent: "space-evenly" }}
          >
            <Button
              transparent
              disabled={
                item.no_cal == "Y" || approve_status != "D" ? true : false
              }
              onPress={() => {
                this._checkList(item, "check");
              }}
            >
              <Svg width="25" height="25" viewBox="0 0 20 20" fill="none">
                <Circle
                  cx="10"
                  cy="10"
                  r="9.5"
                  fill={this._renderStatusBG(item, "check")}
                  stroke="black"
                />
              </Svg>
              <Text style={{ marginLeft: -10, color: "#01D663" }}>ผ่าน</Text>
              <Text
                style={{
                  marginLeft: -20,
                  color: "#01D663",
                  textAlign: "left",
                }}
              ></Text>
            </Button>
            <Button
              transparent
              disabled={
                item.no_cal == "Y" || approve_status != "D" ? true : false
              }
              onPress={() => {
                this._checkList(item, "uncheck");
              }}
            >
              <Svg width="25" height="25" viewBox="0 0 20 20" fill="none">
                <Circle
                  cx="10"
                  cy="10"
                  r="9.5"
                  fill={this._renderStatusBG(item, "uncheck")}
                  stroke="black"
                />
              </Svg>
              <Text style={{ marginLeft: -10, color: "#FF7878" }}>ไม่ผ่าน</Text>
              <Text
                style={{
                  marginLeft: -20,
                  color: "#FF7878",
                  textAlign: "left",
                }}
              ></Text>
            </Button>
            <Button
              transparent
              style={{ paddingHorizontal: 10, position: "absolute", right: 0 }}
              onPress={() => {
                this._removeList(item);
              }}
            >
              <DeleteSVG />
            </Button>
          </View>
        </View>
      </ScrollView>
    ) : (
      <View style={{ paddingHorizontal: 15 }}>
        {item.item_type != "D" ? (
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              width: "100%",
              borderBottomWidth: 1,
              borderBottomColor: "#C4C4C4",
              paddingVertical: 15,
            }}
          >
            <Text
              style={{
                fontSize: item.item_type == "H" ? 18 : 16,
                width: "75%",
              }}
            >
              {item.item_number}.{" "}
              <Text
                style={{
                  fontWeight: "600",
                  fontSize: item.item_type == "H" ? 18 : 16,
                }}
              >
                {item.item_name}
              </Text>
            </Text>
            <View
              style={{
                alignItems: "center",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "flex-start",
                width: 100,
              }}
            >
              <Switch
                disabled={approve_status != "D" ? true : false}
                trackColor={{ false: "#51b84f", true: "#767577" }}
                thumbColor={item.no_cal == "Y" ? "#fff" : "#fff"}
                ios_backgroundColor="#51b84f"
                onValueChange={() => {
                  this.doNoCal(item, item.no_cal);
                }}
                value={item.no_cal == "Y" ? true : false}
              />
              <View style={{ alignItems: "center", justifyContent: "center" }}>
                <Text style={{ marginLeft: 10, fontSize: 15, color: "#000" }}>
                  {item.no_cal == "Y" ? "ไม่ตรวจ" : "ตรวจ"}
                </Text>
              </View>
            </View>
          </View>
        ) : (
          <View
            style={{
              marginLeft: 20,
              borderBottomWidth: 1,
              paddingVertical: 15,
              borderBottomColor: "#C4C4C4",
            }}
          >
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                width: "100%",
                paddingRight: 40,
              }}
            >
              <View style={{}}>
                <Text style={{ fontSize: item.item_type == "H" ? 18 : 16 }}>
                  {item.item_number}.{" "}
                  <Text
                    style={{
                      fontWeight: "600",
                      fontSize: item.item_type == "H" ? 18 : 16,
                    }}
                  >
                    {item.item_name}
                  </Text>
                </Text>
              </View>
              <TouchableOpacity
                transparent
                onPress={() =>
                  this.props.navigation.push("AdditionalMenu", {
                    docno: this.state._docno,
                    approve_status: this.state.approve_status,
                    item_number: item.item_number,
                    check_date: item.check_date || null,
                    score: item.score || null,
                    remark: this.state.showQCType
                      ? item.item_name
                      : item.remark,
                    itemUpdate: this.itemUpdate,
                    showQCType: this.state.showQCType,
                    type_period: this.state._type_period,
                  })
                }
                style={{ position: "absolute", right: 0, top: -10 }}
              >
                <OptionSVG />
              </TouchableOpacity>
            </View>
            <View style={{ flexDirection: "row", flex: 1 }}>
              <View style={{ flexDirection: "row", flex: 1 }}>
                <View
                  style={{ alignItems: "center", justifyContent: "center" }}
                >
                  <Switch
                    disabled={approve_status != "D" ? true : false}
                    trackColor={{ false: "#51b84f", true: "#767577" }}
                    thumbColor={item.no_cal == "Y" ? "#fff" : "#fff"}
                    ios_backgroundColor="#51b84f"
                    onValueChange={() => {
                      this.doNoCal(item, item.no_cal);
                    }}
                    value={item.no_cal == "Y" ? true : false}
                  />
                </View>
                <View
                  style={{
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 30,
                  }}
                >
                  <Text style={{ marginLeft: 10, fontSize: 15, color: "#000" }}>
                    {item.no_cal == "Y" ? "ไม่ตรวจ" : "ตรวจ"}
                  </Text>
                </View>
              </View>
              <View style={{ flexDirection: "row", width: 200 }}>
                <Button
                  transparent
                  style={{ width: "40%" }}
                  disabled={
                    item.no_cal == "Y" || approve_status != "D" ? true : false
                  }
                  onPress={() => {
                    this._checkList(item, "check");
                  }}
                >
                  <Svg width="25" height="25" viewBox="0 0 20 20" fill="none">
                    <Circle
                      cx="10"
                      cy="10"
                      r="9.5"
                      fill={this._renderStatusBG(item, "check")}
                      stroke="black"
                    />
                  </Svg>
                  <Text style={{ marginLeft: -10, color: "#01D663" }}>
                    ผ่าน
                  </Text>
                  <Text
                    style={{
                      marginLeft: -20,
                      color: "#01D663",
                      width: "80%",
                      textAlign: "left",
                    }}
                  ></Text>
                </Button>
                <Button
                  transparent
                  style={{ width: "50%" }}
                  disabled={
                    item.no_cal == "Y" || approve_status != "D" ? true : false
                  }
                  onPress={() => {
                    this._checkList(item, "uncheck");
                  }}
                >
                  <Svg width="25" height="25" viewBox="0 0 20 20" fill="none">
                    <Circle
                      cx="10"
                      cy="10"
                      r="9.5"
                      fill={this._renderStatusBG(item, "uncheck")}
                      stroke="black"
                    />
                  </Svg>
                  <Text style={{ marginLeft: -10, color: "#FF7878" }}>
                    ไม่ผ่าน
                  </Text>
                  <Text
                    style={{
                      marginLeft: -20,
                      color: "#FF7878",
                      width: "80%",
                      textAlign: "left",
                    }}
                  ></Text>
                </Button>
              </View>
            </View>
          </View>
        )}
      </View>
    );
  };
  List = () => (
    <SafeAreaView
      style={{  flex: 1, marginHorizontal: 7 }}
    >
      <FlatList
        ref={(ref) => {
          this.flatListRef = ref;
        }}
        contentContainerStyle={{ marginBottom: 65 }}
        extraData={this.state.refreshing}
        data={this.state.shownDocList}
        onRefresh={this.loadDocList}
        refreshing={this.state.refreshing}
        initialNumToRender={10} // Reduce initial render amount
        maxToRenderPerBatch={5} // Reduce number in each render batch
        windowSize={3} // Reduce the window size
        renderItem={this.renderItem}
        keyExtractor={(item, index) => index.toString()}
      />
    </SafeAreaView>
  );
  createCheckList = async () => {
    var _tem_number = $linq(this.state.shownDocList).count();
    var setItem_number = _tem_number + 1;
    var newList = {
      check_item: "Y",
      item_result: "N",
      itemno: setItem_number,
      item_number: setItem_number,
      node_number: setItem_number,
      revise: 1,
    };
    await this.setState({
      shownDocList: [...this.state.shownDocList, ...[newList]],
    });
    this.flatListRef.scrollToEnd({ animated: true });
    this.calculateCheckList();
    // console.log("create", this.state.shownDocList);
  };
  calculateCheckList = () => {
    let pmm = new Promise((rs, rj) => {
      let q = $linq(this.state.shownDocList);
      //total item
      let total_item = q
        .where((x) => x.check_item === "Y" && x.no_cal !== "Y")
        .count();
      //total  item per
      let total_item_per = $xt.dec(
        q
          .where((x) => x.check_item === "Y" && x.no_cal !== "Y")
          .sum((x) => x.item_per || 0) || 0,
        2
      );

      //total check item
      let qc_total_count = q
        .where((x) => !$xt.isEmpty(x.item_result) && x.no_cal !== "Y")
        .count();
      let qc_total_per = $xt.dec(
        q
          .where((x) => !$xt.isEmpty(x.item_result) && x.no_cal !== "Y")
          .sum((x) => x.item_per || 0) || 0,
        2
      );
      //total pass count
      let qc_pass_count = q
        .where((x) => x.item_result === "Y" && x.no_cal !== "Y")
        .count();
      // pass per
      let pass_per = $xt.dec(
        q
          .where((x) => x.item_result === "Y" && x.no_cal !== "Y")
          .sum((x) => x.item_per || 0),
        2
      );

      let pass_check_per = 0;
      let pass_total_per = 0;
      let _result = "";
      // let saveButton = false;

      if (this.state.showQCType) {
        //ตรวจอิสระ
        pass_total_per =
          total_item == 0 ? 0 : $xt.dec((qc_total_count / total_item) * 100, 2);
        pass_check_per =
          qc_total_count == 0
            ? 0
            : $xt.dec((qc_pass_count / qc_total_count) * 100, 2);

        //Check Save Button & qc_resuult
        if (this.state.pass_check_per == 100) {
          this.state.saveButton = true;
          _result = "Y";
        } else {
          this.state.saveButton = false;
          _result = "N";
        }
      } else {
        pass_total_per =
          pass_per == 0 ? 0 : $xt.dec((pass_per / total_item_per) * 100, 2);
        pass_check_per =
          qc_total_count == 0 ? 0 : $xt.dec((pass_per / qc_total_per) * 100, 2);

        //Check Save Button & qc_resuult
        if (this.state.pass_total_pers == 100) {
          this.state.saveButton = true;
          _result = "Y";
        } else {
          this.state.saveButton = false;
          _result = "N";
        }
      }

      this.setState({
        // saveButton: saveButton,
        qc_resuult: _result,
        total_items: total_item, //จำนวนข้อตรวจทั้งหมด
        qc_total_counts: qc_total_count, //จำนวนข้อที่ตรวจ
        qc_pass_counts: qc_pass_count, //จำนวนข้อที่ตรวจผ่าน
        pass_total_pers: pass_total_per, // % ผ่าน เทียบกับข้อตรวจทั้งหมด
        pass_check_pers: pass_check_per, // % ผ่าน เทียบกับข้อตรวจเท่าที่ตรวจ
      });

      rs();
    });
    pmm.then(() => {});
  };
  findParentNocal() {
    $linq(this.state.shownDocList)
      .where((x) => x.no_cal === "Y")
      .foreach((x) => {
        x.parent_no_cal =
          !x.parent ||
          $linq(this.state.shownDocList).any(
            (y) => y.node_number === x.parent && y.no_cal !== "Y"
          )
            ? "Y"
            : null;
      });
  }
  render() {
    return (
      <View style={{  }}>
        {/* ******************************** Card list Head*************************** */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            paddingRight: 10,
            justifyContent: "space-between",
          }}
        >
          <Text style={[block_title, { fontWeight: "600", width: "80%" }]}>
            เลขที่เอกสาร:{" "}
            <Text style={{ fontWeight: "100" }}>{this.props.docno}</Text>
          </Text>
          <Text style={{ color: this.resultColor(), fontWeight: "100" }}>
            {this._result() == "Y" ? "ผ่านแล้ว" : "ยังไม่ผ่าน"}
          </Text>
        </View>
        {/* <KeyboardAvoidingView
          behavior={Platform.OS == "ios" ? "padding" : null}
          keyboardVerticalOffset={Platform.OS == "ios" ? 150 : null}
        > */}
          <Content style={{ flex: 1 }}>{this.List()}</Content>
        {/* </KeyboardAvoidingView> */}
        {this.state.showQCType ? (
          <Fab
            active={this.state.active}
            direction="up"
            containerStyle={{}}
            style={{ backgroundColor: "#0F1E43" }}
            position="bottomLeft"
            onPress={() => this.createCheckList()}
          >
            <Icon name="add" />
          </Fab>
        ) : null}
      </View>
    );
  }
}

export default Checklist;
