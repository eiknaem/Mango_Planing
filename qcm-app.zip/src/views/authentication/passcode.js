﻿import React, { Component } from 'react';
import { StyleSheet, Alert, View, Image, Dimensions, ImageBackground } from 'react-native'
import { Container, Header, Footer, FooterTab, Body, Right, Left, Title, Content, Form, Item, Input, Label, Button, Text, Thumbnail } from 'native-base';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Spinner from 'react-native-loading-spinner-overlay';
import MessageBox from '../../api/msg'
import $xt from '../../api/xtools'
import { apiPasscode } from '../../api/authentication'
import styles from '../../stylesheet/styles'
import { Asset } from 'expo-asset';
import AuthLayout from '../../layouts/auth_layout'
import logo from '../../../assets/icon_back.png';
import main_bg from '../../../assets/main_bg.png';

import my_theme from '../../stylesheet/theme_selector'

let mytheme = {};

export default class Passcode extends Component {
    constructor(props) {
        super(props);

        this.state = {
            isProcess: false,
            spinner: false,
            passcode: '',
        };
    }

    async UNSAFE_componentWillMount() {
        mytheme = await my_theme.update()
    }

    async componentDidMount() {
        await AsyncStorage.setItem('baseUrl', '')
        await AsyncStorage.setItem('baseUrl', 'mango_auth')
        let passcode = await AsyncStorage.getItem('passcode') || ''
        this.setState({ passcode })
    }

    _doNext = async () => {
        if (this.state.isProcess) return;
        let passcode = (this.state.passcode || '').toUpperCase().trim();
        this.setState({ passcode })

        this.setState({ isProcess: true })
        try {
            if ($xt.isEmpty(passcode)) {
                throw `Please Enter Company Code.`
            }

            let rsp = await apiPasscode.getIP(passcode);
            if (rsp.error) {
                throw rsp.error
            }

            await AsyncStorage.setItem('workplaces', JSON.stringify(rsp.data))
            await AsyncStorage.setItem('passcode', passcode)

            this.props.navigation.replace('LoginScreen')

            //console.log(await AsyncStorage.getItem('workplaces'))
        } catch (ex) {
            MessageBox.Alert(`Error`, ex.toString());
        }

        this.setState({ isProcess: false })
    }

    render() {
        return (
            <AuthLayout>
                <Container style={{ flex: 1 }}>
                    <Content style={[mytheme.backgroundColor, { flex: 1 },]}>
                        <View style={{ flex: 1, margin: 20 }}>
                            <View style={stylesLocal.container}>
                                <Thumbnail
                                    large
                                    style={stylesLocal.logo}
                                    source={logo}
                                />
                                <Text style={[{ fontWeight: 'bold', fontSize: 16, }, mytheme.fontColor]}>สวัสดี! ยินดีต้อนรับสู่ Mango QCM</Text>
                                <Text style={[{ marginTop: 25 }, mytheme.fontColor]}>เพื่อดำเนินการต่อโปรดป้อนรหัสบริษัท (Passcode)</Text>
                            </View>
                            <Form style={{ flex: 1, margin: 0 }}>
                                <Item stackedLabel style={[styles.input]}>

                                    <Input
                                        value={this.state.passcode}
                                        onChangeText={(passcode) => this.setState({ passcode })}
                                        placeholder={"Enter your passcode"}
                                        style={
                                            [mytheme.fontColor]
                                        } />
                                </Item>
                                <View style={[{ marginTop: 30 }]}>
                                    <Button rounded block success onPress={this._doNext} disabled={this.state.isProcess}>
                                        <Text>ดำเนินการต่อ</Text>
                                    </Button>
                                </View>
                            </Form>
                        </View>
                    </Content>
                    {
                        //<Footer>
                        //    <FooterTab>
                        //        <Button success full onPress={this._doNext} disabled={this.state.isProcess}>
                        //            <Text style={{ color: 'white' }}>Continue</Text>
                        //        </Button>
                        //    </FooterTab>
                        //</Footer>
                    }
                    <Spinner visible={this.state.spinner} />
                </Container>
            </AuthLayout>
        );
    }
}

const stylesLocal = StyleSheet.create({
    container: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 40,
        marginBottom: 20,
    },
    logo: {
        //width: 70,
        //height: 70,
        marginBottom: 20,
    }
});