import React, { Component } from 'react';
import { StyleSheet, Alert, View, Image } from 'react-native'
import { Container, Root, Header, Title, Content, Footer, FooterTab, Button, Left, Right, Body, Icon, Text, Badge, Card, CardItem, H1, List, ListItem, Thumbnail, Switch } from 'native-base';
import { Circle } from 'react-native-svg';

//React Navigation
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

class Chart extends Component {
  constructor(props) {
    super(props)
  }
  _camPress = () => this.props.navigation.push('cam', {
  });
  _drawPress = () => this.props.navigation.push('draw', {
  });
  _filePress = () => this.props.navigation.push('showfile', {
  });
  render() {
    return (
      <Body>
        <H1 style={{ flex: 1, paddingVertical: '50%', textAlign: 'center' }}> COMMING SOON</H1>
      </Body>
    );
  }
}

export default Chart