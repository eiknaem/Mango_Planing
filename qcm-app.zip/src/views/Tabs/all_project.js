import React, { Component } from "react";
import {
  StyleSheet,
  View,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  FlatList,
  RefreshControl
} from "react-native";
import {
  Container,
  Header,
  Title,
  Button,
  Body,
  Icon,
  Text,
  Tab,
  Tabs,
} from "native-base";
import { apiAuth } from "../../api/authentication";
import AsyncStorage from "@react-native-async-storage/async-storage";
import HomeLayout from "../../layouts/home_layout";
import SearchInput, { createFilter } from "react-native-search-filter";
import Spinner from "react-native-loading-spinner-overlay";
import { UserSVG } from "../../svg/IconSVG";
import Moment from "moment";
import {
  inputStyle,
  mangoGreen,
  smallTextStyle,
  smallInputStyle,
  bg_logo,
  bg_header,
  btn_text,
} from "../../stylesheet/styles";
import { getReadList } from "../../api/qcm";
import $xt from "../../api/xtools";
class All_project extends Component {
  constructor(props) {
    super(props);

    this.state = {
      spinner: false,
      title: "",
      remarkModalShow: false,
      selectedDocMenu: "all",
      docType: [{ key: 0, label: "All Documents" }],
      selectedDocType: "All Documents",
      refreshing: false,
      docList: [],
      shownDocList: [],
      remark: "",
      selectedDoc: {}, // for tracking when remark submit
      showRemarkError: false,
      projectData: [{ key: 0, label: "All Projects" }],
      selectedProject: "All Projects",
      searchDoc: "",
      searchPj: "",
      approve_status: "",
      filterS2: [],
      status: "N",
      docNo: ""
    };
  }

  async UNSAFE_componentWillMount() { }

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }
  componentDidMount = async () => {
    this.setState({ status: "N" });
    await this.loadDocList();
  };

  loadDocList = async () => {
    this.setState({ refreshing: true });
    let docs = [];
    docs = await getReadList(this.state.status);
    // console.log("DATA", docs.data);
    this.reformatDocList(docs.data);
    this.setState({ refreshing: false });
  };
  _changeTab = async (activeTab) => {
    this.setState({ spinner: true });
    let docs = [];
    if (activeTab == 1) {
      this.setState({ status: "Y" });
      docs = await getReadList("Y");
    } else {
      this.setState({ status: "N" });
      docs = await getReadList("N");
    }
    this.setState({ spinner: false });
    this.reformatDocList(docs.data);
  };
  reformatDocList = (docList) => {
    // console.log("DOCLIST", docList);
    this.setState({ shownDocList: docList });
    this.setState({ filterS2: docList });
  };
  Header = () => (
    <Header
      transparent
      iosBarStyle={"light-content"}
      style={[
        bg_header,
        { flexDirection: "row", width: "100%", alignItems: "center" },
      ]}
    >
      <View style={{ width: "20%" }}>
        <Button
          transparent
          style={{ width: "100%", justifyContent: "flex-start" }}
          onPress={() => this.props.navigation.push("SettingScreen")}
        >
          <UserSVG />
        </Button>
      </View>
      <Body style={{ width: "70%", alignItems: "center", paddingVertical: 7.5 }}>
        <Title style={btn_text}>QCM</Title>
      </Body>

      <View style={{ width: "20%" }}>
        <Button
          transparent
          style={{ width: "100%", justifyContent: "flex-end" }}
        ></Button>
      </View>
    </Header>
  );
  FilterBar = () => (
    <View
      style={{
        backgroundColor: "#0F1E43",
        width: "100%",
        height: 90,
        position: "relative",
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          marginTop: 2,
          marginBottom: 5,
          paddingTop: 5,
        }}
      >
        <View style={{ flex: 4, flexDirection: "row" }}>
          <View style={{ flex: 1, alignItems: "center" }}>
            <Icon style={{ color: "#fff" }} name="business" />
          </View>
          <View style={{ flex: 6, paddingRight: 10 }}>
            <TextInput
              ref={input => { this.textInput2 = input }}
              style={styles.pickerContainer}
              placeholder="Project Name"
              placeholderTextColor="grey"
              value={this.state._searchPj}
              onChangeText={(project) => {
                this.searchUpdated2(project);
              }}
            />
          </View>
          <View
            style={{
              flex: 1,
              alignItems: "center",
              position: "absolute",
              right: 20,
            }}
          >
            <Icon
              style={{ color: "grey" }}
              name="ios-search"
              size={15}
              color="#000"
            />
          </View>
        </View>
      </View>
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          marginTop: 2,
          marginBottom: 5,
        }}
      >
        <View style={{ flex: 4, flexDirection: "row" }}>
          <View style={{ flex: 1, alignItems: "center" }}>
            <Icon style={{ color: "#fff" }} name="document" />
          </View>
          <View style={{ flex: 6, paddingRight: 10 }}>
            <TextInput
            ref={input => { this.textInput = input }}
              style={styles.pickerContainer}
              placeholder="Doc No."
              placeholderTextColor="grey"
              value={this.state._searchDoc}
              onChangeText={(docNo) => {
                this.searchUpdated(docNo);
              }}
            />
          </View>
          <View
            style={{
              flex: 1,
              alignItems: "center",
              position: "absolute",
              right: 20,
            }}
          >
            <Icon
              style={{ color: "grey" }}
              name="ios-search"
              size={15}
              color="#000"
            />
          </View>
        </View>
      </View>
    </View>
  );

  checkFormType = (form_type) => {
    switch (form_type) {
      case "V":
        return "QC";
        break;
      case "C":
        return "DF";
        break;
      case "Q":
        return "QC";
        break;
      case "W":
        return "WO";
        break;
      case "P":
        return "PN";
        break;
    }
    // return "PN";
  };
  _formTypeBG = (form_type) => {
    switch (form_type) {
      case "V":
        return "#E2F3FF";
        break;
      case "C":
        return "#e8b990";
        break;
      case "Q":
        return "#E2F3FF";
        break;
      case "W":
        return "#e8b990";
        break;
      case "P":
        return "#B7FFF2";
        break;
    }
    // return "#B7FFF2";
  };
  renderItem = ({ item }) => {
    return (
      <TouchableOpacity
        style={{
          backgroundColor: "white",
          padding: 10,
          borderBottomWidth: 1,
          borderBottomColor: "#C4C4C4",
        }}
        onPress={() =>
          this.props.navigation.push("QCM", {
            docno: item.docno,
            pre_event2: item.pre_event2,
            pre_event: item.pre_event,
            loccode: item.loccode,
            form_code: item.form_code,
            form_type: item.form_type,
            type_period: item.type_period ?? "N",
          })
        }
      // onPress={() =>
      //     this.props.navigation.push('SubmitApprove',
      //         {
      //             docno: item.docno,
      //             pre_event2: item.pre_event2,
      //             pre_event: item.pre_event,
      //             loccode: item.loccode,
      //             form_code: item.form_code,
      //             form_type: item.form_type,
      //         })
      // }
      >
        <View
          style={{
            position: "relative",
            flexDirection: "row",
            alignItems: "flex-start",
            justifyContent: "space-between",
            width: "100%",
            marginBottom: 15,
            paddingTop: 10,
          }}
        >
          <View style={{ position: "absolute" }}>
            <View
              style={[
                bg_logo,
                { backgroundColor: this._formTypeBG(item.form_type) },
              ]}
            >
              <Text style={[inputStyle, { fontSize: 20, color: "#000" }]}>
                {this.checkFormType(item.form_type)}
              </Text>
            </View>
          </View>
          <View style={{ marginLeft: 65 }}>
            <Text style={{ fontSize: 16 }}>{item.docno}</Text>
            <Text style={[smallTextStyle, { color: "#4F4F4F" }]}>
              {Moment(item.doc_date).format("DD/MM/YYYY")}
            </Text>
          </View>
          <View style={{ justifyContent: "flex-end" }}>
            <View
              style={{
                borderTopLeftRadius: 5,
                borderBottomLeftRadius: 5,
                marginRight: -10,
                backgroundColor:
                  item.approve_status == "Y"
                    ? "#c1f5d9"
                    : item.approve_status == "W"
                      ? "#FFFF99"
                      : item.approve_status == "D"
                        ? "#F79F1F"
                        : "#FFE1DA",
              }}
            >
              <Text
                style={{
                  fontWeight: "600",
                  textAlign: 'center',
                  paddingHorizontal: 30,
                  paddingVertical: 10,

                  color:
                    item.approve_status == "Y"
                      ? "#01D663"
                      : item.approve_status == "W"
                        ? "#CD8500"
                        : item.approve_status == "D"
                          ? "#fff"
                          : "#DB0404",
                }}
              >
                {item.approve_status == "Y"
                  ? "ผ่าน"
                  : item.approve_status == "W"
                    ? "รออนุมัติ"
                    : item.approve_status == "D"
                      ? "อยู่ระหว่างพิจารณา"
                      : "ไม่ผ่าน"}
              </Text>
            </View>
          </View>
        </View>
        <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
          {/* <View style={{ width: '100%', flexDirection: 'row', paddingBottom: 5 }}>
                        <Text style={[smallTextStyle, { width: 110, color: '#001B7A' }]}>บริษัท : </Text><Text style={{ width: '75%', fontSize: 14, color: '#4F4F4F' }}>{item.mainname}</Text>
                    </View> */}
          <View
            style={{ width: "100%", flexDirection: "row", paddingBottom: 5 }}
          >
            <Text style={[smallTextStyle, { width: 110, color: "#001B7A" }]}>
              ชื่อโครงการ :{" "}
            </Text>
            <Text
              style={{
                width: "75%",
                fontSize: 14,
                color: "#000000",
                fontWeight: "600",
              }}
            >
              {item.pre_des}
            </Text>
          </View>
          <View
            style={{ width: "100%", flexDirection: "row", paddingBottom: 5 }}
          >
            <Text
              style={[
                smallTextStyle,
                { width: 110, color: "#001B7A", fontSize: 14 },
              ]}
            >
              ชื่อแผนงาน :{" "}
            </Text>
            <Text style={{ width: "75%", color: "#4F4F4F", fontSize: 14 }}>
              {item.planname}
            </Text>
          </View>
          <View
            style={{ width: "100%", flexDirection: "row", paddingBottom: 5 }}
          >
            <Text
              style={[
                smallTextStyle,
                { width: 110, color: "#001B7A", fontSize: 14 },
              ]}
            >
              ชื่องาน :{" "}
            </Text>
            <Text style={{ width: "75%", color: "#4F4F4F", fontSize: 14 }}>
              {item.taskname}
            </Text>
          </View>
          <View
            style={{ width: "100%", flexDirection: "row", paddingBottom: 5 }}
          >
            <Text
              style={[
                smallTextStyle,
                { width: 110, color: "#001B7A", fontSize: 14 },
              ]}
            >
              ชื่อฟอร์ม :{" "}
            </Text>
            <Text style={{ width: "75%", color: "#4F4F4F", fontSize: 14 }}>
              {item.form_name}
            </Text>
          </View>
          {/* <View style={{ width: '100%', flexDirection: 'row', paddingBottom: 5  }}>
                        <Text style={[smallTextStyle, { width: 110, color: '#001B7A' }]}>โครงการ : </Text><Text style={{ width: '75%', fontSize: 14, color: '#000000', fontWeight: "600" }}>{item.pre_des}</Text>
                    </View> */}
          <View
            style={{ width: "100%", flexDirection: "row", paddingBottom: 5 }}
          >
            <Text style={[smallTextStyle, { width: 110, color: "#001B7A" }]}>
              ผู้ตรวจ :{" "}
            </Text>
            <Text style={{ width: "75%", color: "#4F4F4F", fontSize: 14 }}>
              {item.check_name}
            </Text>
          </View>
          <View
            style={{ width: "100%", flexDirection: "row", paddingBottom: 5 }}
          >
            <Text style={[smallTextStyle, { width: 110, color: "#001B7A" }]}>
              จุดตรวจงาน :{" "}
            </Text>
            <Text style={{ width: "75%", color: "#4F4F4F", fontSize: 14 }}>
              {item.planning_progress_per}%
            </Text>
          </View>
          {!$xt.isEmpty(item.remark_cancel) ? (
            <View
              style={{ width: "100%", flexDirection: "row", paddingBottom: 5 }}
            >
              <View
                style={{
                  backgroundColor: "#ffb8b8",
                  paddingHorizontal: 5,
                  borderRadius: 3,
                }}
              >
                <Text
                  style={[smallTextStyle, { width: 120, color: "#c23616" }]}
                >
                  หมายเหตุการปฏิเสธ :{" "}
                </Text>
              </View>

              <Text
                style={{
                  width: "75%",
                  color: "#c23616",
                  paddingLeft: 5,
                  fontSize: 14,
                }}
              >
                {item.remark_cancel}
              </Text>
            </View>
          ) : null}
        </View>
      </TouchableOpacity>
    );
  };
  searchUpdated(Doc) {
    // console.log(Doc);
    this.setState({ searchDoc: Doc });
    const filterS = this.state.shownDocList.filter(
      createFilter(Doc, ["docno"])
    );
    const filterS2 = filterS.filter(
      createFilter(this.state.searchPj, ["pre_des"])
    );
    this.setState({ filterS2: filterS2 });
  }
  searchUpdated2(project) {
    console.log("project", project);
    this.setState({ searchPj: project });
    const filterS = this.state.shownDocList.filter(
      createFilter(this.state.searchDoc, ["docno"])
    );
    const filterS2 = filterS.filter(createFilter(project, ["pre_des"]));
    this.setState({ filterS2: filterS2 });
  }
  _handleRefresh = async () => {
    this.textInput.clear()
    this.textInput2.clear()
    this.setState({ searchPj: "", searchDoc: ""})
    // await this.searchUpdated("") 
    // await this.searchUpdated2("")
    await this.loadDocList()
  }
  List = () => (
    <SafeAreaView style={{ flex: 1 }}>
      <FlatList
        ref={(ref) => {
          this.flatListRef = ref;
        }}
        contentContainerStyle={{ paddingBottom: 65 }}
        extraData={this.state.refreshing}
        data={this.state.filterS2}
        initialNumToRender={10} // Reduce initial render amount
        maxToRenderPerBatch={5} // Reduce number in each render batch
        windowSize={3} // Reduce the window size
        renderItem={this.renderItem}
        keyExtractor={(item, index) => index.toString()}
        refreshControl={
          <RefreshControl
            refreshing={this.state.refreshing}
            onRefresh={this._handleRefresh}
          />
        }
      />
    </SafeAreaView>
  );

  render() {
    return (
      <HomeLayout>
        <Container>
          {this.Header()}
          {this.FilterBar()}
          <Body>
            <Spinner
              visible={this.state.spinner}
              color={"blue"}
              textContent={"Please wait..."}
              textStyle={smallInputStyle}
            />
            <View style={{ flex: 1 }}>
              {/* ************************************** Data Content******************************* */}
              <Tabs
                scrollWithoutAnimation={true}
                tabContainerStyle={{ backgroundColor: "#0F1E43", elevation: 0 }}
                activeTabContainerStyle={{ backgroundColor: "#FFFFFF" }}
                locked
                onChangeTab={({ i }) => this._changeTab(i)}
                tabBarUnderlineStyle={{ height: 0 }}
              >
                <Tab
                  heading="อยู่ระหว่างดำเนินการ"
                  tabStyle={{
                    backgroundColor: "#0F1E43",
                    borderBottomStartRadius: 20,
                  }}
                  textStyle={{ color: "#fff" }}
                  activeTabStyle={{
                    backgroundColor: "#FFFFFF",
                    borderTopLeftRadius: 20,
                    borderTopEndRadius: 20,
                  }}
                  activeTextStyle={{ color: "#000000", fontWeight: "normal" }}
                >
                  {this.List()}
                  {/* ******************************** Card list *************************** */}
                </Tab>
                <Tab
                  heading="เสร็จสิ้น"
                  tabStyle={{
                    backgroundColor: "#0F1E43",
                    borderBottomStartRadius: 20,
                  }}
                  textStyle={{ color: "#fff" }}
                  activeTabStyle={{
                    backgroundColor: "#FFFFFF",
                    borderTopLeftRadius: 20,
                    borderTopEndRadius: 20,
                  }}
                  activeTextStyle={{ color: "#000000", fontWeight: "normal" }}
                >
                  {this.List()}
                </Tab>
              </Tabs>
              {/* **************************************End Data Content***************************** */}
            </View>
          </Body>
        </Container>
      </HomeLayout>
    );
  }
}
const styles = StyleSheet.create({
  contentContainer: {
    paddingVertical: 60,
  },
  pickerContainer: {
    backgroundColor: "#E6E6E6",
    height: 32,
    paddingHorizontal: 10,
    borderRadius: 5,
  },
  blockSearch: {
    position: "absolute",
    right: 5,
    width: 40,
    height: 68,
    marginVertical: 8,
    backgroundColor: mangoGreen,
    flex: 1,
    flexDirection: "column",
    justifyContent: "center",
    borderRadius: 5,
  },
  btnSearch: {
    color: "#fff",
    fontSize: 22,
  },
});
export default All_project;
