import React, { Component, useState } from 'react';
import { StyleSheet, Alert, View, Image, TouchableOpacity, ListView, ScrollView } from 'react-native'
import { Container, Root, Header, Title, Content, Footer, FooterTab, Button, Left, Right, Body, Icon, Text, Badge, Card, CardItem, H1, List, ListItem, Thumbnail, Switch, Tab, Tabs, Linking } from 'native-base';
import { Circle } from 'react-native-svg';
import Modal from 'react-native-modal';
import SvgPanZoom, { SvgPanZoomElement } from 'react-native-svg-pan-zoom';
import {
  borderGrey,
  darkGreen,
  iconStyle,
  inputStyle,
  mangoGreen,
  red,
  grey,
  smallTextStyle,
  smallText,
  titleStyle,
  tinyTextStyle,
  smallInputStyle,
  blue,
  darkBlue,
  bgHeader
} from "../../stylesheet/styles";


class Group extends Component {
  constructor(props) {
    super(props)
    this.state = {}
  }
  render() {
    return (
      <Container>
        <H1 style={{ flex: 1, paddingVertical: '50%', textAlign: 'center' }}> COMMING SOON</H1>

      </Container>
    );
  }
}

export default Group