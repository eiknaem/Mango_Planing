﻿import React, { Component } from "react";
import { View } from "react-native";
import Constants from "expo-constants";
import {
  Container,
  Header,
  Title,
  Content,
  Button,
  Left,
  Right,
  Body,
  Icon,
  Text,
  Card,
  CardItem,
  Thumbnail,
} from "native-base";
import MessageBox from "../../api/msg";
import { apiAuth } from "../../api/authentication";
import { reFormatPicture } from "../../api/qcm";
import $xt from "../../api/xtools";
import AsyncStorage from "@react-native-async-storage/async-storage";
import user_icon from "../../../assets/avatar-icon-27.png";
import { BackSVG } from "../../svg/IconSVG";
import { bg_header, btn_text } from "../../stylesheet/styles";
class SettingScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      auth: {},
      appinfo: {},
    };
  }

  async componentDidMount() {
    let server_data = (await apiAuth.getAuth()).data;
    let auth = server_data.auth;
    let appinfo = server_data.appinfo;
    console.log("appinfo", appinfo.webview) ;
    let profile = await reFormatPicture(appinfo.profile);
    await this.setState({
      auth,
      appinfo,
      profile,
      checkProfile: appinfo.profile,
    });
  }
  Header = () => (
    <Header
      transparent
      iosBarStyle={"light-content"}
      style={[bg_header, { flexDirection: "row", width: "100%" }]}
    >
      <View style={{ width: "20%" }}>
        <Button
          style={{ width: "100%", justifyContent: "flex-start" }}
          transparent
          onPress={() => this.props.navigation.goBack()}
        >
          <BackSVG />
        </Button>
      </View>
      <Body style={{ width: "70%", alignItems: "center", paddingVertical: 7.5 }}>
        <Title style={btn_text}>QCM</Title>
      </Body>

      <View style={{ width: "20%" }}>
        <Button
          transparent
          style={{ width: "100%", justifyContent: "flex-end" }}
        ></Button>
      </View>
    </Header>
  );

  _logout = async () => {
    if (
      !(await MessageBox.Confirm(
        `โปรดยืนยัน`,
        `คุณต้องการออกจากระบบหรือไม่?`,
        `ไม่ใช่`,
        `ใช่`
      ))
    )
      return;
    try {
      await apiAuth.logout();
    } catch (ex) {
      console.log(ex);
    }

    await AsyncStorage.setItem("mango_auth", "");
    // AsyncStorage.clear();
    this.props.navigation.replace("LoginScreen");
  };

  render() {
    //console.log('0000')
    return (
      <Container>
        {this.Header()}
        <Content style={{ backgroundColor: "#eff0f1" }}>
          <View style={{ flex: 1, margin: 15 }}>
            <Card style={{ flex: 0 }}>
              <CardItem bordered>
                <Left>
                  <Thumbnail
                    style={{
                      width: 50,
                      height: 50,
                    }}
                    source={
                       !$xt.isEmpty(this.state.checkProfile)
                        ? { uri: this.state.profile }
                        : user_icon
                    }
                  />
                  <Body>
                    <Text>{(this.state.auth.empname || "").toUpperCase()}</Text>
                    <Text note>
                      {(this.state.auth.mainname || "").toUpperCase()}
                    </Text>
                  </Body>
                </Left>
              </CardItem>
              <CardItem footer>
                {
                  //<Left>
                  //    <Button transparent >
                  //        <Text>เปลี่ยนรูปโปรไฟล์</Text>
                  //    </Button>
                  //</Left>
                }
                <Left />
                <Right>
                  <Button transparent onPress={this._logout}>
                    <Icon type="FontAwesome" name="sign-out" />
                    <Text>ลงชื่อออก</Text>
                  </Button>
                </Right>
              </CardItem>
            </Card>
            {/*
                    <Card>
                        <CardItem bordered>
                            <Icon name="logo-googleplus" />
                            <Text>Google Plus</Text>
                            <Body />
                            <Right>
                                <Switch value={false} />
                            </Right>
                        </CardItem>
                        <CardItem bordered>
                            <Icon name="logo-googleplus" />
                            <Text>Google Plus xxxxxxxxxxxxx ffff fff fff fff</Text>
                            <Body />
                            <Right>
                                <Switch value={false} />
                            </Right>
                        </CardItem>
                    </Card>
                    */}
            <Card>
              <CardItem header bordered>
                <Text>คู่มือการใช้งาน</Text>
              </CardItem>
              <CardItem>
                <Body>
                  <Text>ยังไม่มีคู่มือการใช้งาน</Text>
                </Body>
              </CardItem>
            </Card>
            <Card>
              <CardItem header bordered>
                <Text>เกี่ยวกับ Mango QCM</Text>
              </CardItem>
              <CardItem>
                <Body>
                  <Text>Version : {Constants.nativeAppVersion}</Text>
                  <Text>
                    API Build No. : {this.state.appinfo.build_version}
                  </Text>
                </Body>
              </CardItem>
            </Card>
            <Card>
              <CardItem header bordered>
                <Text>Mango Consultant Co., Ltd.</Text>
              </CardItem>

              <CardItem>
                <Body>
                  <Text>
                    555 อาคารรสา ทาวเวอร์ 1 ยูนิต 2304-1 ชั้น 23 ถ.พหลโยธิน
                    แขวงจตุจักร เขตจตุจักร กรุงเทพฯ 10900
                  </Text>
                  <Text>Call Center : 02-123-3900</Text>
                  <Text>Email : info@mangoconsultant.com</Text>
                </Body>
              </CardItem>
            </Card>
          </View>
        </Content>
      </Container>
    );
  }
}

export default SettingScreen;
