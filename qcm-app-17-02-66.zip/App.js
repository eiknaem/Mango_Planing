﻿//React Native
import React, { Component } from "react";
import { StyleSheet, BackHandler,View } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Location from 'expo-location';
import { getLocation } from "./src/api/constants";
import MessageBox from "./src/api/msg";
//Expo
import AppLoading from "expo-app-loading";
//import { StatusBar } from 'expo-status-bar';
import * as Font from "expo-font";
import * as Localization from "expo-localization";
import { ApplicationProvider } from "@ui-kitten/components";
import * as eva from "@eva-design/eva";
import * as Linking from "expo-linking";
import $xt from "./src/api/xtools";
import * as Updates from 'expo-updates';
// import * as Location from 'expo-location';

//Native Base
import { StyleProvider, Root } from "native-base";
import getTheme from "./native-base-theme/components";
import material from "./native-base-theme/variables/material";

//React Navigation
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

///Views
import Home from "./src/views/home/home";
import PasscodeScreen from "./src/views/authentication/passcode.js";
import LoginScreen from "./src/views/authentication/login.js";
import SettingScreen from "./src/views/Settings/index.js";

//QCM page
import All_projectScreen from "./src/views/Tabs/all_project.js";
import QCMScreen from "./src/views/QCM/index.js";
import SignatureScreen from "./src/views/QCM/components/signature.js";
import ChecklistScreen from "./src/views/QCM/components/check_list.js";
import DocumentScreen from "./src/views/QCM/components/document.js";
import CommentsScreen from "./src/views/QCM/components/comments.js";
import AttachFileScreen from "./src/views/QCM/components/attach_file.js";
import AdditionalMenuScreen from "./src/views/QCM/components/additional_menu.js";
import SubmitApproveScreen from "./src/views/Tabs/submit_approve.js";

import * as Permissions from "expo-permissions";
import { apiAuth, loginOtherApplication } from "./src/api/authentication";

const Stack = createStackNavigator();

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      initialScreen: "PasscodeScreen",
      isReady: false,
      gps_location: "",
      gps_location_coordinate: "",
    };
  }
  async componentDidMount() {
    await AsyncStorage.setItem("theme", "light_mode");

    BackHandler.addEventListener("hardwareBackPress", this.handleBackPress);
    await Font.loadAsync({
      KanitLight: require("./assets/Fonts/Kanit-Light.ttf"),
      KanitMedium: require("./assets/Fonts/Kanit-Medium.ttf"),
    });
    let url = await Linking.getInitialURL();
    let newURL = Linking.parse(url || "*");
    // console.log("newURL", newURL);
    let newBaseUrl = newURL.queryParams.baseUrl;
    let newMangoAuth = newURL.queryParams.mango_auth;
    let newPasscode = newURL.queryParams.passcode;
    let newBasePath = newURL.queryParams.webview;
    let newSession = newURL.queryParams.session;
    let newAuth = newURL.queryParams.auth
    if (!$xt.isEmpty(newMangoAuth)) {
      await AsyncStorage.multiSet([
        ["baseUrl", newBaseUrl] || "",
        ["passcode", newPasscode || ""],
        ["basePath", newBasePath || ""],
        ["session", newSession || ""],
        ["auth", newAuth || ""],
      ]);
      let newLogin = await loginOtherApplication(newMangoAuth, "QCM", "");
      // console.log("new token:", newLogin.token);
      await AsyncStorage.setItem("mango_auth", newLogin.token || "");
    }
    this.getPermissionAsync()
    let passcode = (await AsyncStorage.getItem("passcode")) || "";
    let baseUrl = (await AsyncStorage.getItem("baseUrl")) || "";
    try {
      if (passcode && baseUrl) {
        let auth = (await apiAuth.getAuth()).data.auth;
        if (auth.is_authen) this.setState({ initialScreen: "All_project" });
        else this.setState({ initialScreen: "LoginScreen" });
      }else this.setState({ initialScreen: "PasscodeScreen" });
    } catch (ex) {
      let msg = await MessageBox.Alert(`Error`, ex.toString())
      msg ? this.setState({ initialScreen: "PasscodeScreen" }) : null
    }
    this.setState({ isReady: true });
  }
  componentWillUnmount() {
    BackHandler.removeEventListener("hardwareBackPress", this.handleBackPress);
  }
  handleBackPress = () => {
    return true; // Do nothing when back button is pressed
  };
  openSetting = async () => {
    await Linking.openSettings();
    await $xt.sleep(200);
    await Updates.reloadAsync();
  };
  getPermissionAsync = async () => {
    var { status } = await Location.requestForegroundPermissionsAsync();
    // setStatus(status)
    // this.setState({ isStatus: status });
    console.log("status", status);
    if (status !== "granted") {
      let _ms = await MessageBox.Confirm(
        "โปรดยืนยัน",
        `สิทธิ์ในการเข้าถึงตำแหน่งถูกปฏิเสธ \n ต้องการไปที่ตั้งค่าหรือไม่?`,
        "ไม่ใช่",
        "ใช่"
      );
      console.log("_ms", _ms);
      if (_ms) {
        this.openSetting();
      }
      return;
    }else{
      let _getlocation = [];
      if (status === "granted") {
        //write code for the app to handle GPS changes
        _getlocation = Location.watchPositionAsync(
          {
            accuracy: Location.Accuracy.BestForNavigation,
            timeInterval: 10000,
            distanceInterval: 1,
          },
          async (location) => {
            // console.log("OS sent Location ");
            const { latitude, longitude } = location.coords;
            // console.log("latitude", latitude, "longitude", longitude);
            const mangoLoc = await getLocation(latitude, longitude);
            let gps_location_coordinate = `${latitude},${longitude}`;
            // console.log("gps_location", gps_location,"gps_location_coordinate", gps_location_coordinate);
           // this.setState({ gps_location, gps_location_coordinate });
            await AsyncStorage.setItem("gps_location_coordinate", gps_location_coordinate || "");
          global.latitude = latitude
          global.longitude = longitude
            // await AsyncStorage.setItem("gps_latitude", latitude.toString() || "");
            // await AsyncStorage.setItem("gps_longitude", longitude.toString() || "");
          }
        );
      }
    }
  };
  render() {
    if (!this.state.isReady) {
      return <View />;
    } else
      return (
        <Root>
          <StyleProvider style={getTheme(material)}>
            <ApplicationProvider {...eva} theme={eva.light}>
              <NavigationContainer>
                <Stack.Navigator
                  screenOptions={{
                    headerShown: false,
                  }}
                  initialRouteName={this.state.initialScreen}
                >
                  <Stack.Screen
                    name="PasscodeScreen"
                    component={PasscodeScreen}
                  />
                  <Stack.Screen name="LoginScreen" component={LoginScreen} />
                  <Stack.Screen
                    name="SettingScreen"
                    component={SettingScreen}
                  />
                  <Stack.Screen name="Home" component={Home} />
                  <Stack.Screen
                    name="All_project"
                    component={All_projectScreen}
                  />
                  <Stack.Screen name="QCM" component={QCMScreen} />
                  <Stack.Screen
                    name="SignatureSc"
                    component={SignatureScreen}
                  />
                  <Stack.Screen name="Document" component={DocumentScreen} />
                  <Stack.Screen
                    name="AttachFile"
                    component={AttachFileScreen}
                  />
                  <Stack.Screen name="Comments" component={CommentsScreen} />
                  <Stack.Screen
                    name="AdditionalMenu"
                    component={AdditionalMenuScreen}
                  />
                  <Stack.Screen
                    name="SubmitApprove"
                    component={SubmitApproveScreen}
                  />
                </Stack.Navigator>
              </NavigationContainer>
            </ApplicationProvider>
          </StyleProvider>
        </Root>
      );
  }
}
export default () => {
  return <App />;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
