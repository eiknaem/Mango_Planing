﻿import axios from 'axios'
import Constants from 'expo-constants'
import { Notifications } from "expo"
import * as Permissions from "expo-permissions"
import * as Application from 'expo-application';
import $xt from './xtools'
import linq from 'js-linq'
import { Platform } from 'react-native'

const $linq = arr => new linq(arr);

let apiPasscode = {
    async getIP(passcode) {
        let url = `https://gateway.mangoanywhere.com/mobile_ip/Home/GetAuthorized2?cus_code=${encodeURIComponent(passcode)}`;
        let rsp = await axios.get(url);
        return rsp.data;
    },
    async getCompany(base) {
        let url = `${base || ''}Api/Public/LoginCompanies/`
        let rsp = await axios.get(url);
        return rsp.data;
    }
};

let apiAuth = {
    notificationConfigure: async () => {
        // Notifications
        const { status: existingStatus } = await Permissions.getAsync(
            Permissions.NOTIFICATIONS
        );
        let finalStatus = existingStatus;
        if (existingStatus !== 'granted') {
            // Android remote notification permissions are granted during the app
            // install, so this will only ask on iOS
            const { status } = await Permissions.askAsync(Permissions.NOTIFICATIONS);
            finalStatus = status;
        }

        // Stop here if the user did not grant permissions
        if (finalStatus !== 'granted') {
            return '';
        }

        // Get the token that uniquely identifies this device

        let token = ''
        //try {
            token = await Notifications.getExpoPushTokenAsync();
        //} catch (ex) {
        //    console.log(ex.toString())
            
        //}

        return token;
    },
    async login(maincode, userid, userpass) {
        if ($linq(Array.from(arguments)).any(x => $xt.isEmpty(x))) {
            throw `โปรดป้อนข้อมูลให้ครบทุกช่อง. Please fill in all required fields.`
        }

        // const token_push = await apiAuth.notificationConfigure();     
        // const device_id = await Constants.deviceId;
        var device_id = ""
        if(Platform.OS === "android"){
         device_id = Application.androidId;
        }else{
            device_id = await Application.getIosIdForVendorAsync();
        }
        //string is_api = "N", string app_name = "POOL"
        let url = `Api/Public/Login?is_api=Y&app_name=QCMA`
        let form = {
            maincode,
            userid,
            userpass,
            device_id,
            // token_push
        }
        console.log("form", form);

        let rsp = await $xt.postServerJson(url, form);
        return rsp;
    },
    async getAuth() {
        //PLANWEB
        let url = `Api/Public/ViewInitData2?menu_name=PLANWEB`
        let rsp = await $xt.getServer(url);
        //console.log(rsp)
        return rsp;
    },
    async logout() {
        //PLANWEB
        let url = `Api/Public/logout?is_api=Y&all=false`
        let rsp = await $xt.getServer(url);
        //console.log(rsp)
        return rsp;
    },
}

export { apiPasscode, apiAuth }

export const loginOtherApplication = async (token, app_name) => {
    // console.log(`Planning/Planning/Planning_projectsummary?pre_event2=${pre_event2}&pre_event=${pre_event}`);
    return await $xt.getServer(
      `api/public/LoginOtherApplication?token=${token}&app_name=${app_name}`
    );
  };
  