﻿import { Platform, StyleSheet } from 'react-native'

const styles = StyleSheet.create({
    backgroundColor: {
        backgroundColor: '#fff'
    },
    fontColor: {
        color: '#000'
    }
});

export default styles