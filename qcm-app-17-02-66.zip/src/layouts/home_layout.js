﻿//React Native
import React, { Component } from 'react';
import { Platform, StatusBar, View, Image, StyleSheet, SafeAreaView, BackHandler } from 'react-native';
import linq from 'js-linq'

const $linq = arr => new linq(arr);

class BaseLayout extends Component {
    render() {
        const children = this.props.children

        return (
            <View style={{ flex: 1 }}>
                <SafeAreaView style={{ flex: 0, backgroundColor: '#000' }} ></SafeAreaView>
                <SafeAreaView style={{
                    flex: 1,
                    backgroundColor: '#000',
                    //backgroundColor: colorScheme === 'dark' ? '#000' : '#FFF',
                    //backgroundColor: 'rgba(52, 52, 52, 0.8)'
                    //marginTop: Platform.OS === 'ios' ? 0 : Constants.statusBarHeight
                }}>
                    <StatusBar barStyle="light-content" backgroundColor="#000" />
                    {children}
                </SafeAreaView>
            </View>
        )
    }
}

export default BaseLayout