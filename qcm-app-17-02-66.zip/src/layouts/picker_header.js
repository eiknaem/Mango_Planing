﻿import React, { Component } from 'react';
import { StyleSheet, Alert, View, Image } from 'react-native'
import { Container, Header, Body, Right, Left, Icon, Title, Content, Form, Item, Input, Label, Button, Text, Picker, Footer, FooterTab, Thumbnail } from 'native-base';

let pickerHeader = (backAction) => {
    return (
        <Header style={{ alignItems: 'center'}}>
            <View style={{ width: '20%' }} >
                <Button transparent
                    style={{ width: '100%', justifyContent: 'flex-start'}}
                    onPress={backAction}>
                    <Text style={{fontSize: 16}}>ยกเลิก</Text>
                </Button>
            </View>
            <Body style={{ width: '70%', alignItems: 'center', paddingVertical: 15 }}>
                <Title style={{ color: "#fff" }}>โปรดเลือก</Title>
            </Body>

            <View style={{ width: '20%' }}>
                <Button transparent
                    style={{ width: '100%', justifyContent: 'flex-end' }}>
                </Button>
            </View>
        </Header>
    )
}

export default pickerHeader