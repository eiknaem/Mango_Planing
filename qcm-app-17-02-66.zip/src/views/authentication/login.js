﻿import React, { Component } from "react";
import { StyleSheet, Alert, View, Image } from "react-native";
import {
  Container,
  Header,
  Body,
  Right,
  Left,
  Icon,
  Title,
  Content,
  Form,
  Item,
  Input,
  Label,
  Button,
  Text,
  Picker,
  Footer,
  FooterTab,
  Thumbnail,
} from "native-base";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Spinner from "react-native-loading-spinner-overlay";
import MessageBox from "../../api/msg";
import $xt from "../../api/xtools";
import { apiPasscode, apiAuth } from "../../api/authentication";
import styles from "../../stylesheet/styles";
import linq from "js-linq";
import logo from "../../../assets/icon_back.png";
import AuthLayout from "../../layouts/auth_layout";
import my_theme from "../../stylesheet/theme_selector";
import pickerHeader from "../../layouts/picker_header";
import theme_selector from "../../stylesheet/theme_selector";

const $linq = (arr) => new linq(arr);

let mytheme = {}; //my_theme.default;

export default class Login extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isProcess: false,
      spinner: false,
      passcode: "",
      userid: "",
      userpass: "",
      company_workplace: [],
      companies: [],
      site: "",
      maincode: "",
      type: "",
    };
  }

  async UNSAFE_componentWillMount() {
    mytheme = await my_theme.update();
  }

  async componentDidMount() {
    let passcode = (await AsyncStorage.getItem("passcode")) || "";
    let company_workplace = JSON.parse(
      (await AsyncStorage.getItem("workplaces")) || []
    );
    //Production และ Demo ว่าง
    let pathNull = $linq(company_workplace).all(x => $xt.isEmpty(x.path));
    if(pathNull){
      let msg = await MessageBox.Alert(`Warning`, `Set Passcode Please`);
      if(msg) {
        await this.props.navigation.replace("PasscodeScreen");
      }
      return;
    }
    //
    let type =
      $linq(company_workplace)
        .where(x => !$xt.isEmpty(x.path))
        .select((x) => x.type)
        .firstOrDefault() || "";

    // this.state.passcode = passcode;
    // this.state.company_workplace = company_workplace;
    // this.state.type = type;
    
    this.setState({ passcode, company_workplace, site, type });
    let site =
      $linq(company_workplace)
        .select((x) => x.path)
        .firstOrDefault() || "";
    // this.setState({ passcode, company_workplace, site })
    await this._getCompany();
  }
  setDataSite = async () => {
    let data = $linq(this.state.company_workplace)
      .where((x) => x.type == this.state.type)
      .firstOrDefault();
      console.log("basePath:", data);
    this.setState({ site: data.path });    
    
    if ($xt.isEmpty(data.basePath)) {//ถ้าไม่มี Production
      // await this._getCompany();
      // await AsyncStorage.setItem("basePath", data.basePath);
    }
  };
  _getCompany = async () => {
    //console.log(this.state.site)

    this.setState({ spinner: true})
    await this.setDataSite();
    if ($xt.isEmpty(this.state.site)) {
      this.setState({ spinner: false});
      return
    };
    await this.setState({companies: [], maincode: "" });
    await $xt.sleep(300);
    try { 
      let rsp = await apiPasscode.getCompany(this.state.site);
      let maincode =
        $linq(rsp.data)
          .select((x) => x.maincode)
          .firstOrDefault() || "";
      this.setState({companies: rsp.data, maincode });
      await AsyncStorage.setItem("baseUrl", this.state.site);
    } catch (ex) {
      MessageBox.Alert(`Error`, ex.toString());
    }finally{
      await $xt.sleep(300);
      await this.setState({ spinner: false });
    }
  };

  _doNext = async () => {
    if (this.state.isProcess) return;

    await this.setState({ isProcess: true, spinner: true });
    await $xt.sleep(500);
    try {
      let rsp = await apiAuth.login(
        this.state.maincode,
        this.state.userid,
        this.state.userpass
      );
      console.log("SUCCESS LOGIN"); 
      if (rsp.error) throw rsp.error;

      await AsyncStorage.setItem("mango_auth", rsp.data);
      let auth = ((await apiAuth.getAuth()).data.auth);
      await AsyncStorage.setItem("auth", JSON.stringify(auth) || "");
      // await AsyncStorage.setItem("session_id", auth.session_id || "");
      
      this.props.navigation.replace("All_project");
    } catch (ex) {
      await this.setState({ isProcess: false, spinner: false });
      await $xt.sleep(200);
      MessageBox.Alert(`Error`, ex.toString());
    }

    await this.setState({ isProcess: false, spinner: false });
  };

  render() {
    return (
      <AuthLayout>
        <Container>
          <Content style={[mytheme.backgroundColor]}>
            <View style={{ flex: 1, margin: 20 }}>
              <View style={stylesLocal.container}>
                <Thumbnail large style={stylesLocal.logo} source={logo} />
                <Text
                  style={[
                    { fontWeight: "bold", fontSize: 20 },
                    mytheme.fontColor,
                  ]}
                >
                  เข้าสู่ระบบ
                </Text>
                <Text style={{ marginTop: 25, color: "red" }}>
                  โปรดป้อนข้อมูลให้ครบทุกช่อง
                </Text>
              </View>
              <Item>
                <Icon
                  type="FontAwesome"
                  name="database"
                  style={[localStyles.icon, mytheme.fontColor]}
                />
                <Picker
                  note
                  mode="dropdown"
                  placeholder="Please Select Database"
                  style={styles.picker}
                  textStyle={[mytheme.fontColor]}
                  selectedValue={this.state.type}
                  // selectedValue={this.state.site}
                  //headerBackButtonText="ยกเลิก"
                  renderHeader={pickerHeader}
                  onValueChange={async (type) => {
                    await this.setState({ type });
                    await this._getCompany();
                  }}
                // onValueChange={async (site) => { await this.setState({ site }); await this._getCompany() }}
                >
                  {$linq(this.state.company_workplace)
                    .select((x, i) => {
                      return (
                        <Picker.Item key={i} label={x.type} value={x.type} /> //x.path
                        // <Picker.Item key={i} label={x.type} value={x.path} />
                      );
                    })
                    .toArray()}
                </Picker>
              </Item>
              <Item>
                <Icon
                  type="FontAwesome"
                  name="building"
                  style={[localStyles.icon, mytheme.fontColor]}
                />
                <Picker
                  note
                  mode="dropdown"
                  placeholder="Please Select Company"
                  style={styles.picker}
                  textStyle={[mytheme.fontColor]}
                  //headerBackButtonText="ยกเลิก"
                  renderHeader={pickerHeader}
                  selectedValue={this.state.maincode}
                  onValueChange={(maincode) => this.setState({ maincode })}
                >
                  {$linq(this.state.companies)
                    .select((x, i) => {
                      return (
                        <Picker.Item
                          key={i}
                          label={x.mainname}
                          value={x.maincode}
                        />
                      );
                    })
                    .toArray()}
                </Picker>
              </Item>
              <Item>
                <Icon
                  type="FontAwesome"
                  name="user"
                  style={[localStyles.icon, mytheme.fontColor]}
                />
                <Input
                  value={this.state.userid}
                  onChangeText={(userid) => this.setState({ userid })}
                  placeholder="ผู้ใช้งาน"
                  style={[mytheme.fontColor]}
                />
              </Item>
              <Item>
                <Icon
                  type="FontAwesome"
                  name="key"
                  style={[localStyles.icon, mytheme.fontColor]}
                />
                <Input
                  value={this.state.userpass}
                  onChangeText={(userpass) => this.setState({ userpass })}
                  placeholder="รหัสผ่าน"
                  secureTextEntry={true}
                  style={[mytheme.fontColor]}
                />
              </Item>
              <View style={[{ marginTop: 30 }]}>
                <Button
                  rounded
                  block
                  success
                  onPress={this._doNext}
                  disabled={this.state.isProcess}
                >
                  <Text>เข้าสู่ระบบ</Text>
                </Button>
              </View>
            </View>

            <View style={stylesLocal.container}>
              <Text
                style={{ marginTop: 0, color: "#4287f5" }}
                onPress={() => {
                  this.props.navigation.replace("PasscodeScreen");
                }}
              >
                เปลี่ยนรหัสบริษัท
              </Text>
            </View>
            <Spinner visible={this.state.spinner} />
          </Content>
          {
            //<Footer>
            //    <FooterTab>
            //        <Button success full onPress={this._doNext} disabled={this.state.isProcess}>
            //            <Text style={{ color: 'white' }}>Sign In</Text>
            //        </Button>
            //    </FooterTab>
            //</Footer>
          }
        </Container>
      </AuthLayout>
    );
  }
}

const localStyles = StyleSheet.create({
  icon: {
    width: 50,
  },
  picker: {
    marginLeft: -10,
  },
});

const stylesLocal = StyleSheet.create({
  container: {
    justifyContent: "center",
    alignItems: "center",
    marginTop: 40,
    marginBottom: 20,
  },
  logo: {
    //width: 70,
    //height: 70,
    marginBottom: 20,
  },
});
