﻿import React, { Component } from 'react';
import { StyleSheet, Alert, View, Image } from 'react-native'
import { Container, Root, Header, Title, Content, Footer, FooterTab, Button, Left, Right, Body, Icon, Text, Badge, Card, CardItem, H1, List, ListItem, Thumbnail, Switch } from 'native-base';
import { Circle } from 'react-native-svg';
import SvgPanZoom, { SvgPanZoomElement } from 'react-native-svg-pan-zoom';

class Example extends Component {
    constructor(props) {
        super(props)
    }

  render() {
    return (
<Body>
      <View style={{flex:1}}>

        <SvgPanZoom
          canvasHeight  = {500}
          canvasWidth   = {500}
          minScale      = {0.5}
          initialZoom   = {1.0}
          onZoom        = {(zoom) => { console.log('onZoom:' + zoom) }}
          canvasStyle   = {{ backgroundColor: 'yellow' }}
          viewStyle     = {{ backgroundColor: 'black'  }}
        >

          {/* Doesn't consume or respond to clicks */}
          <Circle
            cx          = {100}
            cy          = {100}
            r           = {42}
            stroke      = "red"
            strokeWidth = "2.5"
            fill        = "blue"
          />

          {/* Responds to clicks */}
          <SvgPanZoomElement
            x ={50}
            y ={50}
            onClick         = {()=>{ console.log('onClick!') }}
            onClickCanceled = {()=>{ console.log('onClickCanceled!') }}
            onClickRelease  = {()=>{ console.log('onClickRelease!') }}
            onDrag          = {()=>{ console.log('onDrag!') }}
          >
            <Circle
              cx          = {42}
              cy          = {42}
              r           = {42}
              stroke      = "blue"
              strokeWidth = "2.5"
              fill        = "red"
            />
          </SvgPanZoomElement>

        </SvgPanZoom>

      </View>
</Body>
    );
  }
}

export default Example