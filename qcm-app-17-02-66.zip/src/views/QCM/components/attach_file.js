import React, { Component } from "react";
import {
  Dimensions,
  View,
  Image,
  TouchableOpacity,
  TouchableHighlight,
  FlatList,
  SafeAreaView,
  Modal,
  Linking,
  Alert,
  StyleSheet,
  Platform
} from "react-native";
import { Ionicons, Entypo } from "@expo/vector-icons";
import Spinner from "react-native-loading-spinner-overlay";
import { Content, Button, Body, Icon, Text, Card, CardItem } from "native-base";
import * as ImageManipulator from 'expo-image-manipulator';
import * as DocumentPicker from "expo-document-picker";
import * as ImagePicker from "expo-image-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as FileSystem from "expo-file-system";
import linq from "js-linq";
import $xt from "../../../api/xtools";
import PDFReader from "rn-pdf-reader-js";
import ImageViewer from "react-native-image-zoom-viewer";
import {
  customCard,
  block_title,
  smallInputStyle,
} from "../../../stylesheet/styles";
import { postAttachfile, getCheckList } from "../../../api/qcm";
import MessageBox from "../../../api/msg";
import { ScrollView } from "react-native-gesture-handler";
// var RNFS = require('react-native-fs');
// var SavePath = Platform.OS === 'ios' ? RNFS.MainBundlePath : RNFS.DocumentDirectoryPath;
const { _width, _height } = Dimensions.get("window");
class AttachFile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loopdata: [],
      last_count: -1,
      file: [],
      pathFile: "",
      shownDocList: this.props.dataFromParent,
      modalVisible: false,
      spinner: false,
    };
  }
  componentDidMount = async () => {
    console.log("PROPS", this.props);
    await this.loadDocList();
  };
  setModalVisible = (visible) => {
    this.setState({ modalVisible: visible });
  };
  loadDocList = async () => {
    let baseUrl = (await AsyncStorage.getItem("baseUrl")) || "";

    let _docno = this.props.params._docno;
    let _pre_event2 = this.props.params._pre_event2;
    let _pre_event = this.props.params._pre_event;
    let _loccode = this.props.params._loccode;
    let _form_code = this.props.params._form_code;
    let _form_type = this.props.params._form_type;
    let _approve_status = this.props.params._approve_status;
    let _sendapp = this.props.params._sendapp;
    let _docapp = this.props.params._docapp;

    let docs = await getCheckList({
      docno: _docno,
      pre_event: _pre_event,
      loccode: _loccode,
      form_code: _form_code,
      form_type: _form_type,
    });
    // console.log("FILE", docs.data.file);
    this.setState({
      shownDocList: docs.data.file,
      baseUrl: baseUrl,
      approve_status: _approve_status,
      sendapp: _sendapp,
      docapp: _docapp,
      spinner: false,
    });
  };
  openFile = async (item) => {
    console.log(item);
    var filepath2 = `${this.state.baseUrl}Api/File/DownLoad?id=${item.file_path}`;
    console.log("filepath2", filepath2);
    let filename = item.uri.split("/");
    let _type = filename[filename.length - 1].split(".");
    // console.log(_type[1]);
    // console.log("PATH", data);
    let uri = item.file_path;
    if (
      _type[1] == "png" ||
      _type[1] == "jpg" ||
      _type[1] == "jpeg" ||
      _type[1] == "bmp"
    ) {
      var content =
        this.state.baseUrl + `Api/File/DownLoad?download=flase&id=` + uri;
      this.setState({ previewModalShow: !this.state.previewModalShow });
      // await Image.getSize(filepath2, (width, height) => {
      //   this.setState({ width, height });
      //   console.log("YAhoooo",  width, height );
      // });
    } else {
      if (Platform.OS == "ios") {
        this.setState({ previewModalShow: !this.state.previewModalShow });
      } else {
        // Linking.openURL(content);
        Linking.openURL(filepath2);
      }
    }
    this.setState({
      pathFile: filepath2,
      pictures: [{ url: filepath2 }],
      checkTypeFile: _type[1],
    });
  };
  iconName = (item) => {
    let filename = item.file_name.split("/");
    let _type = filename[filename.length - 1].split(".");
    // console.log(_type);

    if (_type == "xlsx" || _type == "xlsm" || _type == "xls") {
      return "file-excel-o";
    } else if (_type == "pptx" || _type == "ppt") {
      return "file-powerpoint-o";
      // .docx, .docm, .dot, .dotm, dotx
    } else if (
      _type == "docx" ||
      _type == "docm" ||
      _type == "dot" ||
      _type == "dotx" ||
      _type == "dotm" ||
      _type == "doc"
    ) {
      return "file-word-o";
    } else if (_type == "pdf") {
      return "file-pdf-o";
    } else if (
      _type == "jpeg" ||
      _type == "jpg" ||
      _type == "png" ||
      _type == "gif"
    ) {
      return "file-image-o";
    } else {
      return "file-o";
    }
  };
  iconColor = (item) => {
    let filename = item.file_name.split("/");
    let _type = filename[filename.length - 1].split(".");
    // console.log(_type);

    if (_type == "xlsx" || _type == "xlsm" || _type == "xls") {
      return "#407855";
    } else if (_type == "pptx" || _type == "ppt") {
      return "#CA5010";
      // .docx, .docm, .dot, .dotm, dotx
    } else if (
      _type == "docx" ||
      _type == "docm" ||
      _type == "dot" ||
      _type == "dotx" ||
      _type == "dotm" ||
      _type == "doc"
    ) {
      return "#0078d4";
    } else if (_type == "pdf") {
      return "#A4262c";
    } else if (
      _type == "jpeg" ||
      _type == "jpg" ||
      _type == "png" ||
      _type == "gif"
    ) {
      return "#40587c";
    } else {
      return "#000";
    }
  };
  _renderItem = ({ item }) => {
    // console.log(item);
    return (
      <TouchableOpacity
        style={{
          margin: 5,
          padding: 5,
          borderRadius: 10,
          backgroundColor: "#fff",
          shadowColor: "#000",
          shadowOffset: {
            width: 0,
            height: 1,
          },
          shadowOpacity: 0.2,
          shadowRadius: 1.41,

          elevation: 2,
        }}
        onPress={() => this.openFile(item)}
      >
        <View
          style={{
            width: 92,
            textAlign: "center",
            alignItems: "center",
          }}
        >
          <Icon type="FontAwesome" name={this.iconName(item)}></Icon>
          <Text
            style={{
              textAlign: "left",
              paddingHorizontal: 7.5,
              paddingVertical: 7.5,
              lineHeight: 18,
              fontSize: 13,
            }}
          >
            {item.file_name}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };
  _pickDoucment = async () => {
    let mango_auth = (await AsyncStorage.getItem("mango_auth")) || "";
    try {
      let result = await DocumentPicker.getDocumentAsync({
        // type: "*/*",
        type: ["*/*", "application/*"],
        // type: ["application/*", "audio/*"]
      });
      console.log("RESULT", result);
      if (result.type == "cancel") {
        return;
      }
      if (!result.cancelled) {
        this.setState({
          modalVisible: false,
          spinner: true,
        });
        //เลือกไฟล์แล้ว
        // console.log("!!!!!",result.uri);
        // this.setState({ image: result.uri });
        // const split = result.uri.split("/");
        // const fileName = split[split.length - 1];
        // console.log("fileName..", fileName);
        // console.log("split...", split[0]);
        // const base64 = await FileSystem.readAsStringAsync(result.uri, {
        //   encoding: FileSystem.EncodingType.Base64,
        // });
        // await FileSystem.readAsStringAsync(result.uri, { encoding: FileSystem.EncodingType.Base64 });
        // result.name = fileName;

        let data = {
          pre_event2: this.props.params._pre_event2,
          pre_event: this.props.params._pre_event,
          plan_code: this.props.plan.plan_code,
          doctype: "WBS_QCM",
          taskid: this.props.params._loccode,
          sizefile: result.size,
          token: mango_auth,
          file: result,
          // file: result.base64,
        };
        //console.log("INNNN", result);
        console.log("_data:", data);
        var rsp = await postAttachfile(data); //Save File
        console.log("rsp....", rsp);
        await this.loadDocList(); //Read Data
      }
      //
      // console.log("SUCCESS", result);
    } catch (E) {
      //Error
      let msg = await MessageBox.Alert("Error...", E.toString());
      msg
        ? this.setState({
          spinner: false,
        })
        : null;
      // console.log(E);
    }
    if (!rsp.success) {
      MessageBox.Alert("Error", rsp.error);
    }
  };
  _pickImg = async () => {
    let mango_auth = (await AsyncStorage.getItem("mango_auth")) || "";
    try {
      // let result = await DocumentPicker.getDocumentAsync({
      //   type: "*/*",
      // });
      // this.setState({
      //   modalVisible: false,
      //   spinner: true,
      // });
      let result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.All,
        // allowsEditing: true,
        // aspect: [4, 3],
        quality: Platform.OS === 'ios' ? 0.67 : 1,

        // base64: true,
      });
      //
      if (!result.cancelled) {
        this.setState({
          modalVisible: false,
          spinner: true,
        });
        //เลือกไฟล์แล้ว
        // console.log("!!!!!",result.uri);
        // this.setState({ image: result.uri });
        const split = result.uri.split("/");
        const fileName = split[split.length - 1];
        // await FileSystem.readAsStringAsync(result.uri, { encoding: FileSystem.EncodingType.Base64 });
        const fileInfo = await FileSystem.getInfoAsync(result.uri || "");
        // console.log("fileInfo...", fileInfo);
        result.mimeType = result.type == "image" ? "image/png" : "video/mp4";
        result.size = fileInfo.size;
        result.name = fileName;
        console.log("result----size :", result.size);
        let data = {
          pre_event2: this.props.params._pre_event2,
          pre_event: this.props.params._pre_event,
          plan_code: this.props.plan.plan_code,
          doctype: "WBS_QCM",
          taskid: this.props.params._loccode,
          sizefile: result.size,
          token: mango_auth,
          file: result,
          // file: result.base64,
        };
        //console.log("INNNN", result);
        // console.log("_dataImg:", data);
        var rsp = await postAttachfile(data); //Save File
        //Read Data
      }
      //
      console.log("SUCCESS", rsp);
    } catch (E) {
      //Error
      let msg = await MessageBox.Alert("Error1", E.toString());
      console.log(msg);
      msg
        ? this.setState({
          spinner: false,
        })
        : null;
    }
    if (!rsp.success) {
      MessageBox.Alert("Error2", rsp?.error);
      this.setState({
        spinner: false,
      });
    } else {
      await this.loadDocList();
    }
  };
  modalSelect = () => {
    const { modalVisible } = this.state;
    return (
      <View style={styles.centeredView}>
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            Alert.alert("Modal has been closed.");
            this.setModalVisible(!modalVisible);
          }}
        >
          <SafeAreaView style={styles.BackgrounModal}>
            <View style={styles.centeredView}>
              <View style={styles.modalView}>
                {/* <Text style={styles.modalText}>จะเอาแบบไหนก็กดสะ !</Text> */}
                <View style={{ flexDirection: "row" }}>
                  <TouchableOpacity
                    style={[styles.button, styles.buttonClose]}
                    onPress={() => this._pickDoucment()}
                  >
                    <View style={{ alignItems: "center" }}>
                      <Ionicons name="document-attach" size={30} color="#fff" />
                    </View>
                    <Text style={[styles.textStyle, { marginTop: 10 }]}>
                      Folder
                    </Text>
                  </TouchableOpacity>
                  <View style={{ margin: 5 }} />
                  <TouchableOpacity
                    style={[styles.button, styles.buttonClose]}
                    onPress={() => this._pickImg()}
                  >
                    <View style={{ alignItems: "center" }}>
                      <Entypo name="images" size={30} color="#fff" />
                    </View>
                    <Text style={[styles.textStyle, { marginTop: 10 }]}>
                      Media
                    </Text>
                  </TouchableOpacity>
                </View>
                <View style={styles.line} />
                <TouchableOpacity
                  onPress={() => this.setModalVisible(!modalVisible)}
                >
                  <Text style={{ textAlign: "center", marginTop: 10 }}>
                    ยกเลิก
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </SafeAreaView>
        </Modal>
      </View>
    );
  };
  beforeSaveModal = () => {
    console.log("PATH", this.state.pathFile);
    if (this.state.previewModalShow) {
      return this.state.checkTypeFile == "png" ||
        this.state.checkTypeFile == "jpg" ||
        this.state.checkTypeFile == "bmp" ||
        this.state.checkTypeFile == "jpeg" ? (
        <Modal visible={true} transparent={true}>
          <ImageViewer
            imageUrls={this.state.pictures}
            renderIndicator={() => { }}
            enableSwipeDown={true}
            renderHeader={() => (
              <View
                style={{
                  position: "absolute",
                  top: 50,
                  right: 15,
                  flexDirection: "row",
                  justifyContent: "flex-end",
                  zIndex: 10,
                }}
              >
                {/* <Icon type={"Ionicons"} name={"arrow-round-forward"} /> */}
                <Button
                  transparent
                  style={{
                    borderWidth: 1,
                    borderColor: "white",
                    marginLeft: 5,
                  }}
                  onPress={() => this.setState({ previewModalShow: false })}
                >
                  <Icon
                    type="FontAwesome"
                    name="times"
                    style={{ color: "white", fontSize: 30 }}
                  />
                </Button>
              </View>
            )}
            onSwipeDown={() => this.setState({ previewModalShow: false })}
            enablePreload={true}
            flipThreshold={50}
            maxOverflow={300}
          />
        </Modal>
      ) : (
        <View
          style={{
            // flex: 1,
            position: "absolute",
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            height: _height,
            zIndex: 999,
            backgroundColor: "black",
          }}
        >
          <View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "flex-end",
                alignItems: "center",
              }}
            >
              <Button
                transparent
                style={{
                  borderWidth: 1,
                  borderColor: "white",
                  marginRight: 15,
                  marginTop: 15,
                  zIndex: 10,
                  marginBottom: 10,
                }}
                onPress={() => this.setState({ previewModalShow: false })}
              >
                <Icon
                  type="FontAwesome"
                  name="times"
                  style={{ color: "white", fontSize: 30 }}
                />
              </Button>
            </View>
            <View
              style={{
                flexDirection: "column",
                justifyContent: "space-between",
                alignItems: "center",
                //marginTop: 20,
                height: "100%",
              }}
            >
              <PDFReader
                source={{
                  uri: this.state.pathFile,
                }}
                style={{ width: "90%", height: 500, zIndex: 1000 }}
              // useGoogleReader={Platform == 'ios' ? false : true}
              />
            </View>
          </View>
        </View>
      );
    } else {
      return <View />;
    }
  };
  render() {
    return (
      <>
        <View style={{ flex: 1 }}>
          <Spinner
            visible={this.state.spinner}
            color={"blue"}
            // textContent={"Please wait..."}
            textStyle={smallInputStyle}
          />
          {/* <FileSystemView /> */}
          <View>
            <Text style={[block_title, { fontWeight: "600" }]}>
              เลขที่เอกสาร:{" "}
              <Text style={{ fontWeight: "100" }}>{this.props.docno}</Text>
            </Text>
          </View>
          {this.beforeSaveModal()}
          <View>
            {this.state.approve_status == "Y" ||
              this.state.approve_status == "W" ? null : (
              <View
                style={{
                  width: "100%",
                  flexDirection: "row",
                  justifyContent: "center",
                }}
              >
                <View
                  style={{
                    // paddingHorizontal: 15,
                    paddingVertical: 10,
                    borderWidth: 1,
                    borderColor: "#0F1E43",
                    borderStyle: "dashed",
                    width: "45%",
                    // marginHorizontal: "3%",
                    marginVertical: 15,
                    // backgroundColor: "red"
                  }}
                >
                  {/* <Icon
                    style={{
                      fontSize: 50,
                      textAlign: "center",
                      color: "#0F1E43",
                    }}
                    type="FontAwesome"
                    name="cloud-upload"
                  /> */}
                  <Ionicons
                    name="document-attach"
                    size={50}
                    color="#0F1E43"
                    style={{ textAlign: "center" }}
                  />
                  <Text style={{ textAlign: "center" }}>
                    Drop file to upload
                  </Text>
                  {/* <TouchableOpacity onPress={() => this._pickImage()} style={{}}> */}
                  <TouchableOpacity
                    onPress={() => this._pickDoucment()}
                    style={{}}
                  >
                    <Text
                      style={{
                        textAlign: "center",
                        paddingHorizontal: 15,
                        paddingVertical: 10,
                        fontWeight: "bold",
                        fontSize: 22,
                        letterSpacing: 2,
                      }}
                    >
                      Folder
                    </Text>
                  </TouchableOpacity>
                </View>
                {/* {box 2} */}
                <View style={{ margin: 5 }} />
                <View
                  style={{
                    // paddingHorizontal: 15,
                    paddingVertical: 10,
                    borderWidth: 1,
                    borderColor: "#0F1E43",
                    borderStyle: "dashed",
                    width: "45%",
                    // marginHorizontal: "3%",
                    marginVertical: 15,
                  }}
                >
                  {/* <Icon
                    style={{
                      fontSize: 50,
                      textAlign: "center",
                      color: "#0F1E43",
                    }}
                    type="FontAwesome"
                    name="cloud-upload"
                  /> */}
                  <Entypo
                    name="images"
                    size={50}
                    color="#0F1E43"
                    style={{ textAlign: "center" }}
                  />
                  <Text style={{ textAlign: "center" }}>
                    Drop file to upload
                  </Text>
                  {/* <TouchableOpacity onPress={() => this._pickImage()} style={{}}> */}
                  <TouchableOpacity onPress={() => this._pickImg()} style={{}}>
                    <Text
                      style={{
                        textAlign: "center",
                        paddingHorizontal: 15,
                        paddingVertical: 10,
                        fontWeight: "bold",
                        fontSize: 22,
                        letterSpacing: 2,
                      }}
                    >
                      Media
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
            <View style={{ paddingHorizontal: 15 }}>
              <View
                style={{
                  width: "100%",
                  height: 2,
                  backgroundColor: "#D6D5D5",
                  opacity: 0.5,
                }}
              />
            </View>
            {/* {this.renderItem()} */}
            {/* <ScrollView> */}
            {/* <Card transparent>
              <CardItem style={customCard}> */}
            {/* <View
              style={{
                flexDirection: "row",
                textAlign: "center",
                // height: "65%",
                justifyContent: "center",
                alignItems: "center",
                flexWrap: "wrap",
                backgroundColor: "red",
                // minHeight: "90%",
                // justifyContent: "flex-start",
              }}
            > */}
            <View style={{ padding: 10 }}>
              <View
                style={{
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <FlatList
                  style={{ height: "75%" }}
                  data={this.state.shownDocList}
                  horizontal={false}
                  numColumns={3}
                  renderItem={this._renderItem}
                  keyExtractor={(item, index) => index.toString()}
                />
              </View>
            </View>
            {/* </CardItem>
            </Card> */}
            {/* </ScrollView> */}
          </View>
        </View>
        {/* </View> */}
        {/* {this.modalSelect()} */}
      </>
    );
  }
}

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: "center",
    // alignItems: "center",
    marginTop: 22,
  },
  BackgrounModal: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.3)",
  },
  modalView: {
    margin: 35,
    backgroundColor: "#fff",
    borderRadius: 20,
    padding: 25,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 10,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: "#F194FF",
  },
  buttonClose: {
    flex: 1,
    backgroundColor: "#0F1E43",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  textStyle: {
    color: "white",
    // fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
  line: {
    width: "100%",
    marginTop: 20,
    borderWidth: 1,
    borderColor: "#EBEDEF",
  },
});

export default AttachFile;
