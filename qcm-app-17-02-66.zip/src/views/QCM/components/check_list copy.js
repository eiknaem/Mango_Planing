import React, { Component } from 'react';
import { StyleSheet, Alert, View, Image, TouchableOpacity, ScrollView } from 'react-native'
import { Container, Root, Header, Title, Content, Footer, FooterTab, Button, Left, Right, Body, Icon, Text, Badge, Card, CardItem, H1, List, ListItem, Thumbnail, Switch, Tab, Tabs, TabHeading, ActionSheet } from 'native-base';
import { Circle } from 'react-native-svg';
import SvgPanZoom, { SvgPanZoomElement } from 'react-native-svg-pan-zoom';
import { LinearGradient } from 'expo-linear-gradient';
import {
  borderGrey,
  darkGreen,
  iconStyle,
  inputStyle,
  mangoGreen,
  red,
  grey,
  smallTextStyle,
  bg_header,
  btn_save,
  btn_text,
  menu_QCM,
  customCard,
  block_title,
  smallText,
  titleStyle,
  tinyTextStyle,
  smallInputStyle,
  blue,
  darkBlue,
  bgHeader
} from "../../../stylesheet/styles";

var BUTTONS = ["ไม่ตรวจ", "รูปภาพ", "หมายเหตุ", "ยกเลิก"];
var DESTRUCTIVE_INDEX = 3;
var CANCEL_INDEX = 4;

class Checklist extends React.Component {
  constructor(props) {
    super(props)
    this.state = {};
  }
  render() {
    return (
      <ScrollView style={{ flex: 1 }}>
        {/* ******************************** Card list Head*************************** */}
        <Text style={[block_title, { fontWeight: '800' }]}>Smile Land <Text style={{ fontWeight: '100' }}>PN2020060043</Text></Text>
        <Card transparent >
          <CardItem style={customCard}>
            <View style={{}}>
              <Text style={smallTextStyle}>ผลตรวจ :  <Text style={{ color: darkGreen }}>ผ่านแล้ว</Text></Text>
              <Text style={smallTextStyle}>จำนวนข้อตรวจทั้งหมด : <Text>16</Text></Text>
              <Text style={smallTextStyle}>จำนวนข้อที่ตรวจ  : <Text>16</Text></Text>
              <Text style={smallTextStyle}>จำนวนข้อที่ตรวจผ่าน : <Text>16</Text></Text>
              <Text style={smallTextStyle}>%ผ่าน เทียบกับข้อตรวจทั้งหมด : <Text>100</Text></Text>
              <Text style={smallTextStyle}>%ผ่าน เทียบกับข้อตรวจเท่าที่ตรวจ : <Text>100</Text></Text>
            </View>
          </CardItem>
        </Card>
        {/* ******************************** Card list *************************** */}
        <Card transparent style={{ padding: 0 }}>
          <CardItem style={[customCard, { padding: 10 }]}>
            <View style={{ marginHorizontal: -16 }}>
              <Text style={{ paddingHorizontal: 15 }}>1.1.1 <Text style={{ fontWeight: '600' }}>แผนงานอาคาร A</Text><Text>งานเดินสายไฟฟ้าห้อง 1</Text></Text>

              <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: '100%', marginTop: 15, marginBottom: -10, borderTopWidth: 1, borderColor: grey }}>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderBottomStartRadius: 10, borderLeftWidth: 1, borderColor: grey }}>
                  <Icon style={[{ color: mangoGreen, textAlign: 'center' }]} type="FontAwesome" name='check' />
                </Button>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderLeftWidth: 1, borderColor: grey }}>
                  <Icon style={[{ color: red, textAlign: 'center' }]} type="FontAwesome" name='times' />
                </Button>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderLeftWidth: 1, borderColor: grey }}>
                  <Icon style={[{ color: grey, textAlign: 'center' }]} type="FontAwesome" name='circle-o' />
                </Button>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderBottomEndRadius: 10, borderLeftWidth: 1, borderColor: grey }}
                  onPress={() =>
                    ActionSheet.show(
                      {
                        options: BUTTONS,
                        cancelButtonIndex: CANCEL_INDEX,
                        destructiveButtonIndex: DESTRUCTIVE_INDEX,
                        title: "เมนูเพิ่มเติม"
                      },
                      buttonIndex => {
                        this.setState({ select_menu: BUTTONS[buttonIndex] });
                        console.log("BUTTONS[buttonIndex]", BUTTONS[buttonIndex]);
                        if (this.state.select_menu == "รูปภาพ") {
                          this.props.navigation.push('Gallery')
                        }
                      }
                    )}
                >
                  <Icon ios='ios-menu' android="md-menu" style={{ fontSize: 30, color: darkBlue }} />
                </Button>
              </View>
            </View>
          </CardItem>
        </Card>
        <Card transparent style={{ padding: 0 }}>
          <CardItem style={[customCard, { padding: 10 }]}>
            <View style={{ marginHorizontal: -16 }}>
              <Text style={{ paddingHorizontal: 15 }}>1.1.1 <Text style={{ fontWeight: '600' }}>แผนงานอาคาร A</Text><Text>งานเดินสายไฟฟ้าห้อง 1</Text></Text>

              <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: '100%', marginTop: 15, marginBottom: -10, borderTopWidth: 1, borderColor: grey }}>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderBottomStartRadius: 10, borderLeftWidth: 1, borderColor: grey }}>
                  <Icon style={[{ color: mangoGreen, textAlign: 'center' }]} type="FontAwesome" name='check' />
                </Button>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderLeftWidth: 1, borderColor: grey }}>
                  <Icon style={[{ color: red, textAlign: 'center' }]} type="FontAwesome" name='times' />
                </Button>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderLeftWidth: 1, borderColor: grey }}>
                  <Icon style={[{ color: grey, textAlign: 'center' }]} type="FontAwesome" name='circle-o' />
                </Button>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderBottomEndRadius: 10, borderLeftWidth: 1, borderColor: grey }}
                  onPress={() =>
                    ActionSheet.show(
                      {
                        options: BUTTONS,
                        cancelButtonIndex: CANCEL_INDEX,
                        destructiveButtonIndex: DESTRUCTIVE_INDEX,
                        title: "เมนูเพิ่มเติม"
                      },
                      buttonIndex => {
                        this.setState({ select_menu: BUTTONS[buttonIndex] });
                        console.log("BUTTONS[buttonIndex]", BUTTONS[buttonIndex]);
                        if (this.state.select_menu == "รูปภาพ") {
                          this.props.navigation.push('Gallery')
                        }
                      }
                    )}
                >
                  <Icon ios='ios-menu' android="md-menu" style={{ fontSize: 30, color: darkBlue }} />
                </Button>
              </View>
            </View>
          </CardItem>
        </Card>
        <Card transparent style={{ padding: 0 }}>
          <CardItem style={[customCard, { padding: 10 }]}>
            <View style={{ marginHorizontal: -16 }}>
              <Text style={{ paddingHorizontal: 15 }}>1.1.1 <Text style={{ fontWeight: '600' }}>แผนงานอาคาร A</Text><Text>งานเดินสายไฟฟ้าห้อง 1</Text></Text>

              <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: '100%', marginTop: 15, marginBottom: -10, borderTopWidth: 1, borderColor: grey }}>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderBottomStartRadius: 10, borderLeftWidth: 1, borderColor: grey }}>
                  <Icon style={[{ color: mangoGreen, textAlign: 'center' }]} type="FontAwesome" name='check' />
                </Button>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderLeftWidth: 1, borderColor: grey }}>
                  <Icon style={[{ color: red, textAlign: 'center' }]} type="FontAwesome" name='times' />
                </Button>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderLeftWidth: 1, borderColor: grey }}>
                  <Icon style={[{ color: grey, textAlign: 'center' }]} type="FontAwesome" name='circle-o' />
                </Button>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderBottomEndRadius: 10, borderLeftWidth: 1, borderColor: grey }}
                  onPress={() =>
                    ActionSheet.show(
                      {
                        options: BUTTONS,
                        cancelButtonIndex: CANCEL_INDEX,
                        destructiveButtonIndex: DESTRUCTIVE_INDEX,
                        title: "เมนูเพิ่มเติม"
                      },
                      buttonIndex => {
                        this.setState({ select_menu: BUTTONS[buttonIndex] });
                        console.log("BUTTONS[buttonIndex]", BUTTONS[buttonIndex]);
                        if (this.state.select_menu == "รูปภาพ") {
                          this.props.navigation.push('Gallery')
                        }
                      }
                    )}
                >
                  <Icon ios='ios-menu' android="md-menu" style={{ fontSize: 30, color: darkBlue }} />
                </Button>
              </View>
            </View>
          </CardItem>
        </Card>
        <Card transparent style={{ padding: 0 }}>
          <CardItem style={[customCard, { padding: 10 }]}>
            <View style={{ marginHorizontal: -16 }}>
              <Text style={{ paddingHorizontal: 15 }}>1.1.1 <Text style={{ fontWeight: '600' }}>แผนงานอาคาร A</Text><Text>งานเดินสายไฟฟ้าห้อง 1</Text></Text>

              <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: '100%', marginTop: 15, marginBottom: -10, borderTopWidth: 1, borderColor: grey }}>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderBottomStartRadius: 10, borderLeftWidth: 1, borderColor: grey }}>
                  <Icon style={[{ color: mangoGreen, textAlign: 'center' }]} type="FontAwesome" name='check' />
                </Button>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderLeftWidth: 1, borderColor: grey }}>
                  <Icon style={[{ color: red, textAlign: 'center' }]} type="FontAwesome" name='times' />
                </Button>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderLeftWidth: 1, borderColor: grey }}>
                  <Icon style={[{ color: grey, textAlign: 'center' }]} type="FontAwesome" name='circle-o' />
                </Button>
                <Button style={{ width: '25%', justifyContent: 'center', backgroundColor: '#fff', borderRadius: 0, borderBottomEndRadius: 10, borderLeftWidth: 1, borderColor: grey }}
                  onPress={() =>
                    ActionSheet.show(
                      {
                        options: BUTTONS,
                        cancelButtonIndex: CANCEL_INDEX,
                        destructiveButtonIndex: DESTRUCTIVE_INDEX,
                        title: "เมนูเพิ่มเติม"
                      },
                      buttonIndex => {
                        this.setState({ select_menu: BUTTONS[buttonIndex] });
                        console.log("BUTTONS[buttonIndex]", BUTTONS[buttonIndex]);
                        if (this.state.select_menu == "รูปภาพ") {
                          this.props.navigation.push('Gallery')
                        }
                      }
                    )}
                >
                  <Icon ios='ios-menu' android="md-menu" style={{ fontSize: 30, color: darkBlue }} />
                </Button>
              </View>
            </View>
          </CardItem>
        </Card>
      </ScrollView>)
  }
}

export default Checklist