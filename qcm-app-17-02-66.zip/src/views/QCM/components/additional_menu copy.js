import React, { Component } from "react";
import {
  StyleSheet,
  Alert,
  View,
  Image,
  TouchableOpacity,
  ScrollView,
  TextInput,
  TouchableWithoutFeedback,
  Keyboard,
} from "react-native";
import {
  Container,
  Header,
  Title,
  Content,
  Button,
  Body,
  Icon,
  Text,
  List,
  ListItem,
  Input,
} from "native-base";
import * as ImagePicker from "expo-image-picker";
import * as FileSystem from "expo-file-system";
import Constants from "expo-constants";
import * as Location from "expo-location";
import * as Permissions from "expo-permissions";
import Modal from "react-native-modal";
import Swiper from "react-native-swiper";
import linq from "js-linq";
import Spinner from "react-native-loading-spinner-overlay";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Moment from "moment";
import { Datepicker } from "@ui-kitten/components";
import $xt from "../../../api/xtools";
import { BackSVG, CameraSvg, BinSVG } from "../../../svg/IconSVG";
import imageSearch from "../../../../assets/image_search.png";
import MessageBox from "../../../api/msg";
// import * as ImageManipulator from 'expo-image-manipulator';
import { manipulateAsync, FlipType, SaveFormat } from "expo-image-manipulator";
import {
  bg_header,
  btn_text,
  smallInputStyle,
} from "../../../stylesheet/styles";
import {
  reFormatPicture,
  addPicture,
  getPicture,
  removePicture,
  getLocation,
  getPermissionGallery,
} from "../../../api/qcm";

const $linq = (arr) => new linq(arr);
class AdditionalMenu extends React.Component {
  constructor(props) {
    // console.log("PROPS first", props);
    super(props);
    this.state = {
      lat: "",
      lng: "",
      file_path: [],
      previewModalShow: false,
      galleryModalShow: false,
      isModalVisible: false,
      title: "",
      path_file: [],
      spinner: false,
      gotoIndex: 0,
      date: new Date(),
      // check_date: new Date(),
      score: 0,
      remark: "",
      remarkHead: "",
      errorMsg: null,
      showQCType: false,
      type_period: "",
      disable: true,
      pickImage: false,
      gps_location: "",
      gps_location_coordinate: "",
    };
  }
  async UNSAFE_componentWillMount() {
    // console.log("PROPS second",this.props);
    await this._setItem();
    await this.createFilePath();
  }
  componentDidMount = async () => {
    let checkPermistion = await getPermissionGallery();
    let gps_location = await AsyncStorage.getItem("gps_location");
    let gps_location_coordinate = await AsyncStorage.getItem(
      "gps_location_coordinate"
    );
    console.log(
      "gps_location",
      gps_location,
      "gps_location_coordinate",
      gps_location_coordinate
    );

    this.setState({
      pickImage: checkPermistion.data,
      gps_location,
      gps_location_coordinate,
    });
    console.log("checkPermistion", checkPermistion);
  };
  componentWillUnmount() {
    this.setState = (state, callback) => {
      return;
    };
  }
  Header = () => (
    <Header
      transparent
      iosBarStyle={"light-content"}
      style={[
        bg_header,
        { flexDirection: "row", width: "100%", alignItems: "center" },
      ]}
    >
      <View style={{ width: "20%" }}>
        <Button
          transparent
          style={{ width: "100%", justifyContent: "flex-start" }}
          onPress={() => this.sentBack()}
        >
          <BackSVG />
        </Button>
      </View>
      <Body
        style={{ width: "70%", alignItems: "center", paddingVertical: 7.5 }}
      >
        <Title style={btn_text}>QCM</Title>
      </Body>

      <View style={{ width: "20%", position: "relative", right: 0 }}>
        {this.props.route.params.approve_status == "D" ? (
          <View
            style={{
              flex: 1,
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              marginLeft: 15,
            }}
          >
            <Button
              disabled={false}
              transparent
              style={{
                flex: 1,
                justifyContent: "flex-end",
              }}
              onPress={() => this.checkPermistion()}
            >
              <CameraSvg />
            </Button>
            {this.state.pickImage ? (
              <Button
                transparent
                style={{
                  flex: 1,
                  justifyContent: "flex-end",
                  marginLeft: 7.5,
                }}
                onPress={() => this._pickImage()}
              >
                <Image
                  style={{
                    resizeMode: "contain",
                    width: 25,
                    marginTop: 5,
                    aspectRatio: 50 / 50, // Image ratio
                  }}
                  source={imageSearch}
                />
              </Button>
            ) : null}
          </View>
        ) : null}
      </View>
    </Header>
  );

  sentBack = async () => {
    let item = {
      check_date: this.state.check_date,
      score: this.state.score,
      remark: this.state.remarkHead,
      item_number: this.props.route.params.item_number,
    };
    await this.props.route.params.itemUpdate(item);
    await this.props.navigation.navigate("QCM");
    // await this.props.route.params.itemUpdate(item);
  };
  _setItem = () => {
    console.log("PARAMS", this.props.route.params);
    let showQCType = this.props.route.params.showQCType;
    let date = this.props.route.params.check_date;
    let score = this.props.route.params.score;
    let remark = this.props.route.params.remark;
    let type_period = this.props.route.params.type_period;
    let reformatDate = date ? Moment(date).toDate() : new Date();
    console.log("TYPE_PERIOD", type_period);
    let disable = type_period == "Y" ? false : true;

    this.setState({
      check_date: reformatDate,
      score: score,
      remarkHead: remark,
      showQCType: showQCType,
      disable: disable,
    });
  };
  getLocation = async () => {
    // alert("this.getLocation")
    // let status_location = await Permissions.askAsync(Permissions.LOCATION);
    // console.log("status", status_location);
    // if (status_location.status !== "granted") {
    //   MessageBox.Alert(`Error`, "Permission to access location was denied");
    //   return false;
    // }

    let status_location = await Location.requestForegroundPermissionsAsync();

    console.log("status", status_location);
    if (status_location.status !== "granted") {
      MessageBox.Alert(`Error`, "Permission to access location was denied");
      return;
    }
    try {
      const location = await Location.getCurrentPositionAsync({});
      console.log("LOCATION 1 : ", location);
      const mangoLoc = await getLocation(
        location.coords.latitude,
        location.coords.longitude
      );
      const gps_location =
        ((mangoLoc || []).data[0] || {}).geo_data.location_fullname || "";
      this.setState({
        gps_location,
        location_y: location?.coords?.latitude,
        location_x: location?.coords?.longitude,
      });
    } catch {
      await $xt.sleep(4000); //5000 Success
      const location = await Location.getLastKnownPositionAsync({});
      console.log("LOCATION 2 : ", location);
      const mangoLoc = await getLocation(
        location.coords.latitude,
        location.coords.longitude
      );
      const gps_location =
        ((mangoLoc || []).data[0] || {}).geo_data.location_fullname || "";
      this.setState({
        gps_location,
        location_y: location?.coords?.latitude,
        location_x: location?.coords?.longitude,
      });
    }

    // const location = await Location.getCurrentPositionAsync({});
    // const mangoLoc = await getLocation(
    //   location.coords.latitude,
    //   location.coords.longitude
    // );
    // const gps_location =
    //   ((mangoLoc || []).data[0] || {}).geo_data.location_fullname || "";

    // if (status !== 'granted' && status_roll !== 'granted') {
    //     alert('Sorry, we need camera and camera roll permissions to make this work!');
    // }
    // const gps_location_coordinate = `${location.coords.latitude},${location.coords.longitude}`;

    // this.setState({
    //   gps_location,
    //   location_y: location.coords.latitude,
    //   location_x: location.coords.longitude,
    // });
  };
  checkPermistion = async () => {
    // if (Constants.platform.ios) {
    const { status } = await Permissions.askAsync(Permissions.CAMERA);
    const { status_roll } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
    // console.log("status", status_camera.status);
    //   console.log("status_roll", status_roll.status);
    //   console.log("status_location", status_location.status);
    if (status !== "granted" && status_roll !== "granted") {
      MessageBox.Alert(
        `Error`,
        "Sorry, we need camera permissions to make this work!"
      );
    } else {
      await this._capImage();
    }
    // }
  };
  _capImage = async () => {
    // this.setState({ spinner: true });
    // alert("this._capImage")
    try {
      let result = await ImagePicker.launchCameraAsync(
        {
          mediaTypes: ImagePicker.MediaTypeOptions.All,
          allowsEditing: false,
          // aspect: [4, 3],
          // base64: true,
          quality: 0.5,
        },
        await this.getLocation()
      );
      // console.log("RESULT : ",result);
      if (!result.cancelled) {
        this.setState({ previewModalShow: true, preview: result.uri });
      }
    } catch (E) {
      // alert(E);
      console.log(E);
    }
    // this.setState({ spinner: false });
  };
  _pickImage = async () => {
    try {
      let result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        // allowsEditing: true,
        aspect: [4, 3],
        quality: 0.3,
        // base64: true,
      });
      console.log("RESULT : ", result);
      if (!result.cancelled) {
        const split = result.uri.split("/");
        const fileName = split[split.length - 1];

        let fileInfo = await this.getFileInfo(result.uri);
        result.mimeType = result.type == "image" ? "image/png" : "video/mp4";
        result.size = fileInfo.size;
        result.name = fileName;
      }
      this.setState({
        previewModalShow: true,
        preview: result.uri,
        _file: result,
      });
      //console.log("result", result);
    } catch (E) {
      // alert(E);
      console.log(E);
    }
    // await this.truePath(this.state.image);
    this.setState({ spinner: false });
  };
  _ImageBase64 = async (uri) => {
    const editedImage = await manipulateAsync(
      uri,
      [
        {
          resize: {
            width: 500,
            height: 500,
          },
        },
      ],
      { base64: true }
    );
    this.setState({ preview: editedImage.base64 });
    // return editedImage.base64;
  };
  saveImage = async () => {
    try {
      console.log("this.state.preview...", this.state.preview);
      this.setState({ spinner: true, previewModalShow: false });
      // this.setState({ previewModalShow: false });
      let _docno = this.props.route.params.docno || "";
      let _item_number = this.props.route.params.item_number || "";
      let res = {
        // file: this._ImageBase64(this.state.preview),
        file: this.state._file,
        docno: _docno,
        item_number: _item_number,
        location_name: this.state.gps_location,
        location_x: this.state.gps_location_coordinate.split(",")[0],
        location_y: this.state.gps_location_coordinate.split(",")[1],
        remark: $xt.isEmpty(this.state.remark) ? "" : this.state.remark,
        // sizefile: fileInfo.size,
      };
      console.log(res);
      var rsp = await addPicture(res);
      console.log("rsp..", rsp);
    } catch (E) {
      let msg = MessageBox.Alert("Error", E.toString());
      console.log("msg...", msg);
      msg
        ? this.setState({
            spinner: false,
          })
        : null;
    }
    if (rsp.error) {
      MessageBox.Alert("Error", rsp.error);
    } else {
      await this.createFilePath();
    }
  };
  createFilePath = async () => {
    this.setState({ spinner: true });
    let _docno = this.props.route.params.docno || [];
    let _item_number = this.props.route.params.item_number || [];
    let picture = [];
    let getPic = await getPicture({ docno: _docno, item_number: _item_number });
    picture = getPic.data;
    // console.log("getPic", getPic);
    // console.log("picture", picture);
    // let path = (this.props.route.params.picture.data || [])
    // path = $linq(path).take(1).toArray();
    //let _file_path = (path.file_path || "");
    let getFile = [];
    //getFile =
    // const result = $linq(path).foreach(x => {
    //     return reFormatPicture(x.file_path);
    // })
    // const result = picture.map(async (x) => {
    //     return (
    //         await reFormatPicture(x.file_path)

    //     )
    // })
    // let xxx = await Promise.all(result)

    for (let xx in picture) {
      let x = picture[xx];
      x.file_path = await reFormatPicture(x.file_path);
    }
    // console.log("xxx", xxx);
    // console.log("picture", picture);
    this.setState({ path_file: picture, spinner: false });
    // this.setState({ spinner: false });
  };
  getFileInfo = async (fileURI) => {
    let fileInfo = await FileSystem.getInfoAsync(fileURI);
    return fileInfo;
  };
  _removePicture = async (item) => {
    // console.log(item);
    // console.log("DOCNO", item.docno);
    // console.log("ITEM_NUMBER", item.node_number);
    // console.log("ITEMNO", item.itemno);
    await removePicture({
      docno: item.docno,
      item_number: item.node_number,
      itemno: item.itemno,
    });
    await this.createFilePath();
    // await getPicture({ docno: item.docno, item_number: item.item_number });
    // console.log("SUCCESS");
  };
  toggleModal = (index) => {
    // console.log("index", index);
    this.setState({ gotoIndex: index });
    this.setState({ isModalVisible: !this.state.isModalVisible });
  };
  reviewModal = () => {
    if (this.state.previewModalShow) {
      return (
        <View style={{ flex: 1 }}>
          <Modal
            style={{ margin: 0, marginTop: 30 }}
            isVisible={this.state.previewModalShow}
          >
            <Content style={{ backgroundColor: "rgba(0,0,0,0.3)" }}>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Button
                  transparent
                  style={{
                    borderWidth: 1,
                    borderColor: "white",
                    marginLeft: 5,
                  }}
                  onPress={() => this.setState({ previewModalShow: false })}
                >
                  <Icon
                    type="FontAwesome"
                    name="times"
                    style={{ color: "white", fontSize: 30 }}
                  />
                </Button>
                <View>
                  <Text style={{ color: "white" }}>เพิ่มรายละเอียดงาน</Text>
                </View>
                <Button
                  transparent
                  style={{
                    borderWidth: 1,
                    borderColor: "white",
                    marginRight: 5,
                  }}
                  onPress={() => {
                    this.saveImage();
                  }}
                >
                  {/* <Icon type="FontAwesome" name="save"
                                        style={{ color: 'white', fontSize: 30 }} /> */}
                  <Text style={{ color: "white" }}>บันทึก</Text>
                </Button>
              </View>
              <View style={{ paddingHorizontal: 5, marginHorizontal: -15 }}>
                <List>
                  <ListItem>
                    <Input
                      style={{
                        width: "100%",
                        justifyContent: "center",
                        borderColor: "white",
                        borderWidth: 1,
                        color: "white",
                      }}
                      inlineLabel
                      label="NAME"
                      placeholder="ระบุรายละเอียด..."
                      onChangeText={(r) => this.setState({ remark: r })}
                    />
                  </ListItem>
                  {/* <Button
                                        transparent
                                        style={{ flexDirection: 'row', justifyContent: 'flex-start', width: '100%', borderColor: 'white', borderWidth: 1, color: 'white' }}
                                        onPress={() => this.getlocation()}>
                                        <Icon type="FontAwesome" name="map-marker" style={{ color: darkBlue, width: 30, justifyContent: 'center' }} />
                                        <Text style={{ width: 80, marginLeft: -30 }}>เช็คอิน</Text>
                                        <Text style={{ paddingLeft: 10, }}>{this.state.lat}{this.state.lat !== "" ? "," : ""}{this.state.lng}</Text>
                                    </Button> */}
                </List>
              </View>
              <View style={{}}>
                <Image
                  source={{ uri: this.state.preview }}
                  style={{
                    width: "100%",
                    height: 400,
                    justifyContent: "center",
                  }}
                ></Image>
              </View>
            </Content>
          </Modal>
        </View>
      );
    } else {
      return <View />;
    }
  };
  galleryModal = () => {
    if (this.state.isModalVisible) {
      return (
        <View
          style={{
            flex: 1,
            backgroundColor: "red",
            height: "100%",
            position: "absolute",
            zIndex: 1,
            width: "100%",
            alignSelf: "center",
          }}
        >
          <Button
            transparent
            style={{
              position: "absolute",
              right: 5,
              top: 5,
              zIndex: 2,
              borderWidth: 1,
              borderColor: "white",
            }}
            onPress={this.toggleModal}
          >
            <Icon
              type="FontAwesome"
              name="times"
              style={{ color: "white", fontSize: 30 }}
            />
          </Button>
          <View style={styles.container}>
            <Swiper
              style={styles.wrapper}
              showsButtons
              loop={false}
              index={this.state.gotoIndex}
              dot={
                <View
                  style={{
                    backgroundColor: "rgba(255,255,255,0.3)",
                    width: 10,
                    height: 10,
                    borderRadius: 5,
                    marginLeft: 5,
                    marginRight: 5,
                  }}
                />
              }
              activeDot={
                <View
                  style={{
                    backgroundColor: "#fff",
                    width: 13,
                    height: 13,
                    borderRadius: 7,
                    marginLeft: 7,
                    marginRight: 7,
                  }}
                />
              }
              nextButton={
                <Text style={styles.buttonText}>
                  <Icon
                    type="FontAwesome"
                    name="chevron-right"
                    style={{ color: "white", fontSize: 30 }}
                  ></Icon>
                </Text>
              }
              prevButton={
                <Text style={styles.buttonText}>
                  <Icon
                    type="FontAwesome"
                    name="chevron-left"
                    style={{ color: "white", fontSize: 30 }}
                  ></Icon>
                </Text>
              }
            >
              {this.state.path_file.map((item, i) => (
                <View key={i} style={{ flexDirection: "row", flex: 1 }}>
                  <View style={styles.slide1}>
                    <Image
                      source={{ uri: item.file_path }}
                      style={{
                        width: "100%",
                        height: "100%",
                        justifyContent: "center",
                      }}
                    ></Image>
                    <View
                      style={{
                        position: "absolute",
                        bottom: 50,
                        textAlign: "center",
                        borderColor: "gray",
                        borderWidth: 1,
                        borderRadius: 5,
                        padding: 15,
                        width: "96%",
                        backgroundColor: "rgba(255,255,255,0.3)",
                      }}
                    >
                      <Text style={{}}>รายละเอียด: {item.remark || ""}</Text>
                      <Text>
                        ที่อยู่:{" "}
                        {item.location_name != "undefined"
                          ? item.location_name
                          : "-"}
                      </Text>
                    </View>
                  </View>
                </View>
              ))}
            </Swiper>
          </View>
        </View>
      );
    } else {
      return <View />;
    }
  };
  /////////////////////////////////////take photo //////////////////////////////
  setDate(item, selectDate) {
    //this.state.item.check_date = selectDate;

    // console.log("DATE", Moment(selectDate).format('DD/MM/YYYY'));
    // console.log("sdfsdf",Moment(this.props.route.params.item.check_date).format('DD/MM/YYYY'));

    this.setState({ check_date: selectDate });
  }
  _setScore(score) {
    //this.state.item.score = $xt.dec(score, 2);
    this.setState({ score: score });
  }
  setRemark = (remark) => {
    //this.state.item.remark = remark;
    this.setState({ remarkHead: remark });
  };
  renderItem = () => {
    let approve_status = this.props.route.params.approve_status;

    return (
      <View
        style={{ flexDirection: "column", justifyContent: "space-between" }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            width: "100%",
            backgroundColor: "#0F1E43",
            paddingHorizontal: 15,
            paddingVertical: 20,
          }}
        >
          <View style={{ width: "50%", borderRadius: 20, marginRight: 10 }}>
            <Text style={{ color: "#fff", alignItems: "center" }}>
              วันที่ตรวจ:{" "}
            </Text>
            <Datepicker
              // disabled={approve_status != 'D' ? true : false}
              disabled={this.state.disable}
              style={{
                width: "100%",
                backgroundColor: "#E0E0E0",
                borderRadius: 5,
                height: 37,
                marginVertical: 5,
              }}
              placeholder="Select Date"
              date={this.state.check_date}
              onSelect={(dateText) => this.setDate(this.state.item, dateText)}
            />
          </View>

          <View style={{ width: "50%" }}>
            <Text style={{ color: "#fff", alignItems: "center" }}>คะแนน: </Text>
            <TextInput
              editable={approve_status != "D" ? false : true}
              style={{
                height: 40,
                borderColor: "#d3d3d3",
                borderWidth: 1,
                paddingHorizontal: 10,
                marginVertical: 5,
                width: "90%",
                borderRadius: 5,
                backgroundColor: "white",
              }}
              //onChangeText={(text) => this.setState({ score: text })}
              keyboardType="numeric"
              onChangeText={(score) => this._setScore(score)}
              placeholder="ระบุจำนวนคะแนน"
            >
              <Text style={{ color: "#8f9bb3" }}>{this.state.score}</Text>
            </TextInput>
          </View>
        </View>
        <View
          style={{
            flexDirection: "row",
            justifyContent: "flex-start",
            paddingHorizontal: 15,
            paddingVertical: 10,
            alignItems: "center",
          }}
        >
          <Text style={{ width: 80, paddingBottom: 5, alignItems: "center" }}>
            *หมายเหตุ:{" "}
          </Text>
          <TextInput
            editable={approve_status != "D" ? false : true}
            style={{
              minHeight: 50,
              marginHorizontal: 15,
              marginVertical: 5,
              width: "75%",
              flexWrap: "wrap",
              padding: 5,
              borderBottomWidth: 1,
              borderBottomColor: "#8f9bb3",
              borderRadius: 5,
            }}
            //onChangeText={(text) => this.setState({ score: text })}
            // keyboardType='numeric'
            onChangeText={(remark) => this.setRemark(remark)}
            placeholder="ระบุรายละเอียดของงาน"
          >
            <Text style={{ color: "#8f9bb3" }}>{this.state.remarkHead}</Text>
          </TextInput>
        </View>
      </View>
    );
  };
  renderImage = () => {
    let approve_status = this.props.route.params.approve_status;
    if (this.state.path_file != "") {
      var num = $linq(this.state.path_file).count();
      return this.state.path_file.map((item, i) => (
        <View
          key={i}
          style={{
            width: num == 1 ? "100%" : "50%",

            position: "relative",
          }}
        >
          <View style={{}}>
            <TouchableOpacity
              onPress={() => {
                this.toggleModal(i);
              }}
              style={{ width: "100%", padding: 10 }}
            >
              <View>
                <Image
                  source={{ uri: item.file_path }}
                  style={{
                    width: "100%",
                    minHeight: num == 1 ? 250 : 120,
                    justifyContent: "center",
                    borderRadius: 10,
                  }}
                ></Image>
              </View>
            </TouchableOpacity>
          </View>
          {approve_status == "D" ? (
            <Button
              onPress={() => {
                this._removePicture(item);
              }}
              style={{
                backgroundColor: "rgba(0,0,0,0.7)",
                position: "absolute",
                right: 10,
                top: 10,
                width: 40,
                height: 40,
                borderTopEndRadius: 10,
                borderBottomLeftRadius: 10,
              }}
            >
              <View
                style={{
                  width: "100%",
                  flexDirection: "row",
                  justifyContent: "center",
                }}
              >
                <BinSVG />
              </View>
            </Button>
          ) : null}
        </View>
      ));
    }
  };
  render() {
    return (
      <Container>
        {this.Header()}
        <Body padder>
          {/* #E0E0E0 */}
          <Spinner
            visible={this.state.spinner}
            color={"blue"}
            textContent={"Please wait..."}
            textStyle={smallInputStyle}
          />
          <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
            <View style={{ flex: 1, justifyContent: "space-between" }}>
              {this.reviewModal()}
              {this.galleryModal()}
              <View>{this.renderItem()}</View>
              <ScrollView style={{}}>
                <View
                  style={{
                    flex: 1,
                    flexDirection: "row",
                    flexWrap: "wrap",
                    paddingLeft: 5,
                    paddingRight: 5,
                  }}
                >
                  {this.renderImage()}
                </View>
              </ScrollView>
            </View>
          </TouchableWithoutFeedback>
        </Body>
      </Container>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  wrapper: {},

  slide: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "transparent",
  },

  slide1: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#9DD6EB",
  },

  slide2: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#97CAE5",
  },

  slide3: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#92BBD9",
  },

  text: {
    color: "#fff",
    fontSize: 30,
    fontWeight: "600",
  },

  image: {
    flex: 1,
  },
  picker: {
    width: "50%",
    backgroundColor: "red",
    borderRadius: 20,
  },
});
export default AdditionalMenu;
