﻿import React, { Component } from "react";
import {
  StyleSheet,
  Alert,
  View,
  KeyboardAvoidingView,
  TouchableOpacity,
  ScrollView,
  TextInput,
  SafeAreaView,
  FlatList,
} from "react-native";
import {
  Container,
  Header,
  Title,
  Content,
  Footer,
  FooterTab,
  Button,
  Body,
  Icon,
  Text,
  Switch,
  Tab,
  Tabs,
  TabHeading,
  List,
  ListItem,
  Input,
  Fab,
} from "native-base";
import Spinner from "react-native-loading-spinner-overlay";
import MessageBox from "../../api/msg";

import Draw from "./components/signature";
import AttachFile from "./components/attach_file";
import Document from "./components/document";
import linq from "js-linq";
import $xt from "../../api/xtools";
import Svg, { Path, Circle, G, Defs, ClipPath, Rect } from "react-native-svg";
import { BackSVG, OptionSVG, ChatSVG, DeleteSVG } from "../../svg/IconSVG";
import { Datepicker } from "@ui-kitten/components";
import {
  mangoGreen,
  red,
  grey,
  smallTextStyle,
  bg_header,
  btn_save,
  btn_revise,
  btn_text,
  customCard,
  block_title,
  tinyTextStyle,
  smallInputStyle,
} from "../../stylesheet/styles";
import {
  getCheckList,
  postReadList,
  postRevise,
  removePicture,
} from "../../api/qcm";

const $linq = (arr) => new linq(arr);
class QCM extends Component {
  //spinner = {}
  constructor(props) {
    super(props);
    // this.setDate = this.setDate.bind(this);
    this.state = {
      refreshing: false,
      spinner: false,
      checkStatus: "",
      unCheckStatus: "",
      disableBtn: false,
      beforeSaveModalShow: false,
      showModalSave: false,
      onCreateListShow: false,
      historyModalShow: false,
      showRemarkError: false,
      showQCType: false,
      remark: "",
      activeTab: 0,
      shownDocList: [],
      selectedDoc: {},
      image: "",
      signature: "",
      chosenDate: new Date(),
      resultShow: false,
      currentTab: 0,
      isEnabled: false,
      active: false,
      due_date: new Date(),
      saveButton: false,
      oneClick: false,
    };
  }
  async UNSAFE_componentWillMount() {}
  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }
  componentDidMount = async () => {
    await this.loadDocList();
    await this.checkApprove();
    global.isSaved = false
    // console.log("asdasd");
  };
  checkApprove = async () => {
    // console.log("5555");
    //Header = this.state.docHeader
    let _approve_status = this.state.docHeader.approve_status;
    let _sendapp = this.state.docHeader.sendapp;
    let _docapp = this.state.docHeader.docapp;
    //this.props.route.params
    let _docno = this.props.route.params.docno;
    let _pre_event2 = this.props.route.params.pre_event2;
    let _pre_event = this.props.route.params.pre_event;
    let _loccode = this.props.route.params.loccode;
    let _form_code = this.props.route.params.form_code;
    let _form_type = this.props.route.params.form_type;
    let _type_period = this.props.route.params.type_period;

    let arr = {
      _docno: _docno,
      _pre_event2: _pre_event2,
      _pre_event: _pre_event,
      _loccode: _loccode,
      _form_code: _form_code,
      _form_type: _form_type,
    };

    if (_approve_status == "W" && _sendapp != "Y" && $xt.isEmpty(_docapp)) {
      //เซ็นแล้ว แต่ยังไม่เลือก Loop Approve
      let messageBox = await MessageBox.Confirm(
        `Warning`,
        `${_docno} ส่งอนุมัติแล้ว ไปยังหน้า Submit Approve หรือไม่?`,
        `ยกเลิก`,
        `ตกลง`
      );
      if (messageBox) {
        this.props.navigation.push("SubmitApprove", {
          params: arr,
          header: this.state.docHeader,
        });
      }
    } else if (_approve_status == "W" && _sendapp == "Y" && _docapp != "Y") {
      //เอกสารอยู่ใน App Approve (_docapp == "N" || _docapp == "C")
      let messageBox = await MessageBox.Alert(
        `Warning`,
        `${_docno} อยู่ในระหว่างอนุมัติ`
      );
      if (messageBox) {
        // this.props.navigation.push('All_project');
        this.props.navigation.push("SubmitApprove", {
          params: arr,
          header: this.state.docHeader,
        });
      }
    }
    // else if(_approve_status == "W" && _sendapp == "N" && !$xt.isEmpty(this.state.docHeader.sig_qc_result)) {
    //   // await this._changeTab(3);
    //   let messageBox = await MessageBox.Alert(
    //     `Warning`,
    //     `กรุณาเซ็นเอกสาร ${_docno} นี้เพื่ออนุมัติ`
    //   );
    //   if (messageBox) {

    //   }
    // }
    else {
    }
  };
  loadDocList = async () => {
    this.setState({ refreshing: true });
    let _docno = this.props.route.params.docno;
    let _pre_event2 = this.props.route.params.pre_event2;
    let _pre_event = this.props.route.params.pre_event;
    let _loccode = this.props.route.params.loccode;
    let _form_code = this.props.route.params.form_code;
    let _form_type = this.props.route.params.form_type;
    let _type_period = this.props.route.params.type_period;
    let docs = [];

    docs = await getCheckList({
      docno: _docno,
      pre_event: _pre_event,
      loccode: _loccode,
      form_code: _form_code,
      form_type: _form_type,
    });

    if (docs.error) {
      MessageBox.Alert(`Error`, docs.error, `OK`);
      return;
    }

    let _approve_status = docs.data.header.approve_status;
    let _sendapp = docs.data.header.sendapp;
    let _docapp = docs.data.header.docapp;
    let arr = {
      _docno: _docno,
      _pre_event2: _pre_event2,
      _pre_event: _pre_event,
      _loccode: _loccode,
      _form_code: _form_code,
      _form_type: _form_type,
      _approve_status: _approve_status,
      _sendapp: _sendapp,
      _docapp: _docapp,
    };

    ////////////
    console.log("APPROVE", docs.data.header);
    console.log("form_data", docs.data.form_data);
    ////////////
    this.reformatDocList(docs.data.detail, docs.data.form_data.qc_type);
    this.setState({
      refreshing: false,
      docHeader: docs.data.header,
      sig_qc: docs.data.header.sig_qc_result || "",
      approve_status: docs.data.header.approve_status,
      sendapp: docs.data.header.sendapp,
      docapp: docs.data.header.docapp,
      _docno: _docno,
      _docs: docs,
      comment: docs.data.comment,
      file: docs.data.file,
      plan: docs.data.plan,
      obj: arr,
      // showQCType: docs.data.form_data.qc_type != "1" ? true : false,
      approveAppQCM: docs.data.approveAppQCM,
      _type_period: _type_period,
    });
  };

  reformatDocList = async (docList, qc_type) => {
    //////////////////
    console.log("qc_type", qc_type);
    if (qc_type != "1") {
      $linq(docList).foreach((x) => {
        x.node_number = x.item_number = x.itemno;
        x.check_item = "Y";
        x.item_name = x.remark;
      });
    }
    //////////////////
    this.setState({
      shownDocList: docList,
      showQCType: qc_type != "1" ? true : false,
    });
    this.calculateCheckList();
    await this.findParentNocal();
  };
  Header = () => (
    <Header
      transparent
      iosBarStyle={"light-content"}
      style={[
        bg_header,
        { flexDirection: "row", width: "100%", alignItems: "center" },
      ]}
    >
      <View style={{ width: "20%" }}>
        <Button
          transparent
          style={{ width: "100%", justifyContent: "flex-start" }}
          onPress={() => this.props.navigation.goBack()}
        >
          <BackSVG />
        </Button>
      </View>
      <Body
        style={{ width: "70%", alignItems: "center", paddingVertical: 7.5 }}
      >
        <Title style={btn_text}>QCM</Title>
      </Body>

      <View style={{ width: "20%" }}>
        <Button
          transparent
          style={{ width: "100%", justifyContent: "flex-end" }}
          onPress={() => this._Comment()}
        >
          <ChatSVG />
        </Button>
      </View>
    </Header>
  );
  _changeTab = async (activeTab) => {
    this.setState({ currentTab: activeTab });
  };
  _Comment = async () => {
    this.props.navigation.push("Comments", {
      dataFromParent: this.state.comment,
      docno: this.state._docno,
      params: this.state.obj,
      plan: this.state.plan,
    }); //Loading: this.loadDocList,
  };
  _checkRemark = async () => {
    if (this.state.remark === "") {
      this.setState({ showRemarkError: true });
      return;
    }
    const docList = this.state.shownDocList.map((doc) => {
      if (doc.item_number === this.state.selectedDoc.item_number) {
        doc.remark = this.state.remark;
        doc.check_date = this.state.check_date;
        doc.score = this.state.score;
        return doc;
      } else {
        return doc;
      }
    });
    await this.setState({
      remarkModalShow: false,
      remark: "",
      selectedDoc: {},
      docList,
      showRemarkError: false,
    });
  };
  _checkList = (item, type) => {
    this.setState({ selectedDoc: item });
    if (type === "check") {
      item.item_result = "Y";
      // this.setState({ showStatus: item.item_result });
    } else if (type === "uncheck") {
      item.item_result = "N";
      // this.setState({ showStatus: item.item_result });
    }
    item.check_date = new Date();
    this.setState({ showStatus: item.item_result }); //check_date: new Date()
    // this.setState({ shownDocList: docList });
    // this._renderStatusBG(item.item_result, type)
    // console.log("shownDocList", this.state.shownDocList);
    this.calculateCheckList();
  };
  _removeList = async (item) => {
    item.remove = "N";
    let i = 1;
    var _remove = $linq(this.state.shownDocList)
      .where((x) => x.remove != "N")
      .toArray();

    $linq(_remove).foreach((x) => {
      x.itemno = i;
      x.item_number = i;
      x.node_number = i;
      i++;
    });
    await this.setState({ shownDocList: _remove });
    await this._removeAllPicture(item);
    this.calculateCheckList();
    // console.log(_remove);
  };
  _removeAllPicture = async (item) => {
    console.log("ITEM", item);
    await removePicture({
      docno: item.docno,
      item_number: item.node_number,
    });
  };
  doNoCal(item, check) {
    //console.log("nocla");
    if (check == "Y") {
      item.no_cal = "N";
    } else {
      item.no_cal = "Y";
    }

    // this.setState({ isEnabled: !this.state.isEnabled });
    this.setState({ checked: item.no_cal });
    // item.item_number
    let findChildren = (parent) => {
      $linq(this.state.shownDocList)
        .where((y) => y.parent === parent)
        .foreach((y) => {
          y.no_cal = item.no_cal;
          y.parent_no_cal = null;
          findChildren(y.item_number);
        });
    };
    findChildren(item.item_number);
    this.findParentNocal();
    this.calculateCheckList();
  }
  findParentNocal() {
    $linq(this.state.shownDocList)
      .where((x) => x.no_cal === "Y")
      .foreach((x) => {
        x.parent_no_cal =
          !x.parent ||
          $linq(this.state.shownDocList).any(
            (y) => y.node_number === x.parent && y.no_cal !== "Y"
          )
            ? "Y"
            : null;
      });

    // console.log(this.state.shownDocList);
  }
  _renderStatusBG = (item, type) => {
    // console.log("item",this.state.selectedDoc);
    if (item.no_cal == "Y") {
      return "#E0E0E0";
    }

    if (item.item_result == "Y" && type == "check") {
      // console.log("check");
      return "#00B473";
    } else if (item.item_result == "N" && type == "uncheck") {
      // console.log("uncheck");
      return "#FF7878";
    } else {
      return "white";
      // console.log("none");
    }
  };

  _doSave = async (approve_status) => {
    let h = this.state.docHeader;
    h.qc_resuult = this.state.qc_resuult;
    h.total_item = this.state.total_items;
    h.qc_total_count = this.state.qc_total_counts;
    h.qc_pass_count = this.state.qc_pass_counts;
    h.pass_total_per = this.state.pass_total_pers;
    h.pass_check_per = this.state.pass_check_pers;
    h.approve_status = approve_status;

    if (this.state.showQCType) {
      $linq(this.state.shownDocList).foreach((x) => {
        x.remark = x.item_name;
        x.revise = 1;
      });
    }
    let res = {
      docno: this.props.route.params.docno,
      header: this.state.docHeader,
      detail: this.state.shownDocList,
    };

    return await postReadList(res);
  };
  onSave = async () => {
    this.setState({ showModalSave: !this.state.showModalSave });
    global.isSaved = true;
    if (this.state.history == "Y") {
      this.props.navigation.push("All_project");
    } else {
      await this.loadDocList();
    }
  };
  _updateList = async (approve_status) => {
    //คะแนน Header
    for (let [i, g] of this.state.shownDocList.entries()) {
      if (this.state.showQCType && $xt.isEmpty(g.item_name)) {
        let messageBox = await MessageBox.Alert(
          `Warning`,
          `กรุณาระบุหัวข้อตรวจในหัวข้อที่ ${g.itemno}`
        );
        if (messageBox) {
          this.flatListRef.scrollToIndex({
            animated: true,
            index: i,
            viewPosition: 0,
          });
          this.setState({ beforeSaveModalShow: false });
          return;
        }
        // this.flatListRef.scrollToIndex({ animated: true, index: i, viewPosition: 0 });
        // this.setState({ beforeSaveModalShow : false});
        // return;
      }
    }

    try {
      let resp = await this._doSave(approve_status);
      if (!resp.success) {
        throw resp.error;
      }
      await this.toggleModal();
      this.setState({ showModalSave: true });
    } catch (ex) {
      MessageBox.Alert(`Error`, ex.toString());
      console.log(ex.toString());
    }
  };
  toggleModal2 = () => {
    this.setState({ historyModalShow: !this.state.historyModalShow });
  };
  toggleModal3 = () => {
    this.setState({ onCreateListShow: !this.state.onCreateListShow });
  };
  setDue_date = (dateText) => {
    this.setState({ due_date: dateText });
  };
  historyModal = () => {
    if (this.state.historyModalShow) {
      return (
        <View
          style={{
            flex: 1,
            position: "absolute",
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            height: "100%",
            zIndex: 1,
          }}
        >
          <Content style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
            <View
              style={{
                width: "90%",
                marginHorizontal: "5%",
                marginTop: "50%",
                backgroundColor: "#0F1E43",
                padding: 10,
              }}
            >
              <Text style={{ color: "white", textAlign: "center" }}>
                เอกสารนี้จะถูกเก็บเป็นประวัติ ไม่สามารถแก้ไขได้อีก
              </Text>
              <View style={{ marginLeft: -15 }}>
                <List>
                  <ListItem>
                    <Datepicker
                      style={{
                        width: "100%",
                        backgroundColor: "#E0E0E0",
                        borderRadius: 5,
                        height: 37,
                        marginVertical: 5,
                      }}
                      placeholder="Select Date"
                      date={this.state.due_date}
                      onSelect={(dateText) => this.setDue_date(dateText)}
                    />
                  </ListItem>
                  <ListItem>
                    <Input
                      style={{
                        width: "90%",
                        justifyContent: "center",
                        color: "white",
                      }}
                      inlineLabel
                      label="NAME"
                      placeholder="ระบุรายละเอียด..."
                      onChangeText={(r) => this.setState({ remarkHistory: r })}
                    />
                  </ListItem>
                </List>
              </View>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Button
                  transparent
                  style={{ marginLeft: 5 }}
                  onPress={() => this.setState({ historyModalShow: false })}
                >
                  <Text style={{ color: "white" }}>ยกเลิก</Text>
                </Button>

                <Button
                  transparent
                  style={{ marginRight: 5 }}
                  onPress={() => {
                    this._updateHistory("D");
                  }}
                  disabled={this.state.oneClick}
                >
                  <Text style={{ color: "white" }}>บันทึก</Text>
                </Button>
              </View>
            </View>
          </Content>
        </View>
      );
    } else {
      return <View />;
    }
  };
  _updateHistory = async (approve_status) => {
    // let checkConfirm = await MessageBox.Confirm(`เอกสารนี้จะถูกเก็บเป็นประวัติ ไม่สามารถแก้ไขได้อีก`);
    this.setState({ oneClick: true });
    let res = {
      docno: this.props.route.params.docno,
      due_date: this.state.due_date,
      remark: this.state.remarkHistory,
    };
    //console.log("DOCNO", this.props.route.params.docno);
    //console.log("RES", res);
    // if (checkConfirm == true) {
    try {
      let resp0 = await this._doSave(approve_status); //QcTransaction_QcAppUpdate
      //console.log("RESP0", resp0);
      if (!resp0.success) {
        throw resp0.error;
      }
      let resp = await postRevise(res); //QcTransaction_QcAppCreateRevise
      console.log("RESP", resp);
      if (!resp.success) {
        throw resp.error;
      }
      await this.toggleModal();
      await this.toggleModal2();
      this.setState({ showModalSave: true, history: "Y" });
    } catch (ex) {
      MessageBox.Alert(`Error`, ex.toString());
      console.log(ex);
    }
    this.setState({ oneClick: false });
    // }
  };
  toggleModal = (index) => {

    this.setState({ beforeSaveModalShow: !this.state.beforeSaveModalShow });
  };
  showStatusSave = () => {
    if (this.state.showModalSave) {
      return (
        <View
          style={{
            flex: 1,
            position: "absolute",
            left: 0,
            right: 0,
            top: 0,
            height: "100%",
            zIndex: 1,
          }}
        >
          <View
            style={{
              backgroundColor: "rgba(0,0,0,0.5)",
              flex: 1,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <View
              style={{
                // flex: 1,
                justifyContent: "center",
                alignItems: "center",
                backgroundColor: "#0F1E43",
                paddingVertical: 30,
                borderRadius: 5,
                width: "80%",
                textAlign: "center",
              }}
            >
              <Text style={{ color: "#fff", fontSize: 24 }}>
                บันทึกข้อมูลเรียบร้อยแล้ว
              </Text>
              <TouchableOpacity
                transparent
                style={{
                  marginVertical: 15,
                  backgroundColor: "#fff",
                  borderRadius: 5,
                  paddingVertical: 7.5,
                  paddingHorizontal: 20,
                }}
                onPress={() => {
                  this.onSave();
                }}
              >
                <Text
                  style={{
                    color: "#0F1E43",
                    textAlign: "center",
                    fontSize: 23,
                  }}
                >
                  ตกลง
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      );
    } else {
      return <View />;
    }
  };
  beforeSaveModal = () => {
    if (this.state.beforeSaveModalShow) {
      return (
        <View
          style={{
            flex: 1,
            position: "absolute",
            left: 0,
            right: 0,
            top: 0,
            height: "100%",
            zIndex: 1,
          }}
        >
          <Content style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "flex-end",
                textAlign: "right",
                justifyContent: "flex-end",
              }}
            >
              <Button
                transparent
                style={{
                  borderWidth: 1,
                  borderColor: "white",
                  marginHorizontal: "5%",
                  marginTop: Platform.OS === "ios" ? 30 : 45,
                }}
                onPress={this.toggleModal}
              >
                <Icon
                  type="FontAwesome"
                  name="times"
                  style={{ color: "white", fontSize: 30 }}
                />
              </Button>
            </View>
            <View
              style={{
                flexDirection: "column",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Button
                transparent
                style={{
                  borderWidth: 1,
                  borderColor: "white",
                  marginVertical: 15,
                  paddingVertical: 100,
                  backgroundColor: "#fff",
                  height: 100,
                  borderRadius: 5,
                  marginHorizontal: "5%",
                }}
                onPress={() => {
                  this._updateList("D");
                }}
              >
                <Text
                  style={{
                    color: "#0F1E43",
                    textAlign: "center",
                    width: "100%",
                    fontSize: 23,
                  }}
                >
                  บันทึกเป็นแบบร่าง
                </Text>
              </Button>
              <Button
                transparent
                style={{
                  borderWidth: 1,
                  borderColor: "white",
                  marginVertical: 15,
                  paddingVertical: 100,
                  backgroundColor: "#fff",
                  height: 100,
                  borderRadius: 5,
                  marginHorizontal: "5%",
                }}
                onPress={this.toggleModal2}
              >
                {/* onPress={() => { this._updateHistory("D") }}> */}
                <Text
                  style={{
                    color: "#0F1E43",
                    textAlign: "center",
                    width: "100%",
                    fontSize: 23,
                  }}
                >
                  บันทึกเก็บประวัติ
                </Text>
              </Button>
              {this.state.saveButton ? (
                <Button
                  transparent
                  style={{
                    borderWidth: 1,
                    borderColor: "white",
                    marginVertical: 15,
                    paddingVertical: 100,
                    backgroundColor: "#fff",
                    height: 100,
                    borderRadius: 5,
                    marginHorizontal: "5%",
                  }}
                  onPress={() => {
                    this._updateList("W");
                  }}
                >
                  <Text
                    style={{
                      color: "#0F1E43",
                      textAlign: "center",
                      width: "100%",
                      fontSize: 23,
                    }}
                  >
                    บันทึกส่งอนุมัติ
                  </Text>
                </Button>
              ) : null}
            </View>
          </Content>
        </View>
      );
    } else {
      return <View />;
    }
  };
  // onCreateList = () => {
  //   if (this.state.onCreateListShow) {
  //     return (
  //       <View
  //         style={{
  //           flex: 1,
  //           position: "absolute",
  //           left: 0,
  //           right: 0,
  //           top: "50%",
  //           height: "30%",
  //           zIndex: 1,
  //         }}
  //       >
  //         <Content style={{ backgroundColor: "rgba(0,0,0,1)" }}>
  //           <View
  //             style={{
  //               paddingVertical: "5%",
  //               justifyContent: "center",
  //               flexDirection: "column",
  //               width: "94%",
  //               marginHorizontal: "3%",
  //             }}
  //           >
  //             <TextInput
  //               style={{
  //                 height: 100,
  //                 borderColor: "#d3d3d3",
  //                 borderWidth: 1,
  //                 paddingHorizontal: 10,
  //                 marginVertical: 15,
  //                 width: "100%",
  //                 borderRadius: 5,
  //                 backgroundColor: "white",
  //               }}
  //               onChangeText={(text) => this._setTitleList(text)}
  //               placeholder="ระบุชื่อหัวข้อตรวจ"
  //             >
  //               <Text style={{ color: "#8f9bb3" }}>{this.state.titleList}</Text>
  //             </TextInput>
  //             <View
  //               style={{
  //                 flexDirection: "row",
  //                 justifyContent: "center",
  //                 alignItems: "center",
  //               }}
  //             >
  //               <Button
  //                 transparent
  //                 style={{
  //                   borderWidth: 1,
  //                   borderColor: "white",
  //                   marginHorizontal: "5%",
  //                 }}
  //                 onPress={this.toggleModal3}
  //               >
  //                 <Text style={{ color: "white" }}>ยกเลิก</Text>
  //               </Button>
  //               <Button
  //                 transparent
  //                 style={{
  //                   borderWidth: 1,
  //                   borderColor: "white",
  //                   marginHorizontal: "5%",
  //                 }}
  //                 onPress={() => {
  //                   this.createCheckList();
  //                   this.toggleModal3();
  //                 }}
  //               >
  //                 {/* <Icon type="FontAwesome" name="save"
  //                                       style={{ color: 'white', fontSize: 30 }} /> */}
  //                 <Text style={{ color: "white" }}>บันทึก</Text>
  //               </Button>
  //             </View>
  //           </View>
  //         </Content>
  //       </View>
  //     );
  //   } else {
  //     return <View />;
  //   }
  // };
  _setTitleList = (title, item) => {
    item.item_name = title;
    this.setState({ titleList: title });
  };
  calculateCheckList = () => {
    let pmm = new Promise((rs, rj) => {
      let q = $linq(this.state.shownDocList);
      //total item
      let total_item = q
        .where((x) => x.check_item === "Y" && x.no_cal !== "Y")
        .count();
      //total  item per
      let total_item_per = $xt.dec(
        q
          .where((x) => x.check_item === "Y" && x.no_cal !== "Y")
          .sum((x) => x.item_per || 0) || 0,
        2
      );

      //total check item
      let qc_total_count = q
        .where((x) => !$xt.isEmpty(x.item_result) && x.no_cal !== "Y")
        .count();
      let qc_total_per = $xt.dec(
        q
          .where((x) => !$xt.isEmpty(x.item_result) && x.no_cal !== "Y")
          .sum((x) => x.item_per || 0) || 0,
        2
      );
      //total pass count
      let qc_pass_count = q
        .where((x) => x.item_result === "Y" && x.no_cal !== "Y")
        .count();
      // pass per
      let pass_per = $xt.dec(
        q
          .where((x) => x.item_result === "Y" && x.no_cal !== "Y")
          .sum((x) => x.item_per || 0),
        2
      );

      let pass_check_per = 0;
      let pass_total_per = 0;
      let _result = "";
      // let saveButton = false;

      if (this.state.showQCType) {
        //ตรวจอิสระ
        pass_total_per =
          total_item == 0 ? 0 : $xt.dec((qc_total_count / total_item) * 100, 2);
        pass_check_per =
          qc_total_count == 0
            ? 0
            : $xt.dec((qc_pass_count / qc_total_count) * 100, 2);

        //Check Save Button & qc_resuult
        if (this.state.pass_check_per == 100) {
          this.state.saveButton = true;
          _result = "Y";
        } else {
          this.state.saveButton = false;
          _result = "N";
        }
      } else {
        pass_total_per =
          pass_per == 0 ? 0 : $xt.dec((pass_per / total_item_per) * 100, 2);
        pass_check_per =
          qc_total_count == 0 ? 0 : $xt.dec((pass_per / qc_total_per) * 100, 2);

        //Check Save Button & qc_resuult
        if (this.state.pass_total_pers == 100) {
          this.state.saveButton = true;
          _result = "Y";
        } else {
          this.state.saveButton = false;
          _result = "N";
        }
      }

      this.setState({
        // saveButton: saveButton,
        qc_resuult: _result,
        total_items: total_item, //จำนวนข้อตรวจทั้งหมด
        qc_total_counts: qc_total_count, //จำนวนข้อที่ตรวจ
        qc_pass_counts: qc_pass_count, //จำนวนข้อที่ตรวจผ่าน
        pass_total_pers: pass_total_per, // % ผ่าน เทียบกับข้อตรวจทั้งหมด
        pass_check_pers: pass_check_per, // % ผ่าน เทียบกับข้อตรวจเท่าที่ตรวจ
      });

      rs();
    });
    pmm.then(() => {});
  };
  createCheckList = async () => {
    var _tem_number = $linq(this.state.shownDocList).count();
    var setItem_number = _tem_number + 1;
    var newList = {
      docno: this.state._docno,
      check_item: "Y",
      item_result: "N",
      itemno: setItem_number,
      item_number: setItem_number,
      node_number: setItem_number,
      revise: 1,
    };
    await this.setState({
      shownDocList: [...this.state.shownDocList, ...[newList]],
    });
    this.flatListRef.scrollToEnd({ animated: true });
    this.calculateCheckList();
    // console.log("create", this.state.shownDocList);
  };
  itemUpdate = (data) => {
    this.setState({ dateRevise: data.check_date, remarkRevise: data.remark });
    $linq(this.state.shownDocList)
      .where((x) => x.item_number == data.item_number)
      .foreach((x) => {
        x.check_date = data.check_date;
        x.score = data.score;

        if (this.state.showQCType) {
          x.remark2 = data.remark;
        } else {
          x.remark = data.remark;
        }
      });
    // console.log("UPDATE", this.state.shownDocList)
  };
  findParentNocal() {
    $linq(this.state.shownDocList)
      .where((x) => x.no_cal === "Y")
      .foreach((x) => {
        x.parent_no_cal =
          !x.parent ||
          $linq(this.state.shownDocList).any(
            (y) => y.node_number === x.parent && y.no_cal !== "Y"
          )
            ? "Y"
            : null;
      });
  }
  _result = () => {
    // console.log("qc_total_counts",this.state.qc_total_counts);
    console.log("pass_check_pers...", this.state.pass_check_pers);
    switch (this.state.showQCType) {
      case true:
        if (this.state.pass_check_pers == 100) {
          this.state.saveButton = true;
          return "Y";
        } else {
          this.state.saveButton = false;
          return "N";
        }
      // break;
      case false:
        if (this.state.pass_total_pers == 100) {
          this.state.saveButton = true;
          return "Y";
        } else {
          this.state.saveButton = false;
          return "N";
        }
      // break;
    }
  };
  resultColor = () => {
    switch (this.state.showQCType) {
      case true:
        if (this.state.pass_check_pers == 100) {
          return "green";
        } else {
          return "red";
        }
        break;
      case false:
        if (this.state.pass_total_pers == 100) {
          return "green";
        } else {
          return "red";
        }
        break;
    }
  };
  renderItem = ({ item }) => {
    let approve_status = this.state.approve_status;
    return this.state.showQCType ? (
      <View style={{ paddingHorizontal: 15 }}>
        <View
          style={{
            marginLeft: 20,
            borderBottomWidth: 1,
            paddingVertical: 15,
            borderBottomColor: "#C4C4C4",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              width: "100%",
              paddingRight: 40,
            }}
          >
            <Text style={{ fontSize: item.item_type == "H" ? 18 : 16 }}>
              {/* {item.item_number}.{" "} */}
              {item.itemno}
            </Text>
            <TextInput
              style={{
                height: 40,
                borderColor: "#d3d3d3",
                borderWidth: 1,
                paddingHorizontal: 10,
                marginVertical: 5,
                width: "90%",
                borderRadius: 5,
              }}
              onChangeText={(text) => this._setTitleList(text, item)}
              placeholder="ระบุหัวข้อตรวจ"
            >
              <Text style={{ color: "#8f9bb3" }}>{item.item_name}</Text>
            </TextInput>
            <TouchableOpacity
              transparent
              onPress={() =>
                this.props.navigation.push("AdditionalMenu", {
                  docno: this.state._docno,
                  approve_status: this.state.approve_status,
                  item_number: item.item_number,
                  check_date: item.check_date || null,
                  score: item.score || null,
                  remark: this.state.showQCType ? item.remark2 : item.remark,
                  itemUpdate: this.itemUpdate,
                  showQCType: this.state.showQCType,
                  type_period: this.state._type_period,
                })
              }
              style={{ position: "absolute", right: 0, top: 5 }}
            >
              <OptionSVG />
            </TouchableOpacity>
          </View>
          <View
            style={{ flexDirection: "row", justifyContent: "space-evenly" }}
          >
            <Button
              transparent
              disabled={
                item.no_cal == "Y" || approve_status != "D" ? true : false
              }
              onPress={() => {
                this._checkList(item, "check");
              }}
            >
              <Svg width="25" height="25" viewBox="0 0 20 20" fill="none">
                <Circle
                  cx="10"
                  cy="10"
                  r="9.5"
                  fill={this._renderStatusBG(item, "check")}
                  stroke="black"
                />
              </Svg>
              <Text style={{ marginLeft: -10, color: "#01D663" }}>ผ่าน</Text>
              <Text
                style={{
                  marginLeft: -20,
                  color: "#01D663",
                  textAlign: "left",
                }}
              ></Text>
            </Button>
            <Button
              transparent
              disabled={
                item.no_cal == "Y" || approve_status != "D" ? true : false
              }
              onPress={() => {
                this._checkList(item, "uncheck");
              }}
            >
              <Svg width="25" height="25" viewBox="0 0 20 20" fill="none">
                <Circle
                  cx="10"
                  cy="10"
                  r="9.5"
                  fill={this._renderStatusBG(item, "uncheck")}
                  stroke="black"
                />
              </Svg>
              <Text style={{ marginLeft: -10, color: "#FF7878" }}>ไม่ผ่าน</Text>
              <Text
                style={{
                  marginLeft: -20,
                  color: "#FF7878",
                  textAlign: "left",
                }}
              ></Text>
            </Button>
            {(this.state.approve_status || "D") == "D" ? (
              <Button
                transparent
                style={{
                  paddingHorizontal: 10,
                  position: "absolute",
                  right: 0,
                }}
                onPress={() => {
                  this._removeList(item);
                }}
              >
                <DeleteSVG />
              </Button>
            ) : null}
          </View>
        </View>
      </View>
    ) : (
      <View style={{ paddingHorizontal: 15 }}>
        {item.item_type != "D" ? (
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              width: "100%",
              borderBottomWidth: 1,
              borderBottomColor: "#C4C4C4",
              paddingVertical: 15,
            }}
          >
            <Text
              style={{
                fontSize: item.item_type == "H" ? 18 : 16,
                width: "75%",
              }}
            >
              {item.item_number}.{" "}
              <Text
                style={{
                  fontWeight: "600",
                  fontSize: item.item_type == "H" ? 18 : 16,
                }}
              >
                {item.item_name}
              </Text>
            </Text>
            <View
              style={{
                alignItems: "center",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "flex-start",
                width: 100,
              }}
            >
              <Switch
                disabled={approve_status != "D" ? true : false}
                trackColor={{ false: "#51b84f", true: "#767577" }}
                thumbColor={item.no_cal == "Y" ? "#fff" : "#fff"}
                ios_backgroundColor="#51b84f"
                onValueChange={() => {
                  this.doNoCal(item, item.no_cal);
                }}
                value={item.no_cal == "Y" ? true : false}
              />
              <View style={{ alignItems: "center", justifyContent: "center" }}>
                <Text style={{ marginLeft: 10, fontSize: 15, color: "#000" }}>
                  {item.no_cal == "Y" ? "ไม่ตรวจ" : "ตรวจ"}
                </Text>
              </View>
            </View>
          </View>
        ) : (
          <View
            style={{
              marginLeft: 20,
              borderBottomWidth: 1,
              paddingVertical: 15,
              borderBottomColor: "#C4C4C4",
            }}
          >
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                width: "100%",
                paddingRight: 40,
              }}
            >
              <View style={{}}>
                <Text style={{ fontSize: item.item_type == "H" ? 18 : 16 }}>
                  {item.item_number}.{" "}
                  <Text
                    style={{
                      fontWeight: "600",
                      fontSize: item.item_type == "H" ? 18 : 16,
                    }}
                  >
                    {item.item_name}
                  </Text>
                </Text>
              </View>
              <TouchableOpacity
                transparent
                onPress={() =>
                  this.props.navigation.push("AdditionalMenu", {
                    docno: this.state._docno,
                    approve_status: this.state.approve_status,
                    item_number: item.item_number,
                    check_date: item.check_date || null,
                    score: item.score || null,
                    remark: this.state.showQCType ? item.remark2 : item.remark,
                    itemUpdate: this.itemUpdate,
                    showQCType: this.state.showQCType,
                    type_period: this.state._type_period,
                  })
                }
                style={{ position: "absolute", right: 0, top: -10 }}
              >
                <OptionSVG />
              </TouchableOpacity>
            </View>
            <View style={{ flexDirection: "row", flex: 1 }}>
              <View style={{ flexDirection: "row", flex: 1 }}>
                <View
                  style={{ alignItems: "center", justifyContent: "center" }}
                >
                  <Switch
                    disabled={approve_status != "D" ? true : false}
                    trackColor={{ false: "#51b84f", true: "#767577" }}
                    thumbColor={item.no_cal == "Y" ? "#fff" : "#fff"}
                    ios_backgroundColor="#51b84f"
                    onValueChange={() => {
                      this.doNoCal(item, item.no_cal);
                    }}
                    value={item.no_cal == "Y" ? true : false}
                  />
                </View>
                <View
                  style={{
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 30,
                  }}
                >
                  <Text style={{ marginLeft: 10, fontSize: 15, color: "#000" }}>
                    {item.no_cal == "Y" ? "ไม่ตรวจ" : "ตรวจ"}
                  </Text>
                </View>
              </View>
              <View style={{ flexDirection: "row", width: 200 }}>
                <Button
                  transparent
                  style={{ width: "40%" }}
                  disabled={
                    item.no_cal == "Y" || approve_status != "D" ? true : false
                  }
                  onPress={() => {
                    this._checkList(item, "check");
                  }}
                >
                  <Svg width="25" height="25" viewBox="0 0 20 20" fill="none">
                    <Circle
                      cx="10"
                      cy="10"
                      r="9.5"
                      fill={this._renderStatusBG(item, "check")}
                      stroke="black"
                    />
                  </Svg>
                  <Text style={{ marginLeft: -10, color: "#01D663" }}>
                    ผ่าน
                  </Text>
                  <Text
                    style={{
                      marginLeft: -20,
                      color: "#01D663",
                      width: "80%",
                      textAlign: "left",
                    }}
                  ></Text>
                </Button>
                <Button
                  transparent
                  style={{ width: "50%" }}
                  disabled={
                    item.no_cal == "Y" || approve_status != "D" ? true : false
                  }
                  onPress={() => {
                    this._checkList(item, "uncheck");
                  }}
                >
                  <Svg width="25" height="25" viewBox="0 0 20 20" fill="none">
                    <Circle
                      cx="10"
                      cy="10"
                      r="9.5"
                      fill={this._renderStatusBG(item, "uncheck")}
                      stroke="black"
                    />
                  </Svg>
                  <Text style={{ marginLeft: -10, color: "#FF7878" }}>
                    ไม่ผ่าน
                  </Text>
                  <Text
                    style={{
                      marginLeft: -20,
                      color: "#FF7878",
                      width: "80%",
                      textAlign: "left",
                    }}
                  ></Text>
                </Button>
              </View>
            </View>
          </View>
        )}
      </View>
    );
  };
  renderFooter = () => {
    if (
      this.state.currentTab == 0 &&
      (this.state.approve_status || "D") == "D"
    ) {
      return (
        <Footer>
          <FooterTab style={{ backgroundColor: "white" }}>
            <Button style={btn_save} onPress={this.toggleModal}>
              <Text style={btn_text}>บันทึก</Text>
            </Button>
          </FooterTab>
        </Footer>
      );
    } else {
      return null;
    }
  };
  List = () => (
    <SafeAreaView style={{}}>
      <FlatList
        ref={(ref) => {
          this.flatListRef = ref;
        }}
        contentContainerStyle={{
          paddingBottom: Platform.OS == "ios" ? 65 : 65,
        }}
        extraData={this.state.refreshing}
        data={this.state.shownDocList}
        onRefresh={this.loadDocList}
        refreshing={this.state.refreshing}
        initialNumToRender={10} // Reduce initial render amount
        maxToRenderPerBatch={5} // Reduce number in each render batch
        windowSize={3} // Reduce the window size
        renderItem={this.renderItem}
        keyExtractor={(item, index) => index.toString()}
        removeClippedSubviews={false}
      />
    </SafeAreaView>
  );
  render() {
    let { signature } = this.state;
    return (
      <Container>
        {this.Header()}
        {this.beforeSaveModal()}
        {this.showStatusSave()}
        {this.historyModal()}
        {/* {this.onCreateList()} */}
        <Body style={{ flex: 1 }}>
          <Spinner
            visible={this.state.spinner}
            color={"blue"}
            textContent={"Please wait..."}
            textStyle={smallInputStyle}
          />

          {/* <Content> */}
          {/* ************************************** Data Content******************************* */}
          {/* ตัวแปร ใน event i, ref, from */}
          <Tabs
            tabContainerStyle={{ backgroundColor: "#0F1E43", elevation: 0 }}
            tabBarUnderlineStyle={{ height: 0 }}
            locked
            onChangeTab={({ i }) => this._changeTab(i)}
          >
            <Tab
              heading={
                <TabHeading
                  style={[
                    this.state.currentTab == 0
                      ? styles.activeTabStyle
                      : styles.inactiveTabStyle,
                    { flexDirection: "column", paddingVertical: 10 },
                  ]}
                >
                  {/* <ListSVG /> */}
                  <Svg width="24" height="24" viewBox="0 0 24 24" fill="red">
                    <Path
                      d="M3.5 5.5L5 7L7.5 4.5"
                      stroke={this.state.currentTab == 0 ? "black" : "white"}
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <Path
                      d="M3.5 11.5L5 13L7.5 10.5"
                      stroke={this.state.currentTab == 0 ? "black" : "white"}
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <Path
                      d="M3.5 17.5L5 19L7.5 16.5"
                      stroke={this.state.currentTab == 0 ? "black" : "white"}
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <Path
                      d="M11 6H20"
                      stroke={this.state.currentTab == 0 ? "black" : "white"}
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <Path
                      d="M11 12H20"
                      stroke={this.state.currentTab == 0 ? "black" : "white"}
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <Path
                      d="M11 18H20"
                      stroke={this.state.currentTab == 0 ? "black" : "white"}
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </Svg>
                  <Text
                    style={[
                      this.state.currentTab == 0
                        ? styles.activeTabStyle
                        : styles.inactiveTabStyle,
                      { fontWeight: "300", fontSize: 15 },
                    ]}
                  >
                    รายการ
                  </Text>
                </TabHeading>
              }
            >
              {/* ******************************** Card list Head*************************** */}
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  paddingRight: 10,
                  justifyContent: "space-between",
                }}
              >
                <Text
                  style={[block_title, { fontWeight: "600", width: "80%" }]}
                >
                  เลขที่เอกสาร:{" "}
                  <Text style={{ fontWeight: "100" }}>
                    {this.props.route.params.docno}
                  </Text>
                </Text>
                <Text style={{ color: this.resultColor(), fontWeight: "100" }}>
                  {this._result() == "Y" ? "ผ่านแล้ว" : "ยังไม่ผ่าน"}
                </Text>
              </View>
              <KeyboardAvoidingView
                behavior={Platform.OS == "ios" ? "padding" : "height"}
                keyboardVerticalOffset={Platform.OS == "ios" ? 150 : 0}
              >
                {this.List()}
                {/* <View style={{ marginBottom: Platform.OS == "ios" ? 0 : 100 }} /> */}
              </KeyboardAvoidingView>
              {this.state.showQCType &&
              (this.state.approve_status || "D") == "D" ? (
                <Fab
                  active={this.state.active}
                  direction="up"
                  containerStyle={{}}
                  style={{ backgroundColor: "#0F1E43" }}
                  position="bottomLeft"
                  onPress={() => this.createCheckList()}
                >
                  <Icon name="add" />
                </Fab>
              ) : null}
            </Tab>
            <Tab
              heading={
                <TabHeading
                  style={[
                    this.state.currentTab == 1
                      ? styles.activeTabStyle
                      : styles.inactiveTabStyle,
                    { flexDirection: "column", paddingVertical: 10 },
                  ]}
                >
                  <Svg width="15" height="19" viewBox="0 0 15 19" fill="none">
                    <Path
                      d="M14.0625 8.07471V16.0625C14.0625 16.5846 13.8551 17.0854 13.4859 17.4546C13.1167 17.8238 12.6159 18.0312 12.0938 18.0312H2.90625C2.38411 18.0312 1.88335 17.8238 1.51413 17.4546C1.14492 17.0854 0.9375 16.5846 0.9375 16.0625V2.9375C0.9375 2.41536 1.14492 1.9146 1.51413 1.54538C1.88335 1.17617 2.38411 0.96875 2.90625 0.96875H6.95654C7.30452 0.968803 7.63823 1.10704 7.88432 1.35307L13.6782 7.14693C13.9242 7.39302 14.0624 7.72673 14.0625 8.07471Z"
                      stroke={this.state.currentTab == 1 ? "black" : "white"}
                      stroke-linejoin="round"
                    />
                    <Path
                      d="M10.5 2.29688V7.21875C10.5 7.56685 10.6383 7.90069 10.8844 8.14683C11.1306 8.39297 11.4644 8.53125 11.8125 8.53125H16.7344"
                      stroke={this.state.currentTab == 1 ? "black" : "white"}
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </Svg>
                  <Text
                    style={[
                      this.state.currentTab == 1
                        ? styles.activeTabStyle
                        : styles.inactiveTabStyle,
                      { fontWeight: "300", fontSize: 15 },
                    ]}
                  >
                    เอกสาร
                  </Text>
                </TabHeading>
              }
            >
              <Document
                documents={this.state._docs}
                total_items={this.state.total_items}
                qc_total_counts={this.state.qc_total_counts}
                qc_pass_counts={this.state.qc_pass_counts}
                pass_total_pers={this.state.pass_total_pers}
                pass_check_pers={this.state.pass_check_pers}
              />
            </Tab>
            <Tab
              heading={
                <TabHeading
                  style={[
                    this.state.currentTab == 2
                      ? styles.activeTabStyle
                      : styles.inactiveTabStyle,
                    { flexDirection: "column", paddingVertical: 10 },
                  ]}
                >
                  <Svg width="19" height="19" viewBox="0 0 19 19" fill="none">
                    <Path
                      d="M13.0626 5.34374V13.7196C13.0626 15.3742 11.8513 16.8467 10.2047 17.005C9.76477 17.0489 9.32055 17.0001 8.90069 16.8617C8.48083 16.7233 8.09467 16.4984 7.76715 16.2015C7.43963 15.9045 7.17804 15.5422 6.99926 15.1379C6.82048 14.7336 6.7285 14.2962 6.72925 13.8542V4.06915C6.72925 3.03207 7.47341 2.08999 8.50258 1.98707C8.77858 1.95821 9.05757 1.98771 9.32143 2.07367C9.58529 2.15962 9.82813 2.3001 10.0342 2.48599C10.2402 2.67188 10.4049 2.89902 10.5174 3.15267C10.63 3.40633 10.688 3.68081 10.6876 3.95832V12.2708C10.6876 12.7062 10.3313 13.0625 9.89591 13.0625C9.4605 13.0625 9.10425 12.7062 9.10425 12.2708V5.34374C9.10425 5.01915 8.83508 4.74999 8.5105 4.74999C8.18591 4.74999 7.91675 5.01915 7.91675 5.34374V12.16C7.91675 13.1971 8.66091 14.1392 9.69008 14.2421C9.96608 14.2709 10.2451 14.2414 10.5089 14.1555C10.7728 14.0695 11.0156 13.929 11.2217 13.7432C11.4277 13.5573 11.5924 13.3301 11.7049 13.0765C11.8175 12.8228 11.8755 12.5483 11.8751 12.2708V4.0929C11.8751 2.43832 10.6638 0.965821 9.01716 0.807487C8.57739 0.76416 8.13343 0.8134 7.71384 0.952039C7.29425 1.09068 6.90834 1.31564 6.58096 1.61245C6.25357 1.90926 5.99197 2.27133 5.81299 2.67536C5.634 3.07939 5.54161 3.51642 5.54175 3.95832V13.6721C5.54175 15.9442 7.20425 17.9787 9.46841 18.1925C12.073 18.43 14.2501 16.4033 14.2501 13.8542V5.34374C14.2501 5.01915 13.9809 4.74999 13.6563 4.74999C13.3317 4.74999 13.0626 5.01915 13.0626 5.34374Z"
                      fill={this.state.currentTab == 2 ? "black" : "white"}
                    />
                  </Svg>
                  <Text
                    style={[
                      this.state.currentTab == 2
                        ? styles.activeTabStyle
                        : styles.inactiveTabStyle,
                      { fontWeight: "300", fontSize: 15 },
                    ]}
                  >
                    ไฟล์แนบ
                  </Text>
                </TabHeading>
              }
            >
              <AttachFile
                dataFromParent={this.state.file}
                docno={this.state._docno}
                params={this.state.obj}
                plan={this.state.plan}
              />
            </Tab>
            <Tab
              heading={
                <TabHeading
                  style={[
                    this.state.currentTab == 3
                      ? styles.activeTabStyle
                      : styles.inactiveTabStyle,
                    { flexDirection: "column", paddingVertical: 10 },
                  ]}
                >
                  {/* <LicenseSVG /> */}
                  <Svg width="27" height="20" viewBox="0 0 27 20" fill="none">
                    <G clip-path="url(#clip0)">
                      <Path
                        d="M10.8603 15.1496C10.081 14.9241 8.72234 15.281 8.08343 15.3278C7.58615 15.3646 7.15723 15.3964 6.83568 15.2793C6.50385 15.1586 6.5405 14.9025 6.80029 14.4035C6.8592 14.2919 7.39533 13.3031 6.58003 13.0579C6.20347 12.9458 5.5034 13.0784 3.41796 14.0021L4.58147 12.7013C5.43344 11.7494 4.60997 10.1926 3.22649 10.4988L2.22322 10.7472C2.08945 10.7767 2.00424 10.9103 2.03317 11.0455L2.14142 11.5339C2.17035 11.6691 2.30395 11.7543 2.43972 11.7239L3.4992 11.4627C3.83189 11.3893 4.05831 11.7859 3.8345 12.0354L1.08016 15.1166C0.890001 15.3284 0.885197 15.7756 1.28163 15.9199C1.4035 15.9643 1.541 15.9611 1.66369 15.9027C2.50882 15.5086 4.74046 14.5167 5.81105 14.1565C5.62644 14.5632 5.46545 15.0101 5.66568 15.497C5.80054 15.8254 6.07814 16.0678 6.49219 16.2185C7.01489 16.4087 7.56864 16.3675 8.15455 16.3247C8.71817 16.2838 9.94268 15.9346 10.5383 16.0982C10.6668 16.1334 10.8005 16.0723 10.8459 15.9474L11.0174 15.4761C11.069 15.3436 10.9971 15.1894 10.8603 15.1496Z"
                        fill={this.state.currentTab == 3 ? "black" : "white"}
                      />
                    </G>
                    <Path
                      fill-rule="evenodd"
                      clip-rule="evenodd"
                      d="M25.5 1.61953C25.697 1.81649 25.8533 2.05034 25.9599 2.30771C26.0666 2.56508 26.1215 2.84094 26.1215 3.11953C26.1215 3.39812 26.0666 3.67397 25.9599 3.93135C25.8533 4.18872 25.697 4.42257 25.5 4.61953L16 14.1195L12 15.1195L13 11.1755L22.504 1.62353C22.7003 1.42625 22.9336 1.26963 23.1905 1.16263C23.4474 1.05564 23.7229 1.00037 24.0012 1C24.2795 0.99963 24.5551 1.05416 24.8123 1.16047C25.0695 1.26678 25.3032 1.42277 25.5 1.61953V1.61953Z"
                      stroke={this.state.currentTab == 3 ? "black" : "white"}
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <Path
                      d="M24 4.11963L25 5.11963"
                      stroke={this.state.currentTab == 3 ? "black" : "white"}
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <Defs>
                      <ClipPath id="clip0">
                        <Rect
                          width="10"
                          height="8"
                          fill={this.state.currentTab == 3 ? "black" : "white"}
                          transform="translate(2.73608 9) rotate(20)"
                        />
                      </ClipPath>
                    </Defs>
                  </Svg>
                  <Text
                    style={[
                      this.state.currentTab == 3
                        ? styles.activeTabStyle
                        : styles.inactiveTabStyle,
                      { fontWeight: "300", fontSize: 15 },
                    ]}
                  >
                    ลายเซ็น
                  </Text>
                </TabHeading>
              }
            >
              <Draw
                qc_total_counts={this.state.qc_total_counts}
                qc_pass_counts={this.state.qc_pass_counts}
                sig_qc={this.state.sig_qc}
                docno={this.state._docno}
                approve_status={this.state.approve_status}
                sendapp={this.state.sendapp}
                docapp={this.state.docapp}
                Loading={this.loadDocList}
                configApprove={this.state.approveAppQCM}
                params={this.state.obj}
                navigation={this.props.navigation}
                header={this.state.docHeader}
              />
            </Tab>
          </Tabs>
          {/* **************************************End Data Content***************************** */}
        </Body>
        {this.renderFooter()}
      </Container>
    );
  }
}
const styles = StyleSheet.create({
  activeTabStyle: {
    backgroundColor: "#FFFFFF",
    color: "#000",
    borderTopLeftRadius: 20,
    borderTopEndRadius: 20,
  },
  inactiveTabStyle: {
    backgroundColor: "#0F1E43",
    color: "#ffffff",
    borderBottomStartRadius: 20,
  },
});
export default QCM;
