import React, { Component } from "react";
import {
  StyleSheet,
  View,
  TouchableOpacity,
  TextInput,
  SafeAreaView,
  FlatList,
  Alert,
} from "react-native";
import {
  Container,
  Header,
  Title,
  Button,
  Body,
  Icon,
  Text,
  Tab,
  Tabs,
} from "native-base";
import linq from "js-linq";
import { apiAuth } from "../../api/authentication";
import AsyncStorage from "@react-native-async-storage/async-storage";
import HomeLayout from "../../layouts/home_layout";
import SearchInput, { createFilter } from "react-native-search-filter";
import DropDownPicker from "react-native-dropdown-picker";
import Spinner from "react-native-loading-spinner-overlay";
import { BackSVG } from "../../svg/IconSVG";

import MessageBox from "../../api/msg";
import Moment from "moment";
import $xt from "../../api/xtools";
import {
  inputStyle,
  mangoGreen,
  smallTextStyle,
  smallInputStyle,
  bg_logo,
  bg_header,
  btn_text,
} from "../../stylesheet/styles";
import {
  getReadList,
  readLoopApprove,
  readUserLoopApprove,
  SendApprove,
} from "../../api/qcm";
const $linq = (arr) => new linq(arr);
// const ItemDropDown = [
//     { label: 'อนุมัติ WO งานจ้างเหมา', value: 'AA' },
//     { label: 'อนุมัติ WO งานโครงสร้าง', value: 'BB' },
//     { label: 'อนุมัติ WO งานไฟฟ้า', value: 'CC' },
//     { label: 'อนุมัติ WO งานระบบ', value: 'DD' },
// ];

class SubmitApprove extends Component {
  constructor(props) {
    super(props);

    this.state = {
      spinner: false, //
      title: "",
      remarkModalShow: false,
      selectedDocMenu: "all",
      docType: [{ key: 0, label: "All Documents" }],
      selectedDocType: "All Documents",
      refreshing: false, //
      docList: [],
      shownDocList: [],
      remark: "",
      selectedDoc: {}, // for tracking when remark submit
      showRemarkError: false,
      projectData: [{ key: 0, label: "All Projects" }],
      selectedProject: "All Projects",
      searchDoc: "",
      searchPj: "",
      approve_status: false,
      filterS2: [],
      status: "N",
      loopApprove: [], //
      approver: [], //
      selectLoop: "",
      header: {},
    };
  }

  async UNSAFE_componentWillMount() {}
  // componentWillUnmount() {
  //   // fix Warning: Can't perform a React state update on an unmounted component
  //   this.setState = (state, callback) => {
  //     return;
  //   };
  // }
  componentDidMount = async () => {
    // this.setState({ status: "N" })
    // console.log("PARAMS SUBMIT", this.props.route.params.header);
    await this.loadDocList();
  };

  loadDocList = async () => {
    this.setState({ refreshing: true });
    console.log("PARAMS SUBMIT", this.props.route.params);
    let _docno = this.props.route.params.params._docno || "DOCNO";
    let _header = this.props.route.params.header;

    let approve_status = _header.sendapp == "Y" ? true : false;
    this.setState({
      approve_status: approve_status,
      docno: _docno,
    });

    let docs = [];
    docs = await readLoopApprove();

    console.log("LOOP", docs);
    let reFormatLoop = [];
    for (let x of docs.data) {
      let formatNew = {
        label: x.form_name,
        value: x.formcode,
      };
      reFormatLoop.push(formatNew);
      // this.state.loopApprove.push(formatNew);
    }

    // console.log("_header", _header);
    var formcode = null;
    if (!$xt.isEmpty(_header.approve_code)) {
      formcode = _header.approve_code;
      this.readDetailApprove(formcode);
    }
    // else {
    //   this.setState({ selectLoop: reFormatLoop[0].value, })
    // }
    // console.log("SELECTLOOP", formcode);
    // console.log("DROPDOWN", this.state.loopApprove);
    console.log("reFormatLoop...", reFormatLoop);
    this.setState({
      loopApprove: reFormatLoop,
      selectLoop: formcode,
      refreshing: false,
      header: _header,
      // approve_status: approve_status
    });
  };
  readDetailApprove = async (item) => {
    console.log("LOOP", item);
    let data = {
      formcode: item,
      pre_event: this.props.route.params.params._pre_event,
    };
    let detail = await readUserLoopApprove(data);
    this.setState({
      selectLoop: item,
      approver: detail,
      formcode: item,
    });
  };
  _sendAppApprove = async (status) => {
    console.log("selectLoop", this.state.selectLoop);
    if ($xt.isEmpty(this.state.selectLoop)) {
      await MessageBox.Alert(`Warning`, `Please select approve loop`);
    } else {
      this.setState({ spinner: true });
      let data = {
        docno: this.props.route.params.params._docno,
        sendapp: status,
        formcode: this.state.formcode,
      };
      //console.log("DATA SUBMIT", data);

      if (status == "Y") {
        // return await SendApprove(data);//Send Approve
        await SendApprove(data);
        let messageBox = await MessageBox.Alert(
          `Success`,
          `  เก็บข้อมูล Submit เรียบร้อย`
        );
        if (messageBox) {
          this.props.navigation.push("All_project");
        }

        this.setState({ spinner: false });
      }
    }
  };
  Header = () => (
    <Header
      transparent
      iosBarStyle={"light-content"}
      style={[
        bg_header,
        { flexDirection: "row", width: "100%", alignItems: "center" },
      ]}
    >
      <View style={{ width: "20%" }}>
        <Button
          transparent
          style={{ width: "100%", justifyContent: "flex-start" }}
          onPress={() => this.props.navigation.goBack()}
        >
          <BackSVG />
        </Button>
      </View>
      <Body
        style={{ width: "70%", alignItems: "center", paddingVertical: 7.5 }}
      >
        <Title style={btn_text}>Submit Approve</Title>
      </Body>

      <View style={{ width: "20%" }}>
        <Button
          transparent
          style={{ width: "100%", justifyContent: "flex-end" }}
        ></Button>
      </View>
    </Header>
  );
  renderFooter = () => {
    return (
      <View
        style={{
          flexDirection: "row",
          justifyContent: "center",
          alignItems: "center",
          zIndex: 3,
          // backgroundColor: "#0f133b",
          backgroundColor: "#FFFFFF",
          height: 70,
        }}
      >
        {/* <TouchableOpacity
                    onPress={() => this._sendAppApprove("N")}
                >
                    <View
                        style={{
                            backgroundColor: "#9FABC6",
                            marginVertical: 10,
                            marginHorizontal: 5,
                            paddingHorizontal: "17%", //43%
                            // width: "96%",
                            paddingVertical: 10,
                            borderRadius: 50,
                            height: 40,
                        }}
                    >
                        <Text
                            style={{ textAlign: "center", fontWeight: "bold" }}
                        >
                            Not Submit
                </Text>
                    </View>
                </TouchableOpacity> */}

        {/* this.state.header.sendapp != "Y" || $xt.isEmpty(this.state.header.approve_code) */}

        {this.state.header.sendapp != "Y" ||
        $xt.isEmpty(this.state.header.approve_code) ? (
          <TouchableOpacity onPress={() => this._sendAppApprove("Y")}>
            <View
              style={{
                backgroundColor: "#FDCB6E",

                marginVertical: 10,
                marginHorizontal: 5,
                paddingHorizontal: "40%", //17%
                paddingVertical: 10,
                borderRadius: 50,
                height: 40,
              }}
            >
              <Text style={{ textAlign: "center", fontWeight: "bold" }}>
                Submit
              </Text>
            </View>
          </TouchableOpacity>
        ) : null}
      </View>
    );
  };
  renderItem = ({ item }) => {
    return (
      <View
        style={{
          marginHorizontal: 10,
          marginVertical: 10,
          borderBottomWidth: 1,
        }}
      >
        <View style={{ flexDirection: "row", paddingVertical: 10 }}>
          <Text style={{ color: "#000000", fontSize: 16 }}>Approver :</Text>
          <Text
            style={{ color: "#000000", fontSize: 16, paddingHorizontal: 10 }}
          >
            {item.empfullname_t}
          </Text>
        </View>
        <View style={{ flexDirection: "row", paddingVertical: 10 }}>
          <Text style={{ color: "#000000", fontSize: 16 }}>level :</Text>
          <Text
            style={{ color: "#000000", fontSize: 16, paddingHorizontal: 10 }}
          >
            {item.levelapp}
          </Text>
        </View>
      </View>
    );
  };
  List = () => (
    <SafeAreaView style={{ flex: 1 }}>
      <FlatList
        ref={(ref) => {
          this.flatListRef = ref;
        }}
        contentContainerStyle={{ paddingBottom: 65 }}
        extraData={this.state.refreshing}
        data={this.state.approver}
        onRefresh={this.loadDocList}
        refreshing={this.state.refreshing}
        initialNumToRender={10} // Reduce initial render amount
        maxToRenderPerBatch={5} // Reduce number in each render batch
        windowSize={3} // Reduce the window size
        renderItem={this.renderItem}
        keyExtractor={(item, index) => index.toString()}
      />
    </SafeAreaView>
  );

  render() {
    console.log("RENDER", this.state.selectLoop);
    return (
      <HomeLayout>
        <Container>
          {this.Header()}
          {/* {this.FilterBar()} */}
          <Body>
            <Spinner
              visible={this.state.spinner}
              color={"white"}
              textContent={"Please wait..."}
              textStyle={smallInputStyle}
            />
            <View
              style={{
                flex: 1,
              }}
            >
              {/* <View style={{ flexDirection: "row", width: "100%", paddingHorizontal: 10, marginVertical: 10 }}>
                                <Text>บริษัท แมงโก้ คอนซัลแตนท์ จำกัด</Text>
                            </View> */}
              <View
                style={{
                  flexDirection: "row",
                  width: "100%",
                  paddingHorizontal: 10,
                  marginVertical: 10,
                }}
              >
                <Text style={{ fontWeight: "bold" }}>
                  เลขที่เอกสาร : {this.state.docno}
                </Text>
              </View>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginTop: 15,
                  ...(Platform.OS !== "android" && {
                    zIndex: 10,
                  }),
                }}
              >
                <View
                  style={{
                    flexDirection: "row",
                    width: "100%",
                    paddingHorizontal: 10,
                    marginVertical: 10,
                  }}
                >
                  {/* <DropDownPicker
                  zIndex={10}
                  items={this.state.loopApprove}
                  defaultValue={this.state.selectLoop}
                  containerStyle={{ width: "100%", height: 45 }}
                  style={{
                    backgroundColor: "#FFFFFF",
                    borderColor: "#000000",
                    borderTopLeftRadius: 10,
                    borderTopRightRadius: 10,
                    borderBottomLeftRadius: 10,
                    borderBottomRightRadius: 10,
                  }} //borderradius ต้องแยกมุม
                  itemStyle={{
                    justifyContent: "flex-start",
                    borderBottomWidth: 1,
                    borderBottomColor: "#A5A5A5",
                  }}
                  dropDownStyle={{
                    backgroundColor: "red",
                    borderColor: "#000000",
                    borderTopLeftRadius: 10,
                    borderTopRightRadius: 10,
                    borderBottomLeftRadius: 10,
                    borderBottomRightRadius: 10,
                  }}
                  labelStyle={{ fontSize: 18, fontFamily: "KanitLight" }}
                  onChangeItem={(item) => this.readDetailApprove(item)}
                  placeholder="Select Approve Loop"
                /> */}

                  <DropDownPicker
                    items={this.state.loopApprove}
                    disabled={this.state.approve_status}
                    searchable={true}
                    placeholder="Please Select Approval"
                    defaultValue={this.state.selectLoop}
                    containerStyle={{ width: "100%", height: 45 }}
                    dropDownMaxHeight={300}
                    style={{ backgroundColor: "#fafafa" }}
                    itemStyle={{
                      justifyContent: "flex-start",
                    }}
                    zIndex={10}
                    dropDownStyle={{ backgroundColor: "#fafafa" }}
                    onChangeItem={(item) => this.readDetailApprove(item.value)}
                  />
                </View>
              </View>
              {this.List()}
            </View>
          </Body>
          {this.renderFooter()}
        </Container>
      </HomeLayout>
    );
  }
}
const styles = StyleSheet.create({
  contentContainer: {
    paddingVertical: 60,
  },
  pickerContainer: {
    backgroundColor: "#E6E6E6",
    height: 32,
    paddingHorizontal: 10,
    borderRadius: 5,
  },
  blockSearch: {
    position: "absolute",
    right: 5,
    width: 40,
    height: 68,
    marginVertical: 8,
    backgroundColor: mangoGreen,
    flex: 1,
    flexDirection: "column",
    justifyContent: "center",
    borderRadius: 5,
  },
  btnSearch: {
    color: "#fff",
    fontSize: 22,
  },
});
export default SubmitApprove;
