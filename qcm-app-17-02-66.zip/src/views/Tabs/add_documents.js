import React, { Component, useState } from 'react';
import { StyleSheet, Alert, View, Image, TouchableOpacity, ListView, ScrollView } from 'react-native'
import { Container, Root, Header, Title, Content, Footer, FooterTab, Button, Left, Right, Body, Icon, Text, Badge, Card, CardItem, H1, List, ListItem, Thumbnail, Switch, Tab, Tabs, Item, Picker } from 'native-base';
import { Circle } from 'react-native-svg';
import Modal from 'react-native-modal';
import { LinearGradient } from 'expo-linear-gradient';
import SvgPanZoom, { SvgPanZoomElement } from 'react-native-svg-pan-zoom';
import {
    borderGrey,
    darkGreen,
    iconStyle,
    inputStyle,
    mangoGreen,
    red,
    grey,
    smallTextStyle,
    smallText,
    titleStyle,
    tinyTextStyle,
    smallInputStyle,
    blue,
    darkBlue,
    bg_header,
    btn_text
} from "../../stylesheet/styles";


const project = [
    {
        id: 'KSC01',
        unit: '01022015',
        name: 'โครงการก่อสร้างรถไฟฟ้าทางคู่ ประจวบ-ชุมพร/1'
    },
    {
        id: 'KSC02',
        unit: '01022045',
        name: 'โครงการก่อสร้างรถไฟฟ้าทางคู่ ประจวบ-ชุมพร/2'
    },
    {
        id: 'KSC03',
        unit: '01022055',
        name: 'โครงการก่อสร้างรถไฟฟ้าทางคู่ ประจวบ-ชุมพร/3'
    },
    {
        id: 'KSC04',
        unit: '01022075',
        name: 'โครงการก่อสร้างรถไฟฟ้าทางคู่ ประจวบ-ชุมพร/4'
    },
    {
        id: 'KSC05',
        unit: '01022085',
        name: 'โครงการก่อสร้างรถไฟฟ้าทางคู่ ประจวบ-ชุมพร/5'
    },
    {
        id: 'KSC06',
        unit: '01022095',
        name: 'โครงการก่อสร้างรถไฟฟ้าทางคู่ ประจวบ-ชุมพร/6'
    },
    {
        id: 'KSC07',
        unit: '01022105',
        name: 'โครงการก่อสร้างรถไฟฟ้าทางคู่ ประจวบ-ชุมพร/7'
    },
    {
        id: 'KSC08',
        unit: '01022125',
        name: 'โครงการก่อสร้างรถไฟฟ้าทางคู่ ประจวบ-ชุมพร/8'
    },
];
const area = [
    {
        id: "A0010",
        name: "หลักกิโลเมตร 500"
    },
    {
        id: "A0020",
        name: "หลักกิโลเมตร 1000"
    },
];
const datafrom = [
    {
        date: "06/03/2020",
        round: 1,
        Doc: 1,
        id: "FS-EC-12-04",
        name: "Lighting_Small Power ITR",
        Doc_No: "QC20200300003",
        contractor: "บริษัท บี ดี เค 2556 จำกัด"
    },
    {
        date: "06/03/2020",
        round: 2,
        Doc: 1,
        id: "FS-EC-12-05",
        name: "Cable Tray_Raceway ITR",
        Doc_No: "QC20200300002",
        contractor: "บริษัท บี ดี เค 2556 จำกัด"
    },
]

class AddDocument extends Component {
    constructor(props) {
        super(props)
        this.state = {
            show_qc: false,
            show_project: false,
            show_area: false,
            show_from: false,
        }
        this.qcm = "";
        this.project_qc = "";
        this.area_qc = "";
        this.from_qc = "";
        this.users_id = 20150015;
    }
    close_qcm = () => this.setState({ show_qc: false });
    close_project_qc = () => this.setState({ show_project: false });
    close_area_qc = () => this.setState({ show_area: false });
    close_from_qc = () => this.setState({ show_from: false });
    Header = () => (
        Platform.select({
            ios:
                <Header transparent iosBarStyle={"light-content"} style={bg_header}>
                    <Left />
                    <Body style={{ flex: 3 }}>
                        <Title style={btn_text}>QCM</Title>
                    </Body>
                    <Right />
                </Header>,
            android:
                <Header style={bg_header}>
                    <Body style={{ justifyContent: 'center', flexDirection: 'row', textAlign: 'center' }}>
                        <Title style={[btn_text]}>QCM</Title>
                    </Body>
                </Header>
        })
    )

    render() {
        return (
            <Container>
                {this.Header()}
                <View style={{ flex: 1 }}>

                    {/* ************************************** Data Content******************************* */}
                    <View>
                        <Modal isVisible={this.state.show_qc}
                            animationType="slide"
                            swipeDirection={['down', 'right']}
                            onSwipeComplete={this.close_qcm}
                        >
                            <View style={{ backgroundColor: "#00000000", flex: 1, justifyContent: "flex-start" }}
                            //  onTouchEnd={this.close_qcm}
                            >
                                <View style={{
                                    backgroundColor: "#ffffff",
                                    margin: 0, padding: 20,
                                    borderRadius: 10
                                }}>
                                    <Text style={{ fontSize: 20, marginTop: 5 }} onPress={() => {
                                        this.qcm = "QC";
                                        this.setState({ show_qc: false });
                                    }}

                                    >
                                        QC{"\n"}
                                    </Text>
                                    <View
                                        style={{
                                            borderBottomColor: 'black',
                                            borderBottomWidth: 1,
                                        }}
                                    />
                                    <Text style={{ fontSize: 20, marginTop: 5 }} onPress={() => {
                                        this.qcm = "Defect";
                                        this.setState({ show_qc: false });
                                        this.boxClick;
                                    }}>
                                        {"\n"}Defect
              </Text>

                                    {/* <Button full danger onPress={()=>{this.setState({show:false})}} style={{marginTop:80}}>
                <Text>ปิด</Text>
              </Button> */}
                                </View>
                            </View>
                        </Modal>
                    </View>
                    <View>
                        <Modal isVisible={this.state.show_project}
                            animationType="slide"
                            // swipeDirection={['right']}
                            onSwipeComplete={this.close_project_qc}
                        >
                            <View style={{ backgroundColor: "#00000000", flex: 1, justifyContent: "flex-start" }}
                            // onTouchEnd={this.close_project_qc}
                            >
                                <View style={{
                                    backgroundColor: "#F2F2F2",
                                    margin: 0,
                                    padding: 20,
                                    borderRadius: 10,
                                    marginBottom: 100,
                                    paddingTop: 10,
                                    height: "100%"
                                }}>
                                    <Text style={{ textAlign: "right", marginBottom: 10 }} >
                                        <Text onPress={() => { this.setState({ show_project: false }) }}>Close
                    </Text>
                                    </Text>
                                    <View style={{ marginBottom: 10 }}>
                                        <Text>
                                            <Text style={{ color: "#555555", fontWeight: '600' }}>{this.users_id} </Text>
                                            {this.project_qc == "" ? null :
                                                <Text style={{ color: "#555555" }}> [{this.project_qc.unit}] [{this.project_qc.id}]</Text>
                                            }
                                            {this.area_qc == "" ? null :
                                                <Text style={{ color: "#555555" }}> [{this.area_qc.id}]</Text>
                                            }
                                        </Text>
                                        {this.project_qc == "" ? null :
                                            <Text style={{ color: "#555555" }}>{this.project_qc.name}</Text>
                                        }
                                    </View>

                                    <ScrollView>
                                        {project.map((item, key) => (
                                            <View key={key}>
                                                {this.project_qc.id == item.id ?
                                                    <Card style={{
                                                        borderRadius: 15,
                                                        padding: 10,
                                                        backgroundColor: "#56CCF2"
                                                    }}>
                                                        <Text onPress={() => {
                                                            this.project_qc = {
                                                                id: item.id,
                                                                unit: item.unit,
                                                                name: item.name
                                                            };
                                                            this.setState({ show_project: false });
                                                        }}>
                                                            <Text style={{ color: "#FFFFFF" }}>
                                                                <Text style={{ fontWeight: '600', color: "#FFFFFF" }}>รหัสอ้างอิง : </Text><Text style={{ color: "#FFFFFF" }}>{item.id}</Text></Text>{"\n"}
                                                            <Text><Text style={{ fontWeight: '600', color: "#FFFFFF" }}>เลขที่ยูนิต : </Text><Text style={{ color: "#FFFFFF" }}>{item.unit}</Text></Text>{"\n"}
                                                            <Text><Text style={{ fontWeight: '600', color: "#FFFFFF" }}>ชื่อยูนิต : </Text><Text style={{ color: "#FFFFFF" }}>{item.name}</Text></Text>
                                                        </Text>
                                                    </Card>
                                                    :
                                                    <Card key={key} style={{
                                                        borderRadius: 15,
                                                        padding: 10
                                                    }}>
                                                        <Text onPress={() => {
                                                            this.project_qc = {
                                                                id: item.id,
                                                                unit: item.unit,
                                                                name: item.name
                                                            };
                                                            this.setState({ show_project: false });
                                                        }}>
                                                            <Text>
                                                                <Text style={{ fontWeight: '600' }}>รหัสอ้างอิง : </Text><Text>{item.id}</Text></Text>{"\n"}
                                                            <Text><Text style={{ fontWeight: '600' }}>เลขที่ยูนิต : </Text><Text>{item.unit}</Text></Text>{"\n"}
                                                            <Text><Text style={{ fontWeight: '600' }}>ชื่อยูนิต : </Text><Text>{item.name}</Text></Text>
                                                        </Text>
                                                    </Card>
                                                }
                                            </View>
                                        ))}
                                    </ScrollView>
                                </View>
                            </View>
                        </Modal>
                    </View>
                    <View>
                        <Modal isVisible={this.state.show_area}
                            animationType="slide"
                            // swipeDirection={['down','right']}
                            onSwipeComplete={this.close_area_qc}
                        >
                            <View style={{ backgroundColor: "#00000000", flex: 1, justifyContent: "flex-start" }}
                            // onTouchEnd={this.close_area_qc}
                            >
                                <View style={{
                                    backgroundColor: "#F2F2F2",
                                    margin: 0,
                                    padding: 20,
                                    borderRadius: 10,
                                    marginBottom: 100,
                                    paddingTop: 10,
                                    height: "100%"
                                }}>
                                    <Text style={{ textAlign: "right", marginBottom: 10 }} >
                                        <Text onPress={() => { this.setState({ show_area: false }) }}>Close
                    </Text>
                                    </Text>
                                    <View style={{ marginBottom: 10 }}>
                                        <Text>
                                            <Text style={{ color: "#555555", fontWeight: '600' }}>{this.users_id} </Text>
                                            {this.project_qc == "" ? null :
                                                <Text style={{ color: "#555555" }}> [{this.project_qc.unit}] [{this.project_qc.id}]</Text>
                                            }
                                            {this.area_qc == "" ? null :
                                                <Text style={{ color: "#555555" }}> [{this.area_qc.id}]</Text>
                                            }
                                        </Text>
                                        {this.project_qc == "" ? null :
                                            <Text style={{ color: "#555555" }}>{this.project_qc.name}</Text>
                                        }
                                    </View>

                                    <ScrollView>
                                        {area.map((item, key) => (
                                            <View key={key}>
                                                {this.area_qc.id == item.id ?
                                                    <Card style={{
                                                        borderRadius: 15,
                                                        padding: 10,
                                                        backgroundColor: "#56CCF2"
                                                    }}>
                                                        <Text onPress={() => {
                                                            this.area_qc = {
                                                                id: item.id,
                                                                name: item.name
                                                            };
                                                            this.setState({ show_area: false });
                                                        }}>
                                                            <Text>
                                                                <Text style={{ fontWeight: '600', color: "#FFFFFF" }}>รหัสพื่นที่ตรวจ : </Text><Text style={{ color: "#FFFFFF" }}>{item.id}</Text></Text>{"\n"}
                                                            <Text><Text style={{ fontWeight: '600', color: "#FFFFFF" }}>ชื่อพื่นที่ตรวจ : </Text><Text style={{ color: "#FFFFFF" }}>{item.name}</Text></Text>
                                                        </Text>
                                                    </Card>
                                                    :
                                                    <Card key={key} style={{
                                                        borderRadius: 15,
                                                        padding: 10
                                                    }}>
                                                        <Text onPress={() => {
                                                            this.area_qc = {
                                                                id: item.id,
                                                                name: item.name
                                                            };
                                                            this.setState({ show_area: false });
                                                        }}>
                                                            <Text>
                                                                <Text style={{ fontWeight: '600' }}>รหัสพื่นที่ตรวจ : </Text><Text>{item.id}</Text></Text>{"\n"}
                                                            <Text><Text style={{ fontWeight: '600' }}>ชื่อพื่นที่ตรวจ : </Text><Text>{item.name}</Text></Text>
                                                        </Text>
                                                    </Card>
                                                }
                                            </View>
                                        ))}
                                    </ScrollView>
                                </View>
                            </View>
                        </Modal>
                    </View>
                    <View>
                        <Modal isVisible={this.state.show_from}
                            animationType="slide"
                            // swipeDirection={['down','right']}
                            onSwipeComplete={this.close_from_qc}
                        >
                            <View style={{ backgroundColor: "#00000000", flex: 1, justifyContent: "flex-start" }}
                            // onTouchEnd={this.close_from_qc}
                            >
                                <View style={{
                                    backgroundColor: "#F2F2F2",
                                    margin: 0,
                                    padding: 20,
                                    borderRadius: 10,
                                    marginBottom: 100,
                                    paddingTop: 10,
                                    height: "100%"
                                }}>
                                    <Text style={{ textAlign: "right", marginBottom: 10 }} >
                                        <Text onPress={() => { this.setState({ show_from: false }) }}>Close
                    </Text>
                                    </Text>
                                    <View style={{ marginBottom: 10 }}>
                                        <Text>
                                            <Text style={{ color: "#555555", fontWeight: '600' }}>{this.users_id} </Text>
                                            {this.project_qc == "" ? null :
                                                <Text style={{ color: "#555555" }}> [{this.project_qc.unit}] [{this.project_qc.id}]</Text>
                                            }
                                            {this.area_qc == "" ? null :
                                                <Text style={{ color: "#555555" }}> [{this.area_qc.id}]</Text>
                                            }
                                        </Text>
                                        {this.project_qc == "" ? null :
                                            <Text style={{ color: "#555555" }}>{this.project_qc.name}</Text>
                                        }
                                    </View>

                                    <ScrollView>
                                        {datafrom.map((item, key) => (
                                            <View key={key}>
                                                {this.from_qc.id == item.id ?
                                                    <Card style={{
                                                        borderRadius: 15,
                                                        padding: 10,
                                                        backgroundColor: "#56CCF2"
                                                    }}>
                                                        <Text onPress={() => {
                                                            this.from_qc = {
                                                                id: item.id,
                                                                date: item.date,
                                                                round: item.round,
                                                                Doc: item.Doc,
                                                                name: item.name,
                                                                Doc_No: item.Doc_No,
                                                                contractor: item.contractor,
                                                            };
                                                            this.setState({ show_from: false });
                                                        }}>

                                                            <Text style={{ color: "#FFFFFF" }}>{item.date}</Text>{"\n"}
                                                            <Text>
                                                                <Text style={{ fontWeight: '600', color: "#FFFFFF" }}>งานตรวจ : </Text><Text style={{ color: "#FFFFFF" }}>{item.round}   </Text>
                                                                <Text style={{ fontWeight: '600', color: "#FFFFFF" }}>เอกสารตรวจที่ : </Text><Text style={{ color: "#FFFFFF" }}>{item.Doc}</Text>{"\n"}
                                                                <Text style={{ fontWeight: '600', color: "#FFFFFF" }}>รหัสฟอร์มตรวจ : </Text><Text style={{ color: "#FFFFFF" }}>{item.id}</Text>{"\n"}
                                                                <Text style={{ fontWeight: '600', color: "#FFFFFF" }}>ชื่อฟอร์มตรวจ : </Text><Text style={{ color: "#FFFFFF" }}>{item.name}</Text>{"\n"}
                                                                <Text style={{ fontWeight: '600', color: "#FFFFFF" }}>เลขที่เอกสาร : </Text>
                                                                <Text style={{ color: '#FFFFFF', textDecorationLine: 'underline' }} onPress={() => Linking.openURL('http://google.com')}>{item.Doc_No}</Text>{"\n"}
                                                                <Text style={{ fontWeight: '600', color: "#FFFFFF" }}>ผู้รับเหมา : </Text><Text style={{ color: "#FFFFFF" }}>{item.contractor}</Text>
                                                            </Text>
                                                        </Text>

                                                    </Card>
                                                    :
                                                    <Card key={key} style={{
                                                        borderRadius: 15,
                                                        padding: 10
                                                    }}>
                                                        <Text onPress={() => {
                                                            this.from_qc = {
                                                                id: item.id,
                                                                date: item.date,
                                                                round: item.round,
                                                                Doc: item.Doc,
                                                                name: item.name,
                                                                Doc_No: item.Doc_No,
                                                                contractor: item.contractor,
                                                            };
                                                            this.setState({ show_from: false });
                                                        }}>

                                                            <Text >{item.date}</Text>{"\n"}
                                                            <Text>
                                                                <Text style={{ fontWeight: '600', color: "#555555" }}>งานตรวจ : </Text><Text>{item.round}   </Text>
                                                                <Text style={{ fontWeight: '600', color: "#555555" }}>เอกสารตรวจที่ : </Text><Text>{item.Doc}</Text>{"\n"}
                                                                <Text style={{ fontWeight: '600', color: "#555555" }}>รหัสฟอร์มตรวจ : </Text><Text>{item.id}</Text>{"\n"}
                                                                <Text style={{ fontWeight: '600', color: "#555555" }}>ชื่อฟอร์มตรวจ : </Text><Text>{item.name}</Text>{"\n"}
                                                                <Text style={{ fontWeight: '600', color: "#555555" }}>เลขที่เอกสาร : </Text>
                                                                <Text style={{ color: 'blue', textDecorationLine: 'underline' }} onPress={() => Linking.openURL('http://google.com')}>{item.Doc_No}</Text>{"\n"}
                                                                <Text style={{ fontWeight: '600', color: "#555555" }}>ผู้รับเหมา : </Text><Text >{item.contractor}</Text>
                                                            </Text>
                                                        </Text>

                                                    </Card>

                                                }
                                            </View>
                                        ))}
                                    </ScrollView>
                                </View>
                            </View>
                        </Modal>
                    </View>
                    <View style={{
                        backgroundColor: "#FFFFFF",
                        margin: 0,
                        padding: 10,
                        borderRadius: 10,
                        marginBottom: 10,
                        paddingTop: 10,
                        height: "100%",
                        width: "100%",
                        alignItems: "center",
                    }}>
                        <ScrollView style={{ width: "100%", alignSelf: "center", padding: 10, marginBottom: 70 }}>
                            <Button block onPress={() => { this.setState({ show_qc: true }) }} style={styles.button}>
                                {this.qcm == "" ? <Text style={{ fontSize: 20, color: "#111111", justifyContent: "center" }}>QC , Defect</Text>
                                    : <Text style={{ fontSize: 20, color: "#111111", justifyContent: "flex-start" }}>{this.qcm}</Text>}

                            </Button>
                            <Button block onPress={() => { this.setState({ show_project: true }) }} style={styles.button}>
                                {this.project_qc == "" ? <Text style={{ fontSize: 20, color: "#111111", justifyContent: "center" }}>Project</Text>
                                    : <Text style={{ fontSize: 15, color: "#111111", justifyContent: "flex-start", textAlign: "center" }}>{this.project_qc.id}   {this.project_qc.unit}{"\n"}{this.project_qc.name}</Text>}
                            </Button>
                            <Button block onPress={() => { this.setState({ show_area: true }) }} style={styles.button}>
                                {this.area_qc == "" ? <Text style={{ fontSize: 20, color: "#111111", justifyContent: "center" }}>Area</Text>
                                    : <Text style={{ fontSize: 15, color: "#111111", justifyContent: "flex-start", textAlign: "center" }}>{this.area_qc.id}{"\n"}{this.area_qc.name}</Text>}
                            </Button>
                            <Button block onPress={() => { this.setState({ show_from: true }) }} style={styles.button}>
                                {this.from_qc == "" ? <Text style={{ fontSize: 20, color: "#111111", justifyContent: "center" }}>From</Text>
                                    : <Text style={{ fontSize: 15, color: "#111111", justifyContent: "flex-start", textAlign: "center" }}>{this.from_qc.id}{"\n"}{this.from_qc.name}</Text>}
                            </Button>
                        </ScrollView>
                    </View>
                    {this.qcm == "" ? null
                        : <Button block onPress={() => { this.setState({ show: true }) }} style={styles.saves}>
                            <Text style={{ fontSize: 20, color: "#FFFFFF", justifyContent: "center" }}>Save</Text>
                        </Button>}

                    {/* *************************************************End Modal Content****************************** */}
                </View>
            </Container>
        );
    }
}
const styles = StyleSheet.create({
    button: {
        width: "90%",
        height: 60,
        borderRadius: 15,
        justifyContent: "center",
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 5,
        },
        shadowOpacity: 0.36,
        shadowRadius: 6.68,
        elevation: 11,
        backgroundColor: "#ffffff",
        marginLeft: "5%",
        marginTop: 10,
        marginBottom: 15

    },
    saves: {
        position: 'absolute',
        bottom: 5,
        width: "90%",
        height: 60,
        borderRadius: 15,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        marginLeft: "5%",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 5,
        },
        shadowOpacity: 0.36,
        shadowRadius: 6.68,
        elevation: 11,
        backgroundColor: darkBlue
    },
    separator: {
        height: 0.5, width: "100%", backgroundColor: "#000"
    },

})
export default AddDocument