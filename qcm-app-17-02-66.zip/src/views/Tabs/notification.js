import React, { Component } from 'react';
import { StyleSheet, Alert, View, Image } from 'react-native'
import { Container, Root, Header, Title, Content, Footer, FooterTab, Button, Left, Right, Body, Icon, Text, Badge, Card, CardItem, H1, List, ListItem, Thumbnail, Switch } from 'native-base';
import { Circle } from 'react-native-svg';
import SvgPanZoom, { SvgPanZoomElement } from 'react-native-svg-pan-zoom';

class Notification extends Component {
    constructor(props) {
        super(props)
    }

  render() {
    return (
<Body>
      <View style={{flex:1}}>
          <H1 style={{ flex: 1, paddingVertical: '50%', textAlign: 'center' }}> COMMING SOON</H1>
      </View>
</Body>
    );
  }
}

export default Notification